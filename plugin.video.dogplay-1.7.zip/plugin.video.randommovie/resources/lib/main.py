# -*- coding: utf-8 -*-
import sys
import os
import random
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Import local lists module
from resources.lib import local_lists

# Try to import Fenlight/FenlightAM modules
trakt_api = None
settings_cache = None
sources = None
fenlight_addon_name = None

# Try Fenlight first (original), then FenlightAM (fork)
for addon_id in ['plugin.video.fenlight', 'plugin.video.fenlightam']:
    try:
        fenlight_addon = xbmcaddon.Addon(addon_id)
        fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
        sys.path.append(fenlight_path + '/resources/lib')

        from apis import trakt_api as ta
        from caches import settings_cache as sc
        from modules.sources import Sources
        from modules.settings import playback_key, tmdb_api_key
        from apis.tmdb_api import tmdb_movies_year
        trakt_api = ta
        settings_cache = sc
        sources = Sources
        fenlight_addon_name = fenlight_addon.getAddonInfo('name')
        xbmc.log(f"DogPlay: Successfully loaded {fenlight_addon_name} modules", xbmc.LOGINFO)
        break
    except Exception as e:
        xbmc.log(f"DogPlay: Failed to load {addon_id}: {str(e)}", xbmc.LOGINFO)
        continue

if not trakt_api:
    xbmc.log("DogPlay: Could not load Fenlight or FenlightAM modules", xbmc.LOGERROR)

addon = xbmcaddon.Addon()

def get_addon_setting(setting_id, setting_type='bool'):
    """Get addon setting with type conversion"""
    if setting_type == 'bool':
        return addon.getSetting(setting_id) == 'true'
    elif setting_type == 'int':
        try:
            return int(addon.getSetting(setting_id))
        except:
            return 0
    else:  # string
        return addon.getSetting(setting_id)


def get_content_info(tmdb_id, media_type):
    """Fetch rating and adult status from TMDB"""
    try:
        from apis.tmdb_api import movie_details, tvshow_details
        api_key = tmdb_api_key()
        if media_type == 'movie':
            meta = movie_details(tmdb_id, api_key)
            if not meta: return None, False
            is_adult = meta.get('adult', False)
            # Extract US rating from release_dates
            rating = None
            release_dates = meta.get('release_dates', {}).get('results', [])
            for res in release_dates:
                if res.get('iso_3166_1') == 'US':
                    for rd in res.get('release_dates', []):
                        if rd.get('certification'):
                            rating = rd.get('certification')
                            break
                    if rating: break
            return rating, is_adult
        else: # tv
            meta = tvshow_details(tmdb_id, api_key)
            if not meta: return None, False
            is_adult = meta.get('adult', False)
            # Extract US rating from content_ratings
            rating = None
            content_ratings = meta.get('content_ratings', {}).get('results', [])
            for res in content_ratings:
                if res.get('iso_3166_1') == 'US':
                    rating = res.get('rating')
                    break
            return rating, is_adult
    except:
        return None, False

def normalize_rating(rating, media_type):
    """Normalize various rating strings to our internal order"""
    if not rating: return 'Universal' # Assume safe if no rating found? Or NC-17? 
    # Let's go with Universal for now, but block_adult will catch explicit stuff.
    
    r = str(rating).upper()
    if media_type == 'movie':
        if r in ['G', 'U', 'UNIVERSAL']: return 'Universal'
        if r in ['PG']: return 'PG'
        if r in ['PG-13', 'PG13']: return 'PG-13'
        if r in ['R']: return 'R'
        if r in ['NC-17', 'NC17', '18']: return 'NC-17'
    else: # tv
        if r in ['TV-G', 'TVG', 'G']: return 'Universal'
        if r in ['TV-PG', 'TVPG', 'PG']: return 'PG'
        if r in ['TV-14', 'TV14', '14']: return 'PG-13'
        if r in ['TV-MA', 'TVMA', 'MA', '18']: return 'R'
    
    return 'NC-17'

def check_parental_controls(tmdb_id, media_type, title, silent=False):
    """Unified check for parental controls. Returns True if allowed, False if blocked."""
    if not get_addon_setting('pc_enabled'):
        return True
    
    limit = get_addon_setting('pc_rating_limit', 'string')
    rating_order = ['Universal', 'PG', 'PG-13', 'R', 'NC-17']
    try:
        limit_idx = rating_order.index(limit)
    except:
        limit_idx = 3 # Default to R

    # Fetch rating from TMDB
    rating, is_adult = get_content_info(tmdb_id, media_type)
    
    # Check rating limit
    norm_rating = normalize_rating(rating, media_type)
    try:
        rating_idx = rating_order.index(norm_rating)
    except:
        rating_idx = 4 

    if rating_idx > limit_idx:
        if not silent:
            xbmc.log(f"DogPlay: Blocked restricted content: {title} ({rating})", xbmc.LOGINFO)
            xbmcgui.Dialog().notification('Parental Control', f'Blocked Rating {rating}: {title}', xbmcgui.NOTIFICATION_INFO, 3000)
        return False
    
    return True

def check_fenlight_auth():
    """Check if Fenlight/FenlightAM is authenticated with Trakt"""
    if not settings_cache or not trakt_api:
        xbmcgui.Dialog().ok('Fenlight Not Available',
                          'Fenlight or FenlightAM addon is required. Please install one of them and try again.')
        return False

    try:
        trakt_user = settings_cache.get_setting('fenlight.trakt.user')
        if not trakt_user or trakt_user in ('', 'empty_setting'):
            xbmcgui.Dialog().ok('Authentication Required',
                              'Please authenticate with Trakt in Fenlight first. Go to Fenlight > Tools > Trakt > Authorize')
            return False
        return True
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Could not access Fenlight settings: {str(e)}')
        return False

def get_trakt_lists():
    """Get user's Trakt lists using FenlightAM's API"""
    try:
        # Get user's lists
        lists = trakt_api.trakt_get_lists('my_lists')

        if not lists:
            xbmcgui.Dialog().ok('No Lists Found', 'No Trakt lists found for your account.')
            return []

        return lists
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch Trakt lists: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch lists: {str(e)}", xbmc.LOGERROR)
        return []

def get_list_items(user, list_id):
    """Get movies from a Trakt list"""
    try:
        # Fetch list contents from Trakt
        items = trakt_api.get_trakt_list_contents('movies', user, list_id, with_auth=True)

        if not items:
            xbmcgui.Dialog().ok('Empty List', 'This list contains no movies.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch list items: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch list items: {str(e)}", xbmc.LOGERROR)
        return []

def get_collection_items():
    """Get movies from user's Trakt collection"""
    try:
        # Fetch collection from Trakt
        items = trakt_api.trakt_collection('movies', None)

        if not items:
            xbmcgui.Dialog().ok('Empty Collection', 'Your Trakt movie collection is empty.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch collection: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch collection: {str(e)}", xbmc.LOGERROR)
        return []

def play_random_movie(user, list_id):
    """Select and play a random movie from the list"""
    if not check_fenlight_auth():
        return

    # Set PENDING playback info - service will activate these only after confirming real playback
    window = xbmcgui.Window(10000)
    window.setProperty('dogplay.pending_user', user)
    window.setProperty('dogplay.pending_list_id', str(list_id))
    window.setProperty('dogplay.pending_tmdb_id', '')  # Will be set after movie selection
    window.setProperty('dogplay.pending_title', '')  # Will be set after movie selection
    xbmc.log(f"DogPlay: Set pending playback info - User: {user}, List ID: {list_id}", xbmc.LOGINFO)

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching list contents...')

    # Get movies from list
    movies = get_list_items(user, list_id)

    if not movies:
        progress.close()
        return

    progress.update(50, 'Selecting random movie...')

    # Select random movie with retry loop for parental controls
    max_retries = 10
    tmdb_id = None
    movie_title = 'Unknown'
    
    for attempt in range(max_retries):
        random_movie = random.choice(movies)
        movie_title = random_movie.get('title', 'Unknown')
        media_ids = random_movie.get('media_ids', {})
        tmdb_id = media_ids.get('tmdb')
        
        if not tmdb_id:
            continue
            
        progress.update(75, f"Checking: {movie_title}")
        
        # Parental Control Check (silent mode for filtering)
        if check_parental_controls(tmdb_id, 'movie', movie_title, silent=True):
            break
        else:
            xbmc.log(f"DogPlay: Filtering out {movie_title} due to rating", xbmc.LOGINFO)
            tmdb_id = None # Reset for next attempt
    
    if not tmdb_id:
        progress.close()
        xbmcgui.Dialog().ok('Content Restricted', 'Could not find a movie that matches your parental control settings after multiple attempts.')
        return

    # Update pending movie info for service monitoring
    window.setProperty('dogplay.pending_tmdb_id', str(tmdb_id))
    window.setProperty('dogplay.pending_title', movie_title)
    xbmc.log(f"DogPlay: Selected filtered movie: {movie_title} (tmdb_id='{tmdb_id}')", xbmc.LOGINFO)

    progress.close()

    # Play via FenlightAM's Sources directly

    # Play via FenlightAM's Sources directly
    if tmdb_id or imdb_id:
        try:
            # Get movie metadata to find runtime
            from apis.tmdb_api import movie_details
            from modules import watched_status
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 0) if meta else 0

            # Calculate random position based on settings
            random_percent = 0.0
            random_start_enabled = get_addon_setting('random_start_enabled')

            if runtime > 0 and random_start_enabled:
                runtime_seconds = runtime * 60  # Convert minutes to seconds
                min_percent = float(get_addon_setting('min_start_percent', 'int'))
                max_percent = float(get_addon_setting('max_start_percent', 'int'))

                # Ensure min < max
                if min_percent >= max_percent:
                    min_percent = 5.0
                    max_percent = 80.0

                random_percent = random.uniform(min_percent, max_percent)
                seek_position = int((random_percent / 100.0) * runtime_seconds)

                xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% ({seek_position//60}m {seek_position%60}s) in {runtime}min movie", xbmc.LOGINFO)

                # Set bookmark using FenlightAM's format
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': movie_title,
                    'from_playback': 'false'
                }
                # watched_status.set_bookmark(bookmark_params)
                xbmc.log(f"DogPlay: ℹ️ skipped Trakt bookmark - using forced start percentage instead", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay: Starting from beginning (random start disabled)", xbmc.LOGINFO)

            # Get the playback key to authenticate with FenlightAM
            key = playback_key()
            # Build params for FenlightAM playback with auth key
            params = {
                'tmdb_id': str(tmdb_id) if tmdb_id else '',
                'media_type': 'movie',
                key: 'true'  # Add the playback key to bypass external check
            }

            # Create Sources instance and override get_playback_percent to force our random position
            source_instance = sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                # If we have a random position, return it directly (bypassing resume dialog)
                if random_percent > 0:
                    xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                    return float(random_percent)
                # Otherwise use the original method
                return original_get_playback_percent()

            # Replace the method with our custom one
            source_instance.get_playback_percent = forced_get_playback_percent

            # Call FenlightAM's playback function - it will use our custom get_playback_percent
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay: Playback error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')
    else:
        xbmcgui.Dialog().ok('Error', 'Could not find movie ID to play')

def play_random_from_collection():
    """Play a random movie from user's Trakt collection"""
    if not check_fenlight_auth():
        return

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching your Trakt collection...')

    # Get movies from collection
    movies = get_collection_items()

    if not movies:
        progress.close()
        return

    progress.update(50, 'Selecting random movie...')

    # Select random movie with retry loop for parental controls
    max_retries = 10
    tmdb_id = None
    movie_title = 'Unknown'
    
    for attempt in range(max_retries):
        random_movie = random.choice(movies)
        movie_title = random_movie.get('title', 'Unknown')
        media_ids = random_movie.get('media_ids', {})
        tmdb_id = media_ids.get('tmdb')
        
        if not tmdb_id:
            continue
            
        progress.update(75, f"Checking: {movie_title}")
        
        # Parental Control Check (silent mode for filtering)
        if check_parental_controls(tmdb_id, 'movie', movie_title, silent=True):
            break
        else:
            xbmc.log(f"DogPlay: Filtering out {movie_title} due to rating", xbmc.LOGINFO)
            tmdb_id = None
    
    if not tmdb_id:
        progress.close()
        xbmcgui.Dialog().ok('Content Restricted', 'Could not find a movie that matches your parental control settings after multiple attempts.')
        return

    # Set pending movie info for service monitoring
    window = xbmcgui.Window(10000)
    window.setProperty('dogplay.pending_tmdb_id', str(tmdb_id))
    window.setProperty('dogplay.pending_title', movie_title)
    window.setProperty('dogplay.pending_user', '')  # Collection playback has no list
    window.setProperty('dogplay.pending_list_id', '')
    xbmc.log(f"DogPlay Collection: Selected filtered movie: {movie_title} (tmdb_id='{tmdb_id}')", xbmc.LOGINFO)

    progress.close()

    # Play via FenlightAM's Sources directly

    # Play via FenlightAM's Sources directly
    if tmdb_id or imdb_id:
        try:
            # Get movie metadata to find runtime
            from apis.tmdb_api import movie_details
            from modules import watched_status
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 0) if meta else 0

            # Calculate random position based on settings
            random_percent = 0.0
            random_start_enabled = get_addon_setting('random_start_enabled')

            if runtime > 0 and random_start_enabled:
                runtime_seconds = runtime * 60  # Convert minutes to seconds
                min_percent = float(get_addon_setting('min_start_percent', 'int'))
                max_percent = float(get_addon_setting('max_start_percent', 'int'))

                # Ensure min < max
                if min_percent >= max_percent:
                    min_percent = 5.0
                    max_percent = 80.0

                random_percent = random.uniform(min_percent, max_percent)
                seek_position = int((random_percent / 100.0) * runtime_seconds)

                xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% ({seek_position//60}m {seek_position%60}s) in {runtime}min movie", xbmc.LOGINFO)

                # Set bookmark using FenlightAM's format
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': movie_title,
                    'from_playback': 'false'
                }
                # watched_status.set_bookmark(bookmark_params)
                xbmc.log(f"DogPlay: ℹ️ skipped Trakt bookmark - using forced start percentage instead", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay: Starting from beginning (random start disabled)", xbmc.LOGINFO)

            # Get the playback key to authenticate with FenlightAM
            key = playback_key()
            # Build params for FenlightAM playback with auth key
            params = {
                'tmdb_id': str(tmdb_id) if tmdb_id else '',
                'media_type': 'movie',
                key: 'true'  # Add the playback key to bypass external check
            }

            # Create Sources instance and override get_playback_percent to force our random position
            source_instance = sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                # If we have a random position, return it directly (bypassing resume dialog)
                if random_percent > 0:
                    xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                    return float(random_percent)
                # Otherwise use the original method
                return original_get_playback_percent()

            # Replace the method with our custom one
            source_instance.get_playback_percent = forced_get_playback_percent

            # Call FenlightAM's playback function - it will use our custom get_playback_percent
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay: Playback error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')
    else:
        xbmcgui.Dialog().ok('Error', 'Could not find movie ID to play')

def play_random_from_local_list(list_name='Omakase'):
    """Play a random movie from a local curated list"""
    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', f'Loading {list_name} list...')

    # Get movies from local list
    movies = local_lists.get_local_list('movie')

    if not movies:
        progress.close()
        xbmcgui.Dialog().ok('List Not Found', f'The {list_name} list is not available. Please build it using the list builder tool.')
        return

    progress.update(50, 'Selecting random movie...')

    # Select random movie with retry loop for parental controls
    max_retries = 10
    tmdb_id = None
    movie_title = 'Unknown'

    for attempt in range(max_retries):
        random_movie = random.choice(movies)
        movie_title = random_movie.get('title', 'Unknown')
        tmdb_id = random_movie.get('tmdb_id')

        if not tmdb_id:
            continue

        # If tmdb_id is actually an IMDB ID (starts with 'tt'), convert it
        if str(tmdb_id).startswith('tt'):
            try:
                from apis.tmdb_api import movie_external_id
                api_key = tmdb_api_key()
                # Use TMDB's find endpoint to convert IMDB to TMDB
                imdb_id = tmdb_id
                find_url = f"https://api.themoviedb.org/3/find/{imdb_id}"
                import requests
                response = requests.get(find_url, params={'api_key': api_key, 'external_source': 'imdb_id'})
                result = response.json()
                if result.get('movie_results'):
                    tmdb_id = str(result['movie_results'][0]['id'])
                    xbmc.log(f"DogPlay: Converted {imdb_id} to TMDB ID {tmdb_id}", xbmc.LOGINFO)
                else:
                    xbmc.log(f"DogPlay: Could not convert {imdb_id} to TMDB ID", xbmc.LOGWARNING)
                    continue
            except Exception as e:
                xbmc.log(f"DogPlay: Error converting IMDB ID: {e}", xbmc.LOGERROR)
                continue

        progress.update(75, f"Checking: {movie_title}")

        # Parental Control Check (silent mode for filtering)
        if check_parental_controls(tmdb_id, 'movie', movie_title, silent=True):
            break
        else:
            xbmc.log(f"DogPlay: Filtering out {movie_title} due to rating", xbmc.LOGINFO)
            tmdb_id = None

    if not tmdb_id:
        progress.close()
        xbmcgui.Dialog().ok('Content Restricted', 'Could not find a movie that matches your parental control settings after multiple attempts.')
        return

    # Set pending movie info for service monitoring
    window = xbmcgui.Window(10000)
    window.setProperty('dogplay.pending_tmdb_id', str(tmdb_id))
    window.setProperty('dogplay.pending_title', movie_title)
    window.setProperty('dogplay.pending_user', '')  # Local list has no user
    window.setProperty('dogplay.pending_list_id', 'omakase')  # Use identifier for local list
    xbmc.log(f"DogPlay {list_name}: Selected filtered movie: {movie_title} (tmdb_id='{tmdb_id}')", xbmc.LOGINFO)

    progress.close()

    # Play via FenlightAM's Sources directly
    if tmdb_id:
        try:
            # Get movie metadata to find runtime
            from apis.tmdb_api import movie_details
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 0) if meta else 0

            # Calculate random position based on settings
            random_percent = 0.0
            random_start_enabled = get_addon_setting('random_start_enabled')

            if runtime > 0 and random_start_enabled:
                runtime_seconds = runtime * 60
                min_percent = float(get_addon_setting('min_start_percent', 'int'))
                max_percent = float(get_addon_setting('max_start_percent', 'int'))

                if min_percent >= max_percent:
                    min_percent = 5.0
                    max_percent = 80.0

                random_percent = random.uniform(min_percent, max_percent)
                seek_position = int((random_percent / 100.0) * runtime_seconds)

                xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% ({seek_position//60}m {seek_position%60}s) in {runtime}min movie", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay: Starting from beginning (random start disabled)", xbmc.LOGINFO)

            # Get the playback key
            key = playback_key()
            params = {
                'tmdb_id': str(tmdb_id),
                'media_type': 'movie',
                key: 'true'
            }

            # Create Sources instance and override get_playback_percent
            source_instance = sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                if random_percent > 0:
                    xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                    return float(random_percent)
                return original_get_playback_percent()

            source_instance.get_playback_percent = forced_get_playback_percent
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay: Playback error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')
    else:
        xbmcgui.Dialog().ok('Error', 'Could not find movie ID to play')

def get_tv_list_items(user, list_id):
    """Get TV shows from a Trakt list"""
    try:
        # Fetch list contents from Trakt
        items = trakt_api.get_trakt_list_contents('shows', user, list_id, with_auth=True)

        if not items:
            xbmcgui.Dialog().ok('Empty List', 'This list contains no TV shows.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch list items: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch TV list items: {str(e)}", xbmc.LOGERROR)
        return []

def get_tv_collection_items():
    """Get TV shows from user's Trakt collection"""
    try:
        # Fetch collection from Trakt
        items = trakt_api.trakt_collection('shows', None)

        if not items:
            xbmcgui.Dialog().ok('Empty Collection', 'Your Trakt TV collection is empty.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch TV collection: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch TV collection: {str(e)}", xbmc.LOGERROR)
        return []

def play_random_tv_episode(user, list_id):
    """Select and play a random episode from a random TV show from the list"""
    if not check_fenlight_auth():
        return

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching TV list contents...')

    # Get TV shows from list
    shows = get_tv_list_items(user, list_id)

    if not shows:
        progress.close()
        return

    # Select random TV show with retry loop for parental controls
    max_show_retries = 5
    tmdb_id = None
    show_title = 'Unknown'
    random_show = None
    
    for attempt in range(max_show_retries):
        random_show = random.choice(shows)
        show_title = random_show.get('title', 'Unknown')
        media_ids = random_show.get('media_ids', {})
        tmdb_id = media_ids.get('tmdb')
        
        if not tmdb_id:
            continue
            
        progress.update(40, f"Checking: {show_title}")
        
        # Parental Control Check (silent mode for filtering)
        if check_parental_controls(tmdb_id, 'tv', show_title, silent=True):
            break
        else:
            xbmc.log(f"DogPlay: Filtering out {show_title} due to rating", xbmc.LOGINFO)
            tmdb_id = None

    if not tmdb_id:
        progress.close()
        xbmcgui.Dialog().ok('Content Restricted', 'Could not find a TV show that matches your parental control settings after multiple attempts.')
        return

    progress.update(50, f'Fetching episodes for {show_title}...')

    # Get show metadata to find seasons
    try:
        from apis.tmdb_api import tvshow_details
        api_key = tmdb_api_key()
        show_meta = tvshow_details(tmdb_id, api_key)

        if not show_meta or not show_meta.get('seasons'):
            progress.close()
            xbmcgui.Dialog().ok('Error', f'Could not fetch season data for {show_title}')
            return

        # Filter out season 0 (specials) and get valid seasons
        valid_seasons = [s for s in show_meta['seasons'] if s.get('season_number', 0) > 0]

        if not valid_seasons:
            progress.close()
            xbmcgui.Dialog().ok('Error', f'No valid seasons found for {show_title}')
            return

        progress.update(70, 'Selecting random episode...')

        # Select random season
        random_season = random.choice(valid_seasons)
        season_number = random_season['season_number']
        episode_count = random_season['episode_count']

        if episode_count == 0:
            progress.close()
            xbmcgui.Dialog().ok('Error', f'No episodes found in Season {season_number}')
            return

        # Select random episode
        episode_number = random.randint(1, episode_count)

        progress.update(85, f'Loading S{season_number:02d}E{episode_number:02d}...')

        # Set pending TV episode info for service monitoring
        window = xbmcgui.Window(10000)
        window.setProperty('dogplay.tv.pending_tmdb_id', str(tmdb_id))
        window.setProperty('dogplay.tv.pending_title', show_title)
        window.setProperty('dogplay.tv.pending_season', str(season_number))
        window.setProperty('dogplay.tv.pending_episode', str(episode_number))
        window.setProperty('dogplay.tv.pending_user', user)
        window.setProperty('dogplay.tv.pending_list_id', str(list_id))
        xbmc.log(f"DogPlay TV: Set pending properties - {show_title} S{season_number:02d}E{episode_number:02d}", xbmc.LOGINFO)

        progress.close()

        # Get episode metadata
        from apis.tmdb_api import season_episodes_details
        season_meta = season_episodes_details(tmdb_id, season_number)

        if not season_meta or 'episodes' not in season_meta:
            xbmcgui.Dialog().ok('Error', 'Could not fetch episode data')
            return

        # Find the specific episode
        episode_meta = None
        for ep in season_meta['episodes']:
            if ep.get('episode_number') == episode_number:
                episode_meta = ep
                break

        if not episode_meta:
            xbmcgui.Dialog().ok('Error', f'Could not find episode {episode_number}')
            return

        runtime = episode_meta.get('runtime', 0)

        # Calculate random position based on TV settings
        random_percent = 0.0
        tv_random_start_enabled = get_addon_setting('tv_random_start_enabled')

        if runtime > 0 and tv_random_start_enabled:
            runtime_seconds = runtime * 60
            min_percent = float(get_addon_setting('tv_min_start_percent', 'int'))
            max_percent = float(get_addon_setting('tv_max_start_percent', 'int'))

            if min_percent >= max_percent:
                min_percent = 5.0
                max_percent = 75.0

            random_percent = random.uniform(min_percent, max_percent)
            xbmc.log(f"DogPlay TV: Setting resume to {random_percent:.1f}% for {runtime}min episode", xbmc.LOGINFO)

        # Get the playback key
        key = playback_key()
        params = {
            'tmdb_id': str(tmdb_id),
            'media_type': 'episode',
            'season': str(season_number),
            'episode': str(episode_number),
            key: 'true'
        }

        # Create Sources instance and override get_playback_percent
        source_instance = sources()
        original_get_playback_percent = source_instance.get_playback_percent

        def forced_get_playback_percent():
            if random_percent > 0:
                xbmc.log(f"DogPlay TV: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                return float(random_percent)
            return original_get_playback_percent()

        source_instance.get_playback_percent = forced_get_playback_percent

        # Call FenlightAM's playback function
        source_instance.playback_prep(params)

    except Exception as e:
        progress.close()
        xbmc.log(f"DogPlay TV: Playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')

def play_random_tv_from_collection():
    """Play a random episode from user's Trakt TV collection"""
    if not check_fenlight_auth():
        return

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching your Trakt TV collection...')

    # Get TV shows from collection
    shows = get_tv_collection_items()

    if not shows:
        progress.close()
        return

    # Select random TV show with retry loop for parental controls
    max_show_retries = 5
    tmdb_id = None
    show_title = 'Unknown'
    
    for attempt in range(max_show_retries):
        random_show = random.choice(shows)
        show_title = random_show.get('title', 'Unknown')
        media_ids = random_show.get('media_ids', {})
        tmdb_id = media_ids.get('tmdb')
        
        if not tmdb_id:
            continue
            
        progress.update(40, f"Checking: {show_title}")
        
        # Parental Control Check (silent mode for filtering)
        if check_parental_controls(tmdb_id, 'tv', show_title, silent=True):
            break
        else:
            xbmc.log(f"DogPlay: Filtering out {show_title} due to rating", xbmc.LOGINFO)
            tmdb_id = None

    if not tmdb_id:
        progress.close()
        xbmcgui.Dialog().ok('Content Restricted', 'Could not find a TV show that matches your parental control settings after multiple attempts.')
        return

    progress.update(50, f'Fetching episodes for {show_title}...')

    # Get show metadata to find seasons
    try:
        from apis.tmdb_api import tvshow_details
        api_key = tmdb_api_key()
        show_meta = tvshow_details(tmdb_id, api_key)

        if not show_meta or not show_meta.get('seasons'):
            progress.close()
            xbmcgui.Dialog().ok('Error', f'Could not fetch season data for {show_title}')
            return

        # Filter out season 0 (specials)
        valid_seasons = [s for s in show_meta['seasons'] if s.get('season_number', 0) > 0]

        if not valid_seasons:
            progress.close()
            xbmcgui.Dialog().ok('Error', f'No valid seasons found for {show_title}')
            return

        progress.update(70, 'Selecting random episode...')

        # Select random season
        random_season = random.choice(valid_seasons)
        season_number = random_season['season_number']
        episode_count = random_season['episode_count']

        if episode_count == 0:
            progress.close()
            xbmcgui.Dialog().ok('Error', f'No episodes found in Season {season_number}')
            return

        # Select random episode
        episode_number = random.randint(1, episode_count)

        progress.update(85, f'Loading S{season_number:02d}E{episode_number:02d}...')

        # Set pending TV episode info for service monitoring
        window = xbmcgui.Window(10000)
        window.setProperty('dogplay.tv.pending_tmdb_id', str(tmdb_id))
        window.setProperty('dogplay.tv.pending_title', show_title)
        window.setProperty('dogplay.tv.pending_season', str(season_number))
        window.setProperty('dogplay.tv.pending_episode', str(episode_number))
        window.setProperty('dogplay.tv.pending_user', '')  # Collection playback
        window.setProperty('dogplay.tv.pending_list_id', '')
        xbmc.log(f"DogPlay TV Collection: Set pending properties - {show_title} S{season_number:02d}E{episode_number:02d}", xbmc.LOGINFO)

        progress.close()

        # Get episode metadata
        from apis.tmdb_api import season_episodes_details
        season_meta = season_episodes_details(tmdb_id, season_number)

        if not season_meta or 'episodes' not in season_meta:
            xbmcgui.Dialog().ok('Error', 'Could not fetch episode data')
            return

        # Find the specific episode
        episode_meta = None
        for ep in season_meta['episodes']:
            if ep.get('episode_number') == episode_number:
                episode_meta = ep
                break

        if not episode_meta:
            xbmcgui.Dialog().ok('Error', f'Could not find episode {episode_number}')
            return

        runtime = episode_meta.get('runtime', 0)

        # Calculate random position based on TV settings
        random_percent = 0.0
        tv_random_start_enabled = get_addon_setting('tv_random_start_enabled')

        if runtime > 0 and tv_random_start_enabled:
            runtime_seconds = runtime * 60
            min_percent = float(get_addon_setting('tv_min_start_percent', 'int'))
            max_percent = float(get_addon_setting('tv_max_start_percent', 'int'))

            if min_percent >= max_percent:
                min_percent = 5.0
                max_percent = 75.0

            random_percent = random.uniform(min_percent, max_percent)
            xbmc.log(f"DogPlay TV: Setting resume to {random_percent:.1f}% for {runtime}min episode", xbmc.LOGINFO)

        # Get the playback key
        key = playback_key()
        params = {
            'tmdb_id': str(tmdb_id),
            'media_type': 'episode',
            'season': str(season_number),
            'episode': str(episode_number),
            key: 'true'
        }

        # Create Sources instance and override get_playback_percent
        source_instance = sources()
        original_get_playback_percent = source_instance.get_playback_percent

        def forced_get_playback_percent():
            if random_percent > 0:
                xbmc.log(f"DogPlay TV: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                return float(random_percent)
            return original_get_playback_percent()

        source_instance.get_playback_percent = forced_get_playback_percent

        # Call FenlightAM's playback function
        source_instance.playback_prep(params)

    except Exception as e:
        progress.close()
        xbmc.log(f"DogPlay TV: Playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')

def play_specific_episode(tmdb_id, season, episode, title, user='', list_id=''):
    """Play a specific episode (called from service for next episode playback)"""
    if not check_fenlight_auth():
        return

    # Parental Control Check
    if not check_parental_controls(tmdb_id, 'tv', title):
        return

    try:
        xbmc.log(f"DogPlay: Playing specific episode - {title} S{season:02d}E{episode:02d}", xbmc.LOGINFO)

        # Set pending TV episode info for service monitoring
        window = xbmcgui.Window(10000)
        window.setProperty('dogplay.tv.pending_tmdb_id', str(tmdb_id))
        window.setProperty('dogplay.tv.pending_title', title)
        window.setProperty('dogplay.tv.pending_season', str(season))
        window.setProperty('dogplay.tv.pending_episode', str(episode))
        window.setProperty('dogplay.tv.pending_user', user)
        window.setProperty('dogplay.tv.pending_list_id', list_id)

        # Get episode metadata
        from apis.tmdb_api import season_episodes_details
        api_key = tmdb_api_key()
        season_meta = season_episodes_details(tmdb_id, season)

        if not season_meta or 'episodes' not in season_meta:
            xbmcgui.Dialog().ok('Error', 'Could not fetch episode data')
            return

        # Find the specific episode
        episode_meta = None
        for ep in season_meta['episodes']:
            if ep.get('episode_number') == episode:
                episode_meta = ep
                break

        if not episode_meta:
            xbmcgui.Dialog().ok('Error', f'Could not find episode {episode}')
            return

        runtime = episode_meta.get('runtime', 0)

        # Calculate random position based on TV settings
        random_percent = 0.0
        tv_random_start_enabled = get_addon_setting('tv_random_start_enabled')

        if runtime > 0 and tv_random_start_enabled:
            min_percent = float(get_addon_setting('tv_min_start_percent', 'int'))
            max_percent = float(get_addon_setting('tv_max_start_percent', 'int'))

            if min_percent >= max_percent:
                min_percent = 5.0
                max_percent = 75.0

            random_percent = random.uniform(min_percent, max_percent)
            xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% for {runtime}min episode", xbmc.LOGINFO)

        # Get the playback key
        key = playback_key()
        params = {
            'tmdb_id': str(tmdb_id),
            'media_type': 'episode',
            'season': str(season),
            'episode': str(episode),
            key: 'true'
        }

        # Create Sources instance and override get_playback_percent
        source_instance = sources()
        original_get_playback_percent = source_instance.get_playback_percent

        def forced_get_playback_percent():
            if random_percent > 0:
                xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                return float(random_percent)
            return original_get_playback_percent()

        source_instance.get_playback_percent = forced_get_playback_percent

        # Call FenlightAM's playback function
        source_instance.playback_prep(params)

    except Exception as e:
        xbmc.log(f"DogPlay: Specific episode playback error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')

def select_tv_list():
    """Show TV list selection dialog"""
    if not check_fenlight_auth():
        return

    # Show list selection dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching your Trakt lists...')

    lists = get_trakt_lists()
    progress.close()

    if not lists:
        return

    # Create list selection dialog
    list_names = [l.get('name', 'Unnamed List') for l in lists]
    selected = xbmcgui.Dialog().select('Select a Trakt List', list_names)

    if selected < 0:
        return

    # Get selected list details
    selected_list = lists[selected]
    user = selected_list.get('user', {}).get('ids', {}).get('slug')
    list_id = selected_list.get('ids', {}).get('trakt')

    if user and list_id:
        play_random_tv_episode(user, list_id)

def show_tv_guide():
    """Show the EPG-style TV guide"""
    xbmc.log("=" * 80, xbmc.LOGINFO)
    xbmc.log("DogPlay: show_tv_guide() CALLED", xbmc.LOGINFO)
    xbmc.log("=" * 80, xbmc.LOGINFO)

    if not check_fenlight_auth():
        xbmc.log("DogPlay: show_tv_guide() - Auth check failed", xbmc.LOGINFO)
        return

    # Check guide source setting
    tv_guide_source = get_addon_setting('tv_guide_source', 'string')
    xbmc.log(f"DogPlay: show_tv_guide() - Source: {tv_guide_source}", xbmc.LOGINFO)

    if tv_guide_source == 'Trakt Collection':
        # Get shows from collection
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay TV Guide', 'Loading TV shows from your collection...')

        shows = get_tv_collection_items()
        progress.close()

        if not shows:
            xbmcgui.Dialog().ok('No TV Shows', 'No TV shows found in your Trakt collection.')
            return

        # Collection has no user/list_id
        user = ''
        list_id = ''
        xbmc.log(f"DogPlay: show_tv_guide() - Using Collection (no user/list)", xbmc.LOGINFO)
    else:
        # Get the list to use (Trakt List mode)
        # Show list selection
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay', 'Fetching your Trakt lists...')

        lists = get_trakt_lists()
        progress.close()

        if not lists:
            return

        list_names = [l.get('name', 'Unnamed List') for l in lists]
        selected = xbmcgui.Dialog().select('Select a Trakt List for TV Guide', list_names)

        if selected < 0:
            return

        selected_list = lists[selected]
        user = selected_list.get('user', {}).get('ids', {}).get('slug')
        list_id = selected_list.get('ids', {}).get('trakt')

        if not user or not list_id:
            return

        xbmc.log(f"DogPlay: show_tv_guide() - Using List (user='{user}', list_id='{list_id}')", xbmc.LOGINFO)

        # Get shows from the list
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay TV Guide', 'Loading TV shows from your list...')

        shows = get_tv_list_items(user, list_id)
        progress.close()

        if not shows:
            xbmcgui.Dialog().ok('No TV Shows', 'No TV shows found in the list.')
            return

    # Show the guide - pass the actual user and list_id
    from resources.lib.tv_guide import show_tv_guide
    xbmc.log(f"DogPlay: show_tv_guide() - Calling tv_guide.show_tv_guide() with user='{user}', list_id='{list_id}'", xbmc.LOGINFO)
    show_tv_guide(shows, user, list_id)

def select_list():
    """Show list selection dialog or use saved list based on settings"""
    if not check_fenlight_auth():
        return

    list_mode = get_addon_setting('list_mode', 'string')

    if list_mode == 'single':
        # Use saved list
        user = get_addon_setting('saved_list_user', 'string')
        list_id = get_addon_setting('saved_list_id', 'string')

        if not user or not list_id:
            xbmcgui.Dialog().ok('No Saved List',
                              'No list configured. Please go to Settings > List Settings and click "Select Trakt List".')
            return

        play_random_movie(user, list_id)
    else:
        # Show list selection dialog
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay', 'Fetching your Trakt lists...')

        lists = get_trakt_lists()
        progress.close()

        if not lists:
            return

        # Create list selection dialog
        list_names = [l.get('name', 'Unnamed List') for l in lists]
        selected = xbmcgui.Dialog().select('Select a Trakt List', list_names)

        if selected < 0:
            return

        # Get selected list details
        selected_list = lists[selected]
        user = selected_list.get('user', {}).get('ids', {}).get('slug')
        list_id = selected_list.get('ids', {}).get('trakt')
        list_name = selected_list.get('name', 'Unknown List')

        if user and list_id:
            # Save the list info to settings for easy access
            addon.setSetting('saved_list_user', user)
            addon.setSetting('saved_list_id', str(list_id))
            addon.setSetting('saved_list_name', list_name)
            play_random_movie(user, list_id)

def open_settings():
    """Open addon settings"""
    addon.openSettings()
    # Refresh the list to update dynamic labels
    xbmc.executebuiltin('Container.Refresh')

def show_movie_guide():
    """Show the EPG-style movie guide"""
    if not check_fenlight_auth():
        return

    # Check guide source setting
    guide_source = get_addon_setting('guide_source', 'string')

    if guide_source == 'Trakt Collection':
        # Get movies from collection
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading movies from your collection...')

        movies = get_collection_items()
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in your Trakt collection.')
            return
    elif guide_source == 'Top 1000 Movies of all Time':
        # Get movies from Top 1000 list
        user = 'reallyjosh'
        list_id = 'top-1-000-movies-on-imdb'
        
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading Top 1000 Movies...')

        movies = get_list_items(user, list_id)
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in the Top 1000 list.')
            return
    elif guide_source == 'Action, Adventure & War Movies/TV':
        # Get movies from Action, Adventure & War list
        user = 'jmillz'
        list_id = 'action-adventure-war-movies-tv'

        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading Action, Adventure & War Movies/TV...')

        movies = get_list_items(user, list_id)
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in the Action, Adventure & War list.')
            return
    elif guide_source == 'All Out 80s':
        # Get movies from All Out 80s list
        user = 'fritzi1221'
        list_id = 'all-out-80s'

        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading All Out 80s...')

        movies = get_list_items(user, list_id)
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in the All Out 80s list.')
            return
    elif guide_source == 'Omakase':
        # Get movies from Omakase (local curated list)
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading Omakase collection...')

        movies = local_lists.get_local_list('movie')

        if not movies:
            progress.close()
            xbmcgui.Dialog().ok('List Not Available', 'The Omakase list has not been created yet. Please build it using the list builder tool.')
            return

        # Convert local list format to match expected format
        # Local list has: {tmdb_id, title, year, rating, ...}
        # Expected format has: {media_ids: {tmdb: ...}, title, ...}
        converted_movies = []
        total_movies = len(movies)

        for idx, movie in enumerate(movies):
            tmdb_id = movie.get('tmdb_id')

            # Update progress every 10 movies
            if idx % 10 == 0:
                progress.update(int((idx / total_movies) * 100), f'Converting movie IDs... {idx}/{total_movies}')

            # If tmdb_id is actually an IMDB ID (starts with 'tt'), convert it
            if tmdb_id and str(tmdb_id).startswith('tt'):
                try:
                    from apis.tmdb_api import movie_external_id
                    api_key = tmdb_api_key()
                    import requests
                    find_url = f"https://api.themoviedb.org/3/find/{tmdb_id}"
                    response = requests.get(find_url, params={'api_key': api_key, 'external_source': 'imdb_id'})
                    result = response.json()
                    if result.get('movie_results'):
                        tmdb_id = str(result['movie_results'][0]['id'])
                except Exception as e:
                    xbmc.log(f"DogPlay: Error converting IMDB ID in guide: {e}", xbmc.LOGWARNING)
                    continue

            converted_movies.append({
                'media_ids': {'tmdb': tmdb_id},
                'title': movie.get('title'),
                'year': movie.get('year'),
                'rating': movie.get('rating'),
                'genres': movie.get('genres', [])
            })

        progress.close()
        movies = converted_movies
    else:
        # Get the list to use (Trakt List mode)
        list_mode = get_addon_setting('list_mode', 'string')

        if list_mode == 'single':
            user = get_addon_setting('saved_list_user', 'string')
            list_id = get_addon_setting('saved_list_id', 'string')

            if not user or not list_id:
                xbmcgui.Dialog().ok('No Saved List',
                                  'Please configure a list in Settings first.')
                return
        else:
            # Show list selection
            progress = xbmcgui.DialogProgress()
            progress.create('DogPlay', 'Fetching your Trakt lists...')

            lists = get_trakt_lists()
            progress.close()

            if not lists:
                return

            list_names = [l.get('name', 'Unnamed List') for l in lists]
            selected = xbmcgui.Dialog().select('Select a Trakt List for Movie Guide', list_names)

            if selected < 0:
                return

            selected_list = lists[selected]
            user = selected_list.get('user', {}).get('ids', {}).get('slug')
            list_id = selected_list.get('ids', {}).get('trakt')

            if not user or not list_id:
                return

        # Get movies from the list
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading movies from your list...')

        movies = get_list_items(user, list_id)
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in the list.')
            return

    # Show the guide
    from resources.lib.movie_guide import show_movie_guide
    source_type = 'omakase' if guide_source == 'Omakase' else 'trakt'
    show_movie_guide(movies, source_type=source_type)

def get_recently_watched_items():
    """Get recently watched movies from Trakt"""
    try:
        # Fetch recently watched from Trakt using FenlightAM's API
        # Manual implementation using call_trakt since get_trakt_history is missing
        params = {'extended': 'full', 'limit': 50}
        result = trakt_api.call_trakt('sync/history/movies', params=params)

        if not result:
            xbmcgui.Dialog().ok('No History', 'No recently watched movies found.')
            return []

        items = []
        for c, i in enumerate(result):
            try:
                if i['type'] == 'movie':
                    items.append({
                        'media_ids': i['movie']['ids'],
                        'title': i['movie']['title'],
                        'overview': i['movie'].get('overview', ''),
                        'year': i['movie'].get('year', ''),
                        'rating': i['movie'].get('rating', ''),
                        'watched_at': i.get('watched_at')
                    })
            except: pass

        if not items:
            xbmcgui.Dialog().ok('No History', 'No recently watched movies found.')
            return []

        return items
    except Exception as e:
        xbmc.log(f"DogPlay: Failed to fetch recently watched: {str(e)}", xbmc.LOGERROR)
        return []

def play_from_history_movie(tmdb_id, title=''):
    """Play a movie from history using FenLight"""
    try:
        # Use RunPlugin to trigger FenLight playback
        fenlight_url = f'plugin://plugin.video.fenlight/?mode=playback.media&media_type=movie&tmdb_id={tmdb_id}'
        xbmc.log(f"DogPlay: Playing from history - {title} (TMDB: {tmdb_id})", xbmc.LOGINFO)
        xbmc.executebuiltin(f'RunPlugin({fenlight_url})')
    except Exception as e:
        xbmc.log(f"DogPlay: Error playing from history: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Playback Error', f'Failed to play movie: {str(e)}')

def show_recently_watched(addon_handle, base_url):
    """Show Recently Watched movies list - Redirect to FenLight"""
    if not check_fenlight_auth():
        return
    
    # Redirect to FenLight's native Recently Watched view
    # This allows playback to work properly
    fenlight_url = 'plugin://plugin.video.fenlight/?mode=build_movie_list&action=recent_watched_movies'
    xbmc.executebuiltin(f'Container.Update({fenlight_url}, false)')


def main_menu(addon_handle, base_url):
    """Display main menu"""
    if not check_fenlight_auth():
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return


    # Common artwork
    addon_dir = addon.getAddonInfo('path')
    icon = os.path.join(addon_dir, 'icon.png')
    
    # Get dynamic settings
    list_mode = get_addon_setting('list_mode', 'string')
    saved_list_name = get_addon_setting('saved_list_name', 'string')
    guide_source = get_addon_setting('guide_source', 'string')
    show_movie_collection = get_addon_setting('show_movie_collection')
    show_tv_collection = get_addon_setting('show_tv_collection')

    # Set plugin category
    xbmcplugin.setPluginCategory(addon_handle, "Main Menu")

    # ========== MOVIES SECTION ==========
    # 1. Random Movie (List)
    play_title = 'Random Movie (List)'
    play_plot = 'Select a Trakt list and play a random movie from it.'
    if list_mode == 'single' and saved_list_name:
        play_title = f'Random Movie ({saved_list_name})'
        play_plot = f"Play a random movie from your saved list: '{saved_list_name}'."

    li = xbmcgui.ListItem(play_title)
    li.setInfo('video', {'title': play_title, 'plot': play_plot})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=select_list'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # 2. Random Movie (Collection) - only if enabled
    if show_movie_collection:
        li = xbmcgui.ListItem('Random Movie (Collection)')
        li.setInfo('video', {'title': 'Random Movie (Collection)', 'plot': 'Play a random movie from your personal Trakt collection.'})
        li.setArt({'icon': icon, 'thumb': icon})
        url = f'{base_url}?action=play_collection'
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=url,
            listitem=li,
            isFolder=False
        )

    # 2.5 Custom Lists Iteration (Moved above Movie Guide)
    # Add Omakase (local list) first if enabled
    try:
        omakase_enabled = get_addon_setting('omakase_enabled')
        xbmc.log(f"DogPlay: Omakase enabled={omakase_enabled}", xbmc.LOGINFO)
        if omakase_enabled:
            # Check if the list file exists
            if local_lists.local_list_exists('movie'):
                list_info = local_lists.get_local_list_info('movie')
                list_name = list_info.get('name', 'Omakase') if list_info else 'Omakase'
                item_count = list_info.get('total_items', 0) if list_info else 0

                li = xbmcgui.ListItem('Random Movies (Omakase)')
                plot_text = f'Play a random movie from your curated collection: {list_name}'
                if item_count > 0:
                    plot_text += f' ({item_count} movies)'
                li.setInfo('video', {
                    'title': 'Random Movies (Omakase)',
                    'plot': plot_text
                })
                li.setArt({'icon': icon, 'thumb': icon})
                url = f'{base_url}?action=play_local_list'
                xbmcplugin.addDirectoryItem(
                    handle=addon_handle,
                    url=url,
                    listitem=li,
                    isFolder=False
                )
                xbmc.log(f"DogPlay: Added Omakase menu item", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay: Omakase enabled but list file not found", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"DogPlay: Error loading Omakase: {str(e)}", xbmc.LOGERROR)

    # Add Trakt custom lists
    for i in range(1, 6):
        try:
            enabled = get_addon_setting(f'custom_list_{i}_enabled')
            xbmc.log(f"DogPlay: Custom list {i} enabled={enabled}", xbmc.LOGINFO)
            if enabled:
                list_name = get_addon_setting(f'custom_list_{i}_name', 'string')
                list_user = get_addon_setting(f'custom_list_{i}_user', 'string')
                list_id = get_addon_setting(f'custom_list_{i}_id', 'string')

                xbmc.log(f"DogPlay: Custom list {i} - name='{list_name}', user='{list_user}', id='{list_id}'", xbmc.LOGINFO)

                if list_name and list_user and list_id:
                    li = xbmcgui.ListItem(f'Random Movie ({list_name})')
                    li.setInfo('video', {
                        'title': f'Random Movie ({list_name})',
                        'plot': f'Play a random movie from custom list: {list_name}'
                    })
                    li.setArt({'icon': icon, 'thumb': icon})
                    url = f'{base_url}?action=play_custom_list&user={list_user}&list_id={list_id}'
                    xbmcplugin.addDirectoryItem(
                        handle=addon_handle,
                        url=url,
                        listitem=li,
                        isFolder=False
                    )
                    xbmc.log(f"DogPlay: Added custom list menu item: {list_name}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay: Error loading custom list {i}: {str(e)}", xbmc.LOGERROR)

    # 3. Movie Guide
    guide_plot = 'Browse movies in an EPG-style guide format.'
    if guide_source:
        guide_plot = f'Browse movies from your {guide_source} in an EPG-style guide format.'

    li = xbmcgui.ListItem('Movie Guide')
    li.setInfo('video', {'title': 'Movie Guide', 'plot': guide_plot})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=movie_guide'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # ========== TV SHOWS SECTION ==========
    # Blank line separator before TV section (non-focusable)
    li = xbmcgui.ListItem(' ')
    li.setInfo('video', {'title': ' ', 'plot': ''})
    li.setArt({'icon': icon, 'thumb': icon})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url='noop',  # Non-playable URL
        listitem=li,
        isFolder=True  # Changed to folder to prevent playback attempts
    )

    # 4. Random TV Show (List)
    li = xbmcgui.ListItem('Random TV Show (List)')
    li.setInfo('video', {'title': 'Random TV Show (List)', 'plot': 'Select a Trakt list and play a random episode from a random TV show.'})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=select_tv_list'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # 5. Random TV Show (Collection) - only if enabled
    if show_tv_collection:
        li = xbmcgui.ListItem('Random TV Show (Collection)')
        li.setInfo('video', {'title': 'Random TV Show (Collection)', 'plot': 'Play a random episode from your personal Trakt TV collection.'})
        li.setArt({'icon': icon, 'thumb': icon})
        url = f'{base_url}?action=play_tv_collection'
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=url,
            listitem=li,
            isFolder=False
        )

    # 6. TV Guide
    tv_guide_source = get_addon_setting('tv_guide_source', 'string')
    tv_guide_plot = 'Browse TV shows in an EPG-style guide format.'
    if tv_guide_source:
        tv_guide_plot = f'Browse TV shows from your {tv_guide_source} in an EPG-style guide format.'

    li = xbmcgui.ListItem('TV Guide')
    li.setInfo('video', {'title': 'TV Guide', 'plot': tv_guide_plot})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=tv_guide'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # 99. Settings
    li = xbmcgui.ListItem('Settings')
    li.setInfo('video', {'title': 'Settings', 'plot': 'Configure DogPlay options, manage lists, and adjust playback preferences.'})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=settings'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # Force insertion order (no sorting) - must be called before endOfDirectory
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED)

    # Revert to standard behavior (updateListing=False is the key fix for duplicates)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
