# Curated Movies

Handpicked movies for DogPlay

**Total items:** 212

---

1. **Airplane!** (1980) — TMDB: 813 — Rating: PG — Genres: Comedy

> An ex-fighter pilot forced to take over the controls of an airliner when the flight crew succumbs to food poisoning.

2. **Alien** (1979) — TMDB: 348 — Rating: R — Genres: Horror, Science Fiction

> During its return to the earth, commercial spaceship Nostromo intercepts a distress signal from a distant planet. When a three-member team of the crew discovers a chamber containing thousands of eggs on the planet, a creature inside one of the eggs attacks an explorer. The entire crew is unaware...

3. **Aliens** (1986) — TMDB: 679 — Rating: R — Genres: Action, Thriller, Science Fiction

> Ripley, the sole survivor of the Nostromo's deadly encounter with the monstrous Alien, returns to Earth after drifting through space in hypersleep for 57 years. Although her story is initially met with skepticism, she agrees to accompany a team of Colonial Marines back to LV-426.

4. **Almost Famous** (2000) — TMDB: 786 — Rating: R — Genres: Drama, Music

> In 1973, 15-year-old William Miller's unabashed love of music and aspiration to become a rock journalist lands him an assignment from Rolling Stone magazine to interview and tour with the up-and-coming band, Stillwater.

5. **Amadeus** (1984) — TMDB: 279 — Rating: PG — Genres: History, Music, Drama

> Disciplined Italian composer Antonio Salieri becomes consumed by jealousy and resentment towards the hedonistic and remarkably talented young Salzburger composer Wolfgang Amadeus Mozart.

6. **Apollo 13** (1995) — TMDB: 568 — Rating: PG — Genres: Drama, History

> The true story of technical troubles that scuttle the Apollo 13 lunar mission in 1970, risking the lives of astronaut Jim Lovell and his crew, with the failed journey turning into a thrilling saga of heroism. Drifting more than 200,000 miles from Earth, the astronauts work furiously with the...

7. **Armageddon** (1998) — TMDB: 95 — Rating: PG-13 — Genres: Action, Thriller, Science Fiction, Adventure

> When an asteroid threatens to collide with Earth, NASA honcho Dan Truman determines the only way to stop it is to drill into its surface and detonate a nuclear bomb. This leads him to renowned driller Harry Stamper, who agrees to helm the dangerous space mission provided he can bring along his...

8. **Austin Powers: International Man of Mystery** (1997) — TMDB: 816 — Rating: PG-13 — Genres: Science Fiction, Comedy, Crime

> As a swinging fashion photographer by day and a groovy British superagent by night, Austin Powers is the '60s' most shagadelic spy. But can he stop megalomaniac Dr. Evil after the bald villain freezes himself and unthaws in the '90s? With the help of sexy sidekick Vanessa Kensington, he just might.

9. **Austin Powers: The Spy Who Shagged Me** (1999) — TMDB: 817 — Rating: PG-13 — Genres: Adventure, Comedy, Crime, Science Fiction

> When diabolical genius Dr. Evil travels back in time to steal superspy Austin Powers's ‘mojo,’ Austin must return to the swingin' '60s himself - with the help of American agent, Felicity Shagwell - to stop the dastardly plan. Once there, Austin faces off against Dr. Evil's army of minions to try...

10. **Avengers: Endgame** (2019) — TMDB: 299534 — Rating: PG-13 — Genres: Adventure, Science Fiction, Action

> After the devastating events of Avengers: Infinity War, the universe is in ruins due to the efforts of the Mad Titan, Thanos. With the help of remaining allies, the Avengers must assemble once more in order to undo Thanos' actions and restore order to the universe once and for all, no matter...

11. **Avengers: Infinity War** (2018) — TMDB: 299536 — Rating: PG-13 — Genres: Adventure, Action, Science Fiction

> As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and...

12. **Baby Driver** (2017) — TMDB: 339403 — Rating: R — Genres: Action, Crime

> After being coerced into working for a crime boss, a young getaway driver finds himself taking part in a heist doomed to fail.

13. **Back to School** (1986) — TMDB: 15596 — Rating: PG-13 — Genres: Comedy

> Self-made millionaire Thornton Melon decides to get a better education and enrolls at his son Jason's college. While Jason tries to fit in with his fellow students, Thornton struggles to gain his son's respect, giving way to hilarious antics.

14. **Back to the Beach** (1987) — TMDB: 26477 — Rating: PG — Genres: Comedy, Music

> Cowabunga! The surfing '60s ride into the new wave as Frankie and Annette star in this hip update of their old-time, good-time beach movies. With special appearances by Bob Denver, Tony Dow, Pee-Wee Herman, Jerry Mathers and other familiar faces. Frankie and Annette grow up and have kids in the...

15. **Back to the Future** (1985) — TMDB: 105 — Rating: PG — Genres: Adventure, Comedy, Science Fiction

> Eighties teenager Marty McFly is accidentally sent back in time to 1955, inadvertently disrupting his parents' first meeting and attracting his mother's romantic interest. Marty must repair the damage to history by rekindling his parents' romance and - with the help of his eccentric inventor...

16. **Beetlejuice** (1988) — TMDB: 4011 — Rating: PG — Genres: Fantasy, Comedy

> A newly dead New England couple seeks help from a deranged demon exorcist to scare an affluent New York family out of their home.

17. **Big Trouble in Little China** (1986) — TMDB: 6978 — Rating: PG-13 — Genres: Action, Comedy, Fantasy, Adventure

> Truck driver Jack Burton gets embroiled in a supernatural battle when his best friend Wang Chi's green-eyed fiancée is kidnapped by henchmen of the sorcerer Lo Pan, who must marry a girl with green eyes in order to return to the human realm.

18. **Blades of Glory** (2007) — TMDB: 9955 — Rating: PG-13 — Genres: Comedy

> When a much-publicized ice-skating scandal strips them of their gold medals, two world-class athletes skirt their way back onto the ice via a loophole that allows them to compete together as a pairs team.

19. **Boogie Nights** (1997) — TMDB: 4995 — Rating: R — Genres: Drama

> Set in 1977, back when sex was safe, pleasure was a business and business was booming, idealistic porn producer Jack Horner aspires to elevate his craft to an art form. Horner discovers Eddie Adams, a hot young talent working as a busboy in a nightclub, and welcomes him into the extended family...

20. **Braveheart** (1995) — TMDB: 197 — Rating: R — Genres: Action, Drama, History, War

> Enraged at the slaughter of Murron, his new bride and childhood love, Scottish warrior William Wallace slays a platoon of the local English lord's soldiers. This leads the village to revolt and, eventually, the entire country to rise up against English rule.

21. **Captain America: Civil War** (2016) — TMDB: 271110 — Rating: PG-13 — Genres: Adventure, Action, Science Fiction

> Following the events of Age of Ultron, the collective governments of the world pass an act designed to regulate all superhuman activity. This polarizes opinion amongst the Avengers, causing two factions to side with Iron Man or Captain America, which causes an epic battle between former allies.

22. **Captain America: The Winter Soldier** (2014) — TMDB: 100402 — Rating: PG-13 — Genres: Action, Adventure, Science Fiction

> After the cataclysmic events in New York with The Avengers, Steve Rogers, aka Captain America is living quietly in Washington, D.C. and trying to adjust to the modern world. But when a S.H.I.E.L.D. colleague comes under attack, Steve becomes embroiled in a web of intrigue that threatens to put...

23. **Casino** (1995) — TMDB: 524 — Rating: R — Genres: Crime, Drama

> In Las Vegas, two best friends--a casino executive and a Mafia enforcer--compete for a gambling empire and a fast-living, fast-loving socialite.

24. **Catch Me If You Can** (2002) — TMDB: 640 — Rating: PG-13 — Genres: Drama, Crime

> A true story about Frank Abagnale Jr. who, before his 19th birthday, successfully conned millions of dollars worth of checks as a Pan Am pilot, doctor, and legal prosecutor. An FBI agent makes it his mission to put him behind bars. But Frank not only eludes capture, he revels in the pursuit.

25. **Clue** (1985) — TMDB: 15196 — Rating: PG — Genres: Comedy, Thriller, Crime, Mystery

> Clue finds six colorful dinner guests gathered at the mansion of their host, Mr. Boddy -- who turns up dead after his secret is exposed: He was blackmailing all of them. With the killer among them, the guests and Boddy's chatty butler must suss out the culprit before the body count rises.

26. **Coco** (2017) — TMDB: 354912 — Rating: PG — Genres: Family, Animation, Music, Adventure

> Despite his family’s baffling generations-old ban on music, Miguel dreams of becoming an accomplished musician like his idol, Ernesto de la Cruz. Desperate to prove his talent, Miguel finds himself in the stunning and colorful Land of the Dead following a mysterious chain of events. Along the...

27. **Collateral** (2004) — TMDB: 1538 — Rating: R — Genres: Drama, Crime, Thriller

> Cab driver Max picks up a man who offers him $600 to drive him around. But the promise of easy money sours when Max realizes his fare is an assassin.

28. **Coming to America** (1988) — TMDB: 9602 — Rating: R — Genres: Comedy, Romance

> An African prince decides it’s time for him to find a princess... and his mission leads him and his most loyal friend to Queens, New York. In disguise as an impoverished immigrant, the pampered prince quickly finds himself a new job, new friends, new digs, new enemies and lots of trouble.

29. **Contagion** (2011) — TMDB: 39538 — Rating: PG-13 — Genres: Drama, Thriller, Science Fiction

> As an epidemic of a lethal airborne virus - that kills within days - rapidly grows, the worldwide medical community races to find a cure and control the panic that spreads faster than the virus itself.

30. **Crimson Tide** (1995) — TMDB: 8963 — Rating: R — Genres: Thriller, Action, Drama, War

> After the Cold War, a breakaway Russian republic with nuclear warheads becomes a possible worldwide threat. U.S. submarine Capt. Frank Ramsey signs on a relatively green but highly recommended Lt. Cmdr. Ron Hunter to the USS Alabama, which may be the only ship able to stop a possible Armageddon....

31. **Crouching Tiger, Hidden Dragon** (2000) — TMDB: 146 — Rating: PG-13 — Genres: Adventure, Drama, Action, Romance

> Two warriors in pursuit of a stolen sword and a notorious fugitive are led to an impetuous, physically-skilled, teenage nobleman's daughter, who is at a crossroads in her life.

32. **Dave** (1993) — TMDB: 11566 — Rating: PG-13 — Genres: Comedy

> A sweet-natured Temp Agency operator and amateur Presidential look-alike is recruited by the Secret Service to become a temporary stand-in for the President of the United States.

33. **Dead Poets Society** (1989) — TMDB: 207 — Rating: PG — Genres: Drama

> At an elite, old-fashioned boarding school in New England, a passionate English teacher inspires his students to rebel against convention and seize the potential of every day, courting the disdain of the stern headmaster.

34. **Die Hard** (1988) — TMDB: 562 — Rating: R — Genres: Action, Thriller

> NYPD cop John McClane's plan to reconcile with his estranged wife is thrown for a serious loop when, minutes after he arrives at her office's Christmas Party, the entire building is overtaken by a group of terrorists. With little help from the LAPD, wisecracking McClane sets out to...

35. **Dirty Rotten Scoundrels** (1988) — TMDB: 10141 — Rating: PG — Genres: Comedy, Crime

> Con artist Lawrence Jamieson is a longtime resident of a luxurious coastal resort, where he enjoys the lavish fruits of his deceptions -- that is, until a competitor, Freddy Benson, shows up. When the new guy's lowbrow tactics impinge on his own sophisticated work and believing him to be the...

36. **District 9** (2009) — TMDB: 17654 — Rating: R — Genres: Science Fiction

> Thirty years ago, aliens arrive on Earth. Not to conquer or give aid, but to find refuge from their dying planet. Separated from humans in a South African area called District 9, the aliens are managed by Multi-National United, which is unconcerned with the aliens' welfare but will do anything...

37. **Django Unchained** (2012) — TMDB: 68718 — Rating: R — Genres: Drama, Western

> With the help of a German bounty hunter, a freed slave sets out to rescue his wife from a brutal Mississippi plantation owner.

38. **Dune** (2021) — TMDB: 438631 — Rating: PG-13 — Genres: Science Fiction, Adventure

> Paul Atreides, a brilliant and gifted young man born into a great destiny beyond his understanding, must travel to the most dangerous planet in the universe to ensure the future of his family and his people. As malevolent forces explode into conflict over the planet's exclusive supply of the...

39. **Dune** (1984) — TMDB: 841 — Rating: PG-13 — Genres: Action, Science Fiction, Adventure

> In the year 10,191, the most precious substance in the universe is the spice Melange. The spice extends life. The spice expands consciousness. The spice is vital to space travel.  The spice exists on only one planet in the entire universe, the vast desert planet Arrakis, also known as Dune.  Its...

40. **Dune: Part Two** (2024) — TMDB: 693134 — Rating: PG-13 — Genres: Science Fiction, Adventure

> Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a path of revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the known universe, Paul endeavors to prevent a terrible future only he can...

41. **Edge of Tomorrow** (2014) — TMDB: 137113 — Rating: PG-13 — Genres: Action, Science Fiction

> Major Bill Cage is an officer who has never seen a day of combat when he is unceremoniously demoted and dropped into combat. Cage is killed within minutes, managing to take an alpha alien down with him. He awakens back at the beginning of the same day and is forced to fight and die again... and...

42. **Ex Machina** (2015) — TMDB: 264660 — Rating: R — Genres: Drama, Science Fiction

> Caleb, a coder at the world's largest internet company, wins a competition to spend a week at a private mountain retreat belonging to Nathan, the reclusive CEO of the company. But when Caleb arrives at the remote location he finds that he will have to participate in a strange and fascinating...

43. **Ferris Bueller's Day Off** (1986) — TMDB: 9377 — Rating: PG-13 — Genres: Comedy

> After high school slacker Ferris Bueller successfully fakes an illness in order to skip school for the day, he goes on a series of adventures throughout Chicago with his girlfriend Sloane and best friend Cameron, all the while trying to outwit his wily school principal and fed-up sister.

44. **Fight Club** (1999) — TMDB: 550 — Rating: R — Genres: Drama, Thriller

> A ticking-time-bomb insomniac and a slippery soap salesman channel primal male aggression into a shocking new form of therapy. Their concept catches on, with underground "fight clubs" forming in every town, until an eccentric gets in the way and ignites an out-of-control spiral toward oblivion.

45. **Flight of the Navigator** (1986) — TMDB: 10122 — Rating: PG — Genres: Family, Science Fiction, Adventure

> 12-year-old David is accidentally knocked out in the forest near his home, but when he awakens eight years have passed. His family is overjoyed to have him back, but is just as perplexed as he is that he hasn't aged. When a NASA scientist discovers a UFO nearby, David gets the chance to unravel...

46. **Ford v Ferrari** (2019) — TMDB: 359724 — Rating: PG-13 — Genres: Drama, Action, History

> American car designer Carroll Shelby and the British-born driver Ken Miles work together to battle corporate interference, the laws of physics, and their own personal demons to build a revolutionary race car for Ford Motor Company and take on the dominating race cars of Enzo Ferrari at the 24...

47. **Forrest Gump** (1994) — TMDB: 13 — Rating: PG-13 — Genres: Comedy, Drama, Romance

> A man with a low IQ has accomplished great things in his life and been present during significant historic events—in each case, far exceeding what anyone imagined he could do. But despite all he has achieved, his one true love eludes him.

48. **Full Metal Jacket** (1987) — TMDB: 600 — Rating: R — Genres: Drama, War

> A pragmatic U.S. Marine observes the dehumanizing effects the U.S.-Vietnam War has on his fellow recruits from their brutal boot camp training to the bloody street fighting in Hue.

49. **Gangs of New York** (2002) — TMDB: 3131 — Rating: R — Genres: Drama, History, Crime

> In early 1860s New York, Irish immigrant Amsterdam Vallon is released from prison and returns to the Five Points, seeking revenge against his father's killer, William Cutting, a powerful anti-immigrant gang leader. He knows that revenge can only be attained by infiltrating Cutting's inner...

50. **Ghostbusters** (1984) — TMDB: 620 — Rating: PG — Genres: Comedy, Fantasy

> After losing their academic posts at a prestigious university, a team of parapsychologists goes into business as proton-pack-toting "ghostbusters" who exterminate ghouls, hobgoblins and supernatural pests of all stripes. An ad campaign pays off when a knockout cellist hires the squad to purge...

51. **Gladiator** (2000) — TMDB: 98 — Rating: R — Genres: Action, Drama, Adventure

> After the death of Emperor Marcus Aurelius, his devious son takes power and demotes Maximus, one of Rome's most capable generals who Marcus preferred. Eventually, Maximus is forced to become a gladiator and battle to the death against other men for the amusement of paying audiences.

52. **Glory** (1989) — TMDB: 9665 — Rating: R — Genres: Drama, History, War

> Robert Gould Shaw leads the US Civil War's first all-black volunteer company, fighting prejudices of both his own Union army and the Confederates.

53. **Good Will Hunting** (1997) — TMDB: 489 — Rating: R — Genres: Drama

> Will Hunting is a headstrong, working-class genius who is failing the lessons of life. After one too many run-ins with the law, Will's last chance is a psychology professor, who might be the only man who can reach him.

54. **GoodFellas** (1990) — TMDB: 769 — Rating: R — Genres: Drama, Crime

> The true story of Henry Hill, a half-Irish, half-Sicilian Brooklyn kid who is adopted by neighbourhood gangsters at an early age and climbs the ranks of a Mafia family under the guidance of Jimmy Conway.

55. **Heat** (1995) — TMDB: 949 — Rating: R — Genres: Crime, Drama, Action

> Obsessive master thief Neil McCauley leads a top-notch crew on various daring heists throughout Los Angeles while determined detective Vincent Hanna pursues him without rest. Each man recognizes and respects the ability and the dedication of the other even though they are aware their...

56. **Highlander** (1986) — TMDB: 8009 — Rating: R — Genres: Adventure, Action, Fantasy

> He fought his first battle on the Scottish Highlands in 1536. He will fight his greatest battle on the streets of New York City in 1986. His name is Connor MacLeod. He is immortal.

57. **Hunter Killer** (2018) — TMDB: 399402 — Rating: R — Genres: Action, Adventure, Thriller

> Captain Glass of the USS Arkansas discovers that a coup d'état is taking place in Russia, so he and his crew join an elite group working on the ground to prevent a war.

58. **Inception** (2010) — TMDB: 27205 — Rating: PG-13 — Genres: Action, Science Fiction, Adventure

> Cobb, a skilled thief who commits corporate espionage by infiltrating the subconscious of his targets is offered a chance to regain his old life as payment for a task considered to be impossible: "inception", the implantation of another person's idea into a target's subconscious.

59. **Indiana Jones and the Last Crusade** (1989) — TMDB: 89 — Rating: PG-13 — Genres: Adventure, Action

> In 1938, an art collector appeals to eminent archaeologist Dr. Indiana Jones to embark on a search for the Holy Grail. Indy learns that a medieval historian has vanished while searching for it, and the missing man is his own father, Dr. Henry Jones Sr.. He sets out to rescue his father by...

60. **Indiana Jones and the Temple of Doom** (1984) — TMDB: 87 — Rating: PG — Genres: Adventure, Action

> After arriving in India, Indiana Jones is asked by a desperate village to find a mystical stone. He agrees – and stumbles upon a secret cult plotting a terrible plan in the catacombs of an ancient palace.

61. **Inglourious Basterds** (2009) — TMDB: 16869 — Rating: R — Genres: Drama, Thriller, War

> In Nazi-occupied France during World War II, a group of Jewish-American soldiers known as "The Basterds" are chosen specifically to spread fear throughout the Third Reich by scalping and brutally killing Nazis. The Basterds, lead by Lt. Aldo Raine soon cross paths with a French-Jewish teenage...

62. **Inside Man** (2006) — TMDB: 388 — Rating: R — Genres: Crime, Drama, Thriller

> When an armed, masked gang enter a Manhattan bank, lock the doors and take hostages, the detective assigned to effect their release enters negotiations preoccupied with corruption charges he is facing.

63. **Interstellar** (2014) — TMDB: 157336 — Rating: PG-13 — Genres: Adventure, Drama, Science Fiction

> The adventures of a group of explorers who make use of a newly discovered wormhole to surpass the limitations on human space travel and conquer the vast distances involved in an interstellar voyage.

64. **Jaws** (1975) — TMDB: 578 — Rating: PG — Genres: Horror, Thriller, Adventure

> When the seaside community of Amity finds itself under attack by a dangerous great white shark, the town's chief of police, a young marine biologist, and a grizzled shark hunter embark on a desperate quest to kill the beast before it strikes again.

65. **John Wick** (2014) — TMDB: 245891 — Rating: R — Genres: Action, Thriller

> Ex-hitman John Wick comes out of retirement to track down the gangsters that took everything from him.

66. **Jurassic Park** (1993) — TMDB: 329 — Rating: PG-13 — Genres: Adventure, Science Fiction

> A wealthy entrepreneur secretly creates a theme park featuring living dinosaurs drawn from prehistoric DNA. Before opening day, he invites a team of experts and his two eager grandchildren to experience the park and help calm anxious investors. However, the park is anything but amusing as the...

67. **Kill Bill: Vol. 1** (2003) — TMDB: 24 — Rating: R — Genres: Action, Crime

> An assassin is shot by her ruthless employer, Bill, and other members of their assassination circle – but she lives to plot her vengeance.

68. **Kill Bill: Vol. 2** (2004) — TMDB: 393 — Rating: R — Genres: Action, Crime, Thriller

> The Bride unwaveringly continues on her roaring rampage of revenge against the band of assassins who had tried to kill her and her unborn child. She visits each of her former associates one-by-one, checking off the victims on her Death List Five until there's nothing left to do … but kill Bill.

69. **Kingsman: The Secret Service** (2015) — TMDB: 207703 — Rating: R — Genres: Crime, Comedy, Action, Adventure

> The story of a super-secret spy organization that recruits an unrefined but promising street kid into the agency's ultra-competitive training program just as a global threat emerges from a twisted tech genius.

70. **Knives Out** (2019) — TMDB: 546554 — Rating: PG-13 — Genres: Comedy, Crime, Mystery

> When renowned crime novelist Harlan Thrombey is found dead at his estate just after his 85th birthday, the inquisitive and debonair Detective Benoit Blanc is mysteriously enlisted to investigate. From Harlan's dysfunctional family to his devoted staff, Blanc sifts through a web of red herrings...

71. **Léon: The Professional** (1994) — TMDB: 101 — Rating: R — Genres: Crime, Drama, Action

> Léon, the top hit man in New York, has earned a rep as an effective "cleaner". But when his next-door neighbors are wiped out by a loose-cannon DEA agent, he becomes the unwilling custodian of 12-year-old Mathilda. Before long, Mathilda's thoughts turn to revenge, and she considers following in...

72. **Mad Max: Fury Road** (2015) — TMDB: 76341 — Rating: R — Genres: Action, Adventure, Science Fiction

> An apocalyptic story set in the furthest reaches of our planet, in a stark desert landscape where humanity is broken, and most everyone is crazed fighting for the necessities of life. Within this world exist two rebels on the run who just might be able to restore order.

73. **Man on Fire** (2004) — TMDB: 9509 — Rating: R — Genres: Action, Drama, Thriller

> Jaded ex-CIA operative John Creasy reluctantly accepts a job as the bodyguard for a 10-year-old girl in Mexico City. They clash at first, but eventually bond, and when she's kidnapped he's consumed by fury and will stop at nothing to save her life.

74. **Master and Commander: The Far Side of the World** (2003) — TMDB: 8619 — Rating: PG-13 — Genres: Adventure, Drama, War

> After an abrupt and violent encounter with a French warship inflicts severe damage upon his ship, a captain of the British Royal Navy begins a chase over two oceans to capture or destroy the enemy, though he must weigh his commitment to duty and ferocious pursuit of glory against the safety of...

75. **Memento** (2000) — TMDB: 77 — Rating: R — Genres: Mystery, Thriller

> Leonard Shelby is tracking down the man who raped and murdered his wife. The difficulty of locating his wife's killer, however, is compounded by the fact that he suffers from a rare, untreatable form of short-term memory loss. Although he can recall details of life before his accident, Leonard...

76. **No Country for Old Men** (2007) — TMDB: 6977 — Rating: R — Genres: Crime, Thriller, Western

> Llewelyn Moss stumbles upon dead bodies, $2 million and a hoard of heroin in a Texas desert, but methodical killer Anton Chigurh comes looking for it, with local sheriff Ed Tom Bell hot on his trail. The roles of prey and predator blur as the violent pursuit of money and justice collide.

77. **Oblivion** (2013) — TMDB: 75612 — Rating: PG-13 — Genres: Action, Science Fiction, Adventure, Mystery

> Jack Harper is one of the last few drone repairmen stationed on Earth. Part of a massive operation to extract vital resources after decades of war with a terrifying threat known as the Scavs, Jack’s mission is nearly complete. His existence is brought crashing down when he rescues a beautiful ...

78. **Ocean's Eleven** (2001) — TMDB: 161 — Rating: PG-13 — Genres: Thriller, Crime

> Less than 24 hours into his parole, charismatic thief Danny Ocean is already rolling out his next plan: In one night, Danny's hand-picked crew of specialists will attempt to steal more than $150 million from three Las Vegas casinos. But to score the cash, Danny risks his chances of reconciling...

79. **Office Space** (1999) — TMDB: 1542 — Rating: R — Genres: Comedy

> A depressed white-collar worker tries hypnotherapy, only to find himself in a perpetual state of devil-may-care bliss that prompts him to start living by his own rules, and hatch a hapless attempt to embezzle money from his soul-killing employers.

80. **Old School** (2003) — TMDB: 11635 — Rating: R — Genres: Comedy

> Three friends attempt to recapture their glory days by opening up a fraternity near their alma mater.

81. **One Crazy Summer** (1986) — TMDB: 18282 — Rating: PG — Genres: Comedy, Romance, Family

> An aspiring teenage cartoonist and his friends come to the aid of a singer trying to save her family property from developers.

82. **Palm Springs** (2020) — TMDB: 587792 — Rating: R — Genres: Comedy, Romance, Science Fiction

> When carefree Nyles and reluctant maid of honor Sarah have a chance encounter at a Palm Springs wedding, things get complicated when they find themselves unable to escape the venue, themselves, or each other.

83. **Pan's Labyrinth** (2006) — TMDB: 1417 — Rating: R — Genres: Fantasy, Drama, War

> In post–civil war Spain, 10-year-old Ofelia moves with her pregnant mother to live under the control of her cruel stepfather. Drawn into a mysterious labyrinth, she meets a faun who reveals that she may be a lost princess from an underground kingdom. To return to her true father, she must...

84. **Pirates of the Caribbean: The Curse of the Black Pearl** (2003) — TMDB: 22 — Rating: PG-13 — Genres: Adventure, Fantasy, Action

> When wily Captain Barbossa steals Jack Sparrow's ship and kidnaps the governor's beautiful daughter, Elizabeth, her childhood friend Will Turner joins forces with Jack to save her and recapture Jack's ship, the Black Pearl.

85. **Point Break** (1991) — TMDB: 1089 — Rating: R — Genres: Action, Thriller, Crime

> In Los Angeles, a gang of bank robbers who call themselves The Ex-Presidents commit their crimes while wearing masks of Reagan, Carter, Nixon and Johnson. Believing that the members of the gang could be surfers, the F.B.I. sends young agent Johnny Utah to the beach undercover to mix with the...

86. **Predator** (1987) — TMDB: 106 — Rating: R — Genres: Science Fiction, Action, Adventure, Thriller

> A team of elite commandos on a secret mission in a Central American jungle come to find themselves hunted by an extraterrestrial warrior.

87. **Princess Mononoke** (1997) — TMDB: 128 — Rating: PG-13 — Genres: Adventure, Fantasy, Animation

> Ashitaka, a prince of the disappearing Emishi people, is cursed by a demonized boar god and must journey to the west to find a cure. Along the way, he encounters San, a young human woman fighting to protect the forest, and Lady Eboshi, who is trying to destroy it. Ashitaka must find a way to...

88. **Pulp Fiction** (1994) — TMDB: 680 — Rating: R — Genres: Thriller, Crime, Comedy

> A burger-loving hit man, his philosophical partner, a drug-addled gangster's moll and a washed-up boxer converge in this sprawling, comedic crime caper. Their adventures unfurl in three stories that ingeniously trip back and forth in time.

89. **Raiders of the Lost Ark** (1981) — TMDB: 85 — Rating: PG — Genres: Adventure, Action

> When Dr. Indiana Jones – the tweed-suited professor who just happens to be a celebrated archaeologist – is hired by the government to locate the legendary Ark of the Covenant, he finds himself up against the entire Nazi regime.

90. **Ratatouille** (2007) — TMDB: 2062 — Rating: G — Genres: Animation, Comedy, Family, Fantasy

> Remy, a resident of Paris, has quite a sophisticated palate. He would love to become a chef so he can create and enjoy culinary masterpieces to his heart's delight. The only problem is, Remy is a rat. When he winds up in the sewer beneath one of Paris' finest restaurants, Remy finds himself...

91. **Ready Player One** (2018) — TMDB: 333339 — Rating: PG-13 — Genres: Adventure, Action, Science Fiction

> When the creator of a popular video game system dies, a virtual contest is created to compete for his fortune.

92. **Real Genius** (1985) — TMDB: 14370 — Rating: PG — Genres: Comedy, Romance, Science Fiction

> When teenage geniuses Mitch Taylor and Chris Knight, working on an advanced laser project, learn that the military wants to use it as a weapon, they decide to thwart the plan.

93. **Remember the Titans** (2000) — TMDB: 10637 — Rating: PG — Genres: Drama

> After leading his football team to 15 winning seasons, coach Bill Yoast is demoted and replaced by Herman Boone – tough, opinionated and as different from the beloved Yoast as he could be. The two men learn to overcome their differences and turn a group of hostile young men into champions.

94. **Return of the Jedi** (1983) — TMDB: 1892 — Rating: PG — Genres: Adventure, Action, Science Fiction

> Luke Skywalker leads a mission to rescue his friend Han Solo from the clutches of Jabba the Hutt, the Emperor prepares to crush the Rebellion with a more powerful Death Star, and the Rebel fleet mounts a massive attack on the space station. Luke Skywalker confronts Darth Vader in a final...

95. **Rogue One: A Star Wars Story** (2016) — TMDB: 330459 — Rating: PG-13 — Genres: Action, Adventure, Science Fiction

> A rogue band of resistance fighters unite for a mission to steal the Death Star plans and bring a new hope to the galaxy.

96. **Rudy** (1993) — TMDB: 14534 — Rating: PG — Genres: Drama, History

> Rudy grew up in a steel mill town where most people ended up working, but wanted to play football at Notre Dame instead. There were only a couple of problems. His grades were a little low, his athletic skills were poor, and he was only half the size of the other players. But he had the drive and...

97. **Rush** (2013) — TMDB: 96721 — Rating: R — Genres: Drama, Action

> In the 1970s, a rivalry propels race car drivers Niki Lauda and James Hunt to fame and glory — until a horrible accident threatens to end it all.

98. **Saturday Night Live: The Best of Will Ferrell** (2002) — TMDB: 289401 — Rating: NR — Genres: Comedy

> The best skits from Will Ferrell's days on Saturday Night Live 1995-2002

99. **Saving Private Ryan** (1998) — TMDB: 857 — Rating: R — Genres: War, Drama, History

> As U.S. troops storm the beaches of Normandy, three brothers lie dead on the battlefield, with a fourth trapped behind enemy lines. Ranger captain John Miller and seven men are tasked with penetrating German-held territory and bringing the boy home.

100. **Scarface** (1983) — TMDB: 111 — Rating: R — Genres: Action, Crime, Drama

> After getting a green card in exchange for assassinating a Cuban government official, Tony Montana stakes a claim on the drug trade in Miami. Viciously murdering anyone who stands in his way, Tony eventually becomes the biggest drug lord in the state, controlling nearly all the cocaine that...

101. **School Ties** (1992) — TMDB: 14684 — Rating: PG-13 — Genres: Drama

> When David Greene receives a football scholarship to a prestigious prep school in the 1950s, he feels pressure to hide the fact that he is Jewish from his classmates and teachers, fearing that they may be anti-Semitic. He quickly becomes the big man on campus thanks to his football skills, but...

102. **Se7en** (1995) — TMDB: 807 — Rating: R — Genres: Crime, Mystery, Thriller

> Two homicide detectives are on a desperate hunt for a serial killer whose crimes are based on the "seven deadly sins" in this dark and haunting film that takes viewers from the tortured remains of one victim to the next. The seasoned Det. Somerset researches each sin in an effort to get inside...

103. **Sicario** (2015) — TMDB: 273481 — Rating: R — Genres: Action, Crime, Thriller

> An idealistic FBI agent is enlisted by a government task force to aid in the escalating war against drugs at the border area between the U.S. and Mexico.

104. **Sin City** (2005) — TMDB: 187 — Rating: R — Genres: Crime, Thriller

> Welcome to Sin City. This town beckons to the tough, the corrupt, the brokenhearted. Some call it dark… Hard-boiled. Then there are those who call it home — Crooked cops, sexy dames, desperate vigilantes. Some are seeking revenge, others lust after redemption, and then there are those hoping for...

105. **SNL: The Best of Adam Sandler** (1999) — TMDB: 290044 — Rating: NR — Genres: Comedy

> Before he was Happy Gilmore, Little Nicky, The Waterboy, or Billy Madison, Adam Sandler was doing Saturday Night Live playing hilarious characters and singing hilarious songs like the Hanukkah song and Christmas song. Watch Adam act in his own star studded way as Canteen Boy, Cajun Man, Opera...

106. **Spaceballs** (1987) — TMDB: 957 — Rating: PG — Genres: Comedy, Science Fiction

> When the nefarious Dark Helmet hatches a plan to snatch Princess Vespa and steal her planet's air, space-bum-for-hire Lone Starr and his clueless sidekick fly to the rescue. Along the way, they meet Yogurt, who puts Lone Starr wise to the power of "The Schwartz." Can he master it in time to save...

107. **Spirited Away** (2001) — TMDB: 129 — Rating: PG — Genres: Animation, Family, Fantasy

> A young girl, Chihiro, becomes trapped in a strange new world of spirits. When her parents undergo a mysterious transformation, she must call upon the courage she never knew she had to free her family.

108. **Stand by Me** (1986) — TMDB: 235 — Rating: R — Genres: Crime, Drama

> After learning that a boy their age has been accidentally killed near their rural homes, four boys decide to go see the body. Gordie, Vern, Chris, and Teddy encounter a mean junk man and a marsh full of leeches, but they also learn more about one another and their very different home lives. Just...

109. **Star Wars** (1977) — TMDB: 11 — Rating: PG — Genres: Adventure, Action, Science Fiction

> Princess Leia is captured and held hostage by the evil Imperial forces in their effort to take over the galactic Empire. Venturesome Luke Skywalker and dashing captain Han Solo team together with the loveable robot duo R2-D2 and C-3PO to rescue the beautiful princess and restore peace and...

110. **Stripes** (1981) — TMDB: 10890 — Rating: R — Genres: Action, Comedy

> Hard-luck cabbie John Winger, directionless after being fired from his job and dumped by his girlfriend, enlists in the U.S. Army with his close pal, Russell Ziskey. After his barely satisfactory performance in basic training, the irreverent Winger emerges as the figurehead for a ragtag band of...

111. **Summer Rental** (1985) — TMDB: 19357 — Rating: PG — Genres: Comedy

> Jack Chester, an overworked air traffic controller, takes his family on vacation to the beach. Things immediately start to go wrong for the Chesters, and steadily get worse. Jack ends up in a feud with a local yachtsman, and has to race him to regain his pride and family's respect.

112. **Team America: World Police** (2004) — TMDB: 3989 — Rating: R — Genres: Adventure, Action, Comedy

> When North Korean ruler Kim Jong-il orchestrates a global terrorist plot, it's up to the heavily armed, highly specialized Team America unit to stop his dastardly scheme. The group, which has recruited troubled Broadway actor Gary Johnston, not only has to face off against Jong-il, but they must...

113. **Terminator 2: Judgment Day** (1991) — TMDB: 280 — Rating: R — Genres: Action, Thriller, Science Fiction

> Ten years after the events of the original, a reprogrammed T-800 is sent back in time to protect young John Connor from the shape-shifting T-1000. Together with his mother Sarah, he fights to stop Skynet from triggering a nuclear apocalypse.

114. **The 'Burbs** (1989) — TMDB: 11974 — Rating: PG — Genres: Comedy, Horror, Thriller

> When secretive new neighbors move in next door, suburbanite Ray Peterson and his friends let their paranoia get the best of them as they start to suspect the newcomers of evildoings and commence an investigation. But it's hardly how Ray, who much prefers drinking beer, reading his newspaper and...

115. **The Beastmaster** (1982) — TMDB: 16441 — Rating: PG — Genres: Fantasy, Adventure, Action

> Dar, is the son of a king, who's hunted by a priest after his birth and grows up in another family. When he becomes a grown man, his new father is murdered by savages and he discovers that he's the ability to communicate with the animals, which leads him on his quest for revenge against his...

116. **The Birdcage** (1996) — TMDB: 11000 — Rating: R — Genres: Comedy

> A gay cabaret owner and his drag queen partner agree to put up a false heterosexual front so that their son can introduce them to his fiancée's conservative parents.

117. **The Dark Knight** (2008) — TMDB: 155 — Rating: PG-13 — Genres: Action, Crime, Thriller

> Batman raises the stakes in his war on crime. With the help of Lt. Jim Gordon and District Attorney Harvey Dent, Batman sets out to dismantle the remaining criminal organizations that plague the streets. The partnership proves to be effective, but they soon find themselves prey to a reign of...

118. **The Departed** (2006) — TMDB: 1422 — Rating: R — Genres: Drama, Thriller, Crime

> To take down South Boston's Irish Mafia, the police send in one of their own to infiltrate the underworld, not realizing the syndicate has done likewise. While an undercover cop curries favor with the mob kingpin, a career criminal rises through the police ranks. But both sides soon discover...

119. **The Devil's Advocate** (1997) — TMDB: 1813 — Rating: R — Genres: Drama, Mystery, Horror

> Aspiring Florida defense lawyer Kevin Lomax accepts a job at a New York law firm. With the stakes getting higher every case, Kevin quickly learns that his boss has something far more evil planned.

120. **The Dirty Dozen** (1967) — TMDB: 1654 — Rating: NR — Genres: Action, Adventure, War

> 12 American military prisoners in World War II are ordered to infiltrate a well-guarded enemy château and kill the Nazi officers vacationing there. The soldiers, most of whom are facing death sentences for a variety of violent crimes, agree to the mission and the possible commuting of their...

121. **The Empire Strikes Back** (1980) — TMDB: 1891 — Rating: PG — Genres: Adventure, Action, Science Fiction

> The epic saga continues as Luke Skywalker, in hopes of defeating the evil Galactic Empire, learns the ways of the Jedi from aging master Yoda. But Darth Vader is more determined than ever to capture Luke. Meanwhile, rebel leader Princess Leia, cocky Han Solo, Chewbacca, and droids C-3PO and...

122. **The Fifth Element** (1997) — TMDB: 18 — Rating: PG-13 — Genres: Science Fiction, Action, Adventure

> In 2257, a taxi driver is unintentionally given the task of saving a young girl who is part of the key that will ensure the survival of humanity.

123. **The Game** (1997) — TMDB: 2649 — Rating: R — Genres: Drama, Thriller, Mystery

> In honor of his birthday, San Francisco banker Nicholas Van Orton, a financial genius and a cold-hearted loner, receives an unusual present from his younger brother, Conrad: a gift certificate to play a unique kind of game. In nary a nanosecond, Nicholas finds himself consumed by a dangerous set...

124. **The Gentlemen** (2020) — TMDB: 522627 — Rating: R — Genres: Comedy, Crime

> American expat Mickey Pearson has built a highly profitable marijuana empire in London. When word gets out that he’s looking to cash out of the business forever it triggers plots, schemes, bribery and blackmail in an attempt to steal his domain out from under him.

125. **The Godfather** (1972) — TMDB: 238 — Rating: R — Genres: Drama, Crime

> Spanning the years 1945 to 1955, a chronicle of the fictional Italian-American Corleone crime family. When organized crime family patriarch, Vito Corleone barely survives an attempt on his life, his youngest son, Michael steps in to take care of the would-be killers, launching a campaign of...

126. **The Godfather Part II** (1974) — TMDB: 240 — Rating: R — Genres: Drama, Crime

> In the continuing saga of the Corleone crime family, a young Vito Corleone grows up in Sicily and in 1910s New York. In the 1950s, Michael Corleone attempts to expand the family business into Las Vegas, Hollywood and Cuba.

127. **The Golden Child** (1986) — TMDB: 10136 — Rating: PG-13 — Genres: Action, Adventure, Comedy

> After a Tibetan boy, the mystical Golden Child, is kidnapped by the evil Sardo Numspa, humankind's fate hangs in the balance. On the other side of the world in Los Angeles, the priestess Kee Nang seeks the Chosen One, who will save the boy from death. When Nang sees social worker Chandler...

128. **The Goonies** (1985) — TMDB: 9340 — Rating: PG — Genres: Adventure, Comedy, Family

> Young teen Mikey Walsh and his friends set off on a quest to find Pirate One-Eyed Willie's treasure in hopes of saving their homes from demolition. However, on their quest to find the treasure, they run into a family of recently escaped criminals, determined to capture the kids and reach the...

129. **The Great Outdoors** (2002) — TMDB: 242937 — Rating: NR

> A look at the 2002 AMA motocross series.

130. **The Green Mile** (1999) — TMDB: 497 — Rating: R — Genres: Fantasy, Drama, Crime

> A supernatural tale set on death row in a Southern prison, where gentle giant John Coffey possesses the mysterious power to heal people's ailments. When the cell block's head guard, Paul Edgecomb, recognizes Coffey's miraculous gift, he tries desperately to help stave off the condemned man's...

131. **The Hundred-Foot Journey** (2014) — TMDB: 228194 — Rating: PG — Genres: Drama, Comedy

> A story centered around an Indian family who moves to France and opens a restaurant across the street from a Michelin-starred French restaurant.

132. **The Hunt for Red October** (1990) — TMDB: 1669 — Rating: PG-13 — Genres: Action, Thriller

> A new technologically-superior Soviet nuclear sub, the Red October, is heading for the U.S. coast under the command of Captain Marko Ramius. The American government thinks Ramius is planning to attack. Lone CIA analyst Jack Ryan has a different idea: he thinks Ramius is planning to defect, but...

133. **The Hurt Locker** (2008) — TMDB: 12162 — Rating: R — Genres: Drama, Thriller, War

> During the Iraq War, a Sergeant recently assigned to an army bomb squad is put at odds with his squad mates due to his maverick way of handling his work.

134. **The Imitation Game** (2014) — TMDB: 205596 — Rating: PG-13 — Genres: History, Drama, Thriller, War

> Based on the real life story of legendary cryptanalyst Alan Turing, the film portrays the nail-biting race against time by Turing and his brilliant team of code-breakers at Britain's top-secret Government Code and Cypher School at Bletchley Park, during the darkest days of World War II.

135. **The Incredibles** (2004) — TMDB: 9806 — Rating: PG — Genres: Action, Adventure, Animation, Family

> Bob Parr has given up his superhero days to log in time as an insurance adjuster and raise his three children with his formerly heroic wife in suburbia. But when he receives a mysterious assignment, it's time to get back into costume.

136. **The Karate Kid** (2010) — TMDB: 38575 — Rating: PG — Genres: Action, Adventure, Drama, Family

> 12-year-old Dre Parker could've been the most popular kid in Detroit, but his mother's latest career move has landed him in China. Dre immediately falls for his classmate Mei Ying but the cultural differences make such a friendship impossible. Even worse, Dre's feelings make him an enemy of the...

137. **The Last Dragon** (1985) — TMDB: 13938 — Rating: PG-13 — Genres: Action, Adventure, Music, Comedy, Drama

> A young man searches for the "master" to obtain the final level of martial arts mastery known as the glow. Along the way he must fight an evil martial arts expert and rescue a beautiful singer from an obsessed music promoter.

138. **The Last Starfighter** (1984) — TMDB: 11884 — Rating: PG — Genres: Adventure, Science Fiction, Action

> Video game expert Alex Rogan finds himself transported to another planet after conquering the video game The Last Starfighter, only to find out it was just a test. He was recruited to join the team of best Starfighters to defend their world from the attack.

139. **The Lego Movie** (2014) — TMDB: 137106 — Rating: PG — Genres: Animation, Family, Adventure, Comedy, Fantasy

> An ordinary Lego mini-figure, mistakenly thought to be the extraordinary MasterBuilder, is recruited to join a quest to stop an evil Lego tyrant from conquering the universe.

140. **The Lord of the Rings: The Fellowship of the Ring** (2001) — TMDB: 120 — Rating: PG-13 — Genres: Adventure, Fantasy, Action

> Young hobbit Frodo Baggins, after inheriting a mysterious ring from his uncle Bilbo, must leave his home in order to keep it from falling into the hands of its evil creator. Along the way, a fellowship is formed to protect the ringbearer and make sure that the ring arrives at its final...

141. **The Lord of the Rings: The Return of the King** (2003) — TMDB: 122 — Rating: PG-13 — Genres: Adventure, Fantasy, Action

> As armies mass for a final battle that will decide the fate of the world--and powerful, ancient forces of Light and Dark compete to determine the outcome--one member of the Fellowship of the Ring is revealed as the noble heir to the throne of the Kings of Men. Yet, the sole hope for triumph over...

142. **The Lord of the Rings: The Two Towers** (2002) — TMDB: 121 — Rating: PG-13 — Genres: Adventure, Fantasy, Action

> Frodo Baggins and the other members of the Fellowship continue on their sacred quest to destroy the One Ring--but on separate paths. Their destinies lie at two towers--Orthanc Tower in Isengard, where the corrupt wizard Saruman awaits, and Sauron's fortress at Barad-dur, deep within the dark...

143. **The Lost Boys** (1987) — TMDB: 1547 — Rating: R — Genres: Horror, Comedy, Thriller, Drama, Romance

> When an unsuspecting town newcomer is drawn to local blood fiends, the Frog brothers and other unlikely heroes gear up to rescue him.

144. **The Martian** (2015) — TMDB: 286217 — Rating: PG-13 — Genres: Drama, Adventure, Science Fiction

> During a manned mission to Mars, Astronaut Mark Watney is presumed dead after a fierce storm and left behind by his crew. But Watney has survived and finds himself stranded and alone on the hostile planet. With only meager supplies, he must draw upon his ingenuity, wit and spirit to subsist and...

145. **The Matrix** (1999) — TMDB: 603 — Rating: R — Genres: Action, Science Fiction

> Set in the 22nd century, The Matrix tells the story of a computer hacker who joins a group of underground insurgents fighting the vast and powerful computers who now rule the earth.

146. **The NeverEnding Story** (1984) — TMDB: 34584 — Rating: PG — Genres: Adventure, Fantasy, Family, Drama

> While hiding from bullies in his school's attic, a young boy discovers the extraordinary land of Fantasia, through a magical book called The Neverending Story. The book tells the tale of Atreyu, a young warrior who, with the help of a luck dragon named Falkor, must save Fantasia from the...

147. **The Prestige** (2006) — TMDB: 1124 — Rating: PG-13 — Genres: Drama, Mystery, Science Fiction

> A mysterious story of two magicians whose intense rivalry leads them on a life-long battle for supremacy -- full of obsession, deceit and jealousy with dangerous and deadly consequences.

148. **The Shawshank Redemption** (1994) — TMDB: 278 — Rating: R — Genres: Drama, Crime

> Imprisoned in the 1940s for the double murder of his wife and her lover, upstanding banker Andy Dufresne begins a new life at the Shawshank prison, where he puts his accounting skills to work for an amoral warden. During his long stretch in prison, Dufresne comes to be admired by the other...

149. **The Silence of the Lambs** (1991) — TMDB: 274 — Rating: R — Genres: Crime, Thriller, Drama

> Clarice Starling is a top student at the FBI's training academy.  Jack Crawford wants Clarice to interview Dr. Hannibal Lecter, a brilliant psychiatrist who is also a violent psychopath, serving life behind bars for various acts of murder and cannibalism.  Crawford believes that Lecter may have...

150. **The Sixth Sense** (1999) — TMDB: 745 — Rating: PG-13 — Genres: Mystery, Thriller, Drama

> Following an unexpected tragedy, child psychologist Malcolm Crowe meets a nine year old boy named Cole Sear, who is hiding a dark secret.

151. **The Terminator** (1984) — TMDB: 218 — Rating: R — Genres: Action, Thriller, Science Fiction

> In the post-apocalyptic future, reigning tyrannical supercomputers teleport a cyborg assassin known as the "Terminator" back to 1984 to kill Sarah Connor, whose unborn son is destined to lead insurgents against 21st century mechanical hegemony. Meanwhile, the human-resistance movement dispatches...

152. **The Thing** (1982) — TMDB: 1091 — Rating: R — Genres: Horror, Mystery, Science Fiction

> A research team in Antarctica is hunted by a shape-shifting alien that assumes the appearance of its victims.

153. **The Town** (2010) — TMDB: 23168 — Rating: R — Genres: Crime, Drama, Thriller

> Doug MacRay is a longtime thief, who, smarter than the rest of his crew, is looking for his chance to exit the game. When a bank job leads to the group kidnapping an attractive branch manager, he takes on the role of monitoring her – but their burgeoning relationship threatens to unveil the...

154. **The Transformers: The Movie** (1986) — TMDB: 1857 — Rating: PG — Genres: Animation, Science Fiction, Action, Adventure, Family

> The Autobots must stop a colossal planet-consuming robot who goes after the Autobot Matrix of Leadership. At the same time, they must defend themselves against an all-out attack from the Decepticons.

155. **The Wolf of Wall Street** (2013) — TMDB: 106646 — Rating: R — Genres: Crime, Drama, Comedy

> A New York stockbroker refuses to cooperate in a large securities fraud case involving corruption on Wall Street, corporate banking world and mob infiltration. Based on Jordan Belfort's autobiography.

156. **There's Something About Mary** (1998) — TMDB: 544 — Rating: R — Genres: Romance, Comedy

> For Ted, prom night went about as bad as it’s possible for any night to go. Thirteen years later, he finally gets another chance with his old prom date, only to run up against other suitors including the sleazy detective he hired to find her.

157. **Tombstone** (1993) — TMDB: 11969 — Rating: R — Genres: Western, Action

> Legendary marshal Wyatt Earp, now a weary gunfighter, joins his brothers Morgan and Virgil to pursue their collective fortune in the thriving mining town of Tombstone. But Earp is forced to don a badge again and get help from his notorious pal Doc Holliday when a gang of renegade brigands and...

158. **Top Gun** (1986) — TMDB: 744 — Rating: PG — Genres: Action, Drama

> For Lieutenant Pete 'Maverick' Mitchell and his friend and co-pilot Nick 'Goose' Bradshaw, being accepted into an elite training school for fighter pilots is a dream come true. But a tragedy, as well as personal demons, will threaten Pete's dreams of becoming an ace pilot.

159. **Top Gun: Maverick** (2022) — TMDB: 361743 — Rating: PG-13 — Genres: Action, Drama

> After more than thirty years of service as one of the Navy’s top aviators, and dodging the advancement in rank that would ground him, Pete “Maverick” Mitchell finds himself training a detachment of TOP GUN graduates for a specialized mission the likes of which no living pilot has ever seen.

160. **Trading Places** (1983) — TMDB: 1621 — Rating: R — Genres: Comedy

> A snobbish investor and a wily street con-artist find their positions reversed as part of a bet by two callous millionaires.

161. **Uncle Buck** (1989) — TMDB: 2616 — Rating: PG — Genres: Comedy, Drama, Family

> Buck Russell, a lovable but slovenly bachelor, suddenly becomes the temporary caretaker of his nephew and nieces after a family emergency. His freewheeling attitude soon causes tension with his older niece Tia, loyal girlfriend Chanice and just about everyone else who crosses his path.

162. **Unforgiven** (1992) — TMDB: 33 — Rating: R — Genres: Western

> William Munny is a retired, once-ruthless killer turned gentle widower and hog farmer. To help support his two motherless children, he accepts one last bounty-hunter mission to find the men who brutalized a prostitute. Joined by his former partner and a cocky greenhorn, he takes on a corrupt...

163. **Wall Street** (1987) — TMDB: 10673 — Rating: R — Genres: Crime, Drama

> A young and impatient stockbroker is willing to do anything to get to the top, including trading on illegal inside information taken through a ruthless and greedy corporate raider, whom takes the youth under his wing.

164. **Watchmen** (2009) — TMDB: 13183 — Rating: R — Genres: Mystery, Action, Science Fiction

> In a gritty and alternate 1985, the glory days of costumed vigilantes have been brought to a close by a government crackdown. But after one of the masked veterans is brutally murdered, an investigation into the killer is initiated. The reunited heroes set out to prevent their own destruction,...

165. **Weird Science** (1985) — TMDB: 11814 — Rating: PG-13 — Genres: Comedy, Fantasy, Science Fiction, Romance

> Two unpopular teenagers, Gary and Wyatt, fail at all attempts to be accepted by their peers. Their desperation to be liked leads them to "create" a woman via their computer. Their living and breathing creation is a gorgeous woman, Lisa, whose purpose is to boost their confidence level by putting...

166. **Whiplash** (2014) — TMDB: 244786 — Rating: R — Genres: Drama, Music

> Under the direction of a ruthless instructor, a talented young drummer begins to pursue perfection at any cost, even his humanity.

167. **Willow** (1988) — TMDB: 847 — Rating: PG — Genres: Fantasy, Adventure, Action

> The evil Queen Bavmorda hunts the newborn princess Elora Danan, a child prophesied to bring about her downfall. When the royal infant is found by Willow, a timid farmer and aspiring sorcerer, he's entrusted with delivering her from evil.

168. **The Edge** (1997) — TMDB: 9433 — Rating: R — Genres: Action, Adventure, Drama

> The plane carrying wealthy Charles Morse crashes down in the Alaskan wilderness. Together with the two other passengers, photographer Robert and assistant Stephen, Charles devises a plan to help them reach civilization. However, his biggest obstacle might not be the elements, or even the Kodiak...

169. **Sinners** (2025) — TMDB: 1233413 — Rating: R — Genres: Horror, Action, Thriller

> Trying to leave their troubled lives behind, twin brothers return to their hometown to start again, only to discover that an even greater evil is waiting to welcome them back.

170. **Gattaca** (1997) — TMDB: 782 — Rating: PG-13 — Genres: Thriller, Science Fiction, Mystery, Romance

> Vincent is an all-too-human man who dares to defy a system obsessed with genetic perfection. He is an "In-Valid" who assumes the identity of a member of the genetic elite to pursue his goal of traveling into space with the Gattaca Aerospace Corporation.

171. **300** (2007) — TMDB: 1271 — Rating: R — Genres: Action, Adventure, War

> Based on Frank Miller's graphic novel, "300" is very loosely based the 480 B.C. Battle of Thermopylae, where the King of Sparta led his army against the advancing Persians; the battle is said to have inspired all of Greece to band together against the Persians, and helped usher in the world's...

172. **Con Air** (1997) — TMDB: 1701 — Rating: R — Genres: Action, Thriller, Crime

> Newly-paroled former US Army ranger Cameron Poe is headed back to his wife, but must fly home aboard a prison transport flight dubbed "Jailbird" taking the “worst of the worst” prisoners, a group described as “pure predators”, to a new super-prison. Poe faces impossible odds when the transport...

173. **The Rock** (1996) — TMDB: 9802 — Rating: R — Genres: Action, Adventure, Thriller

> When vengeful General Francis X. Hummel seizes control of Alcatraz Island and threatens to launch missiles loaded with deadly chemical weapons into San Francisco, only a young FBI chemical weapons expert and notorious Federal prisoner have the skills to penetrate the impregnable island fortress...

174. **National Treasure** (2004) — TMDB: 2059 — Rating: PG — Genres: Adventure, Action, Thriller, Mystery

> Modern treasure hunters, led by archaeologist Ben Gates, search for a chest of riches rumored to have been stashed away by George Washington, Thomas Jefferson and Benjamin Franklin during the Revolutionary War. The chest's whereabouts may lie in secret clues embedded in the Constitution and the...

175. **Clear and Present Danger** (1994) — TMDB: 9331 — Rating: PG-13 — Genres: Action, Drama, Thriller

> Agent Jack Ryan becomes acting Deputy Director of Intelligence for the CIA when Admiral Greer is diagnosed with cancer. When an American businessman, and friend of the president, is murdered on his yacht, Ryan starts discovering links between the man and drug dealers. As former CIA agent John...

176. **The Fugitive** (1993) — TMDB: 5503 — Rating: PG-13 — Genres: Action, Thriller, Drama

> Wrongfully convicted of murdering his wife and sentenced to death, Richard Kimble escapes from the law in an attempt to find the real killer and clear his name.

177. **¡Three Amigos!** (1986) — TMDB: 8388 — Rating: PG — Genres: Comedy, Western, Drama

> A trio of unemployed silent film actors are mistaken for real heroes by a small Mexican village in search of someone to stop a malevolent bandit.

178. **Lean On Me** (1989) — TMDB: 14621 — Rating: PG-13 — Genres: Drama

> When principal Joe Clark takes over decaying Eastside High School, he's faced with students wearing gang colors and graffiti-covered walls. Determined to do anything he must to turn the school around, he expels suspected drug dealers, padlocks doors and demands effort and results from students,...

179. **The Running Man** (1987) — TMDB: 865 — Rating: R — Genres: Action, Thriller, Science Fiction

> By 2017, the global economy has collapsed and U.S. society has become a totalitarian police state, censoring all cultural activity. The government pacifies the populace by broadcasting a number of game shows in which convicted criminals fight for their lives, including the gladiator-style The...

180. **Commando** (1985) — TMDB: 10999 — Rating: R — Genres: Action, Adventure, Thriller

> John Matrix, the former leader of a special commando strike force that always got the toughest jobs done, is forced back into action when his young daughter is kidnapped. To find her, Matrix has to fight his way through an array of punks, killers, one of his former commandos, and a fully...

181. **Field of Dreams** (1989) — TMDB: 2323 — Rating: PG — Genres: Drama, Fantasy

> Ray Kinsella is an Iowa farmer who hears a mysterious voice telling him to turn his cornfield into a baseball diamond. He does, but the voice's directions don't stop -- even after the spirits of deceased ballplayers turn up to play.

182. **Major League** (1989) — TMDB: 9942 — Rating: R — Genres: Comedy

> When Rachel Phelps inherits the Cleveland Indians from her deceased husband, she's determined to move the team to a warmer climate—but only a losing season will make that possible, which should be easy given the misfits she's hired. Rachel is sure her dream will come true, but she underestimates...

183. **The Karate Kid** (1984) — TMDB: 1885 — Rating: PG — Genres: Action, Adventure, Drama, Family

> New Jersey teen Daniel LaRusso moves to Los Angeles with his mother, and soon strikes up a relationship with Ali. He quickly finds himself the target of bullying by a group of thugs, led by Ali's ex-boyfriend Johnny, who study karate at the Cobra Kai dojo under ruthless sensei John Kreese....

184. **Young Guns** (1988) — TMDB: 11967 — Rating: R — Genres: Western, Action, Adventure

> A group of young gunmen, led by Billy the Kid, become deputies to avenge the murder of the rancher who became their benefactor. But when Billy takes their authority too far, they become the hunted.

185. **Star Trek II: The Wrath of Khan** (1982) — TMDB: 154 — Rating: PG — Genres: Action, Adventure, Science Fiction, Thriller

> The starship Enterprise and its crew is pulled back into action when old nemesis, Khan, steals a top secret device called Project Genesis.

186. **A Few Good Men** (1992) — TMDB: 881 — Rating: R — Genres: Drama

> When cocky military lawyer Lt. Daniel Kaffee and his co-counsel, Lt. Cmdr. JoAnne Galloway, are assigned to a murder case, they uncover a hazing ritual that could implicate high-ranking officials such as shady Col. Nathan Jessep.

187. **Total Recall** (1990) — TMDB: 861 — Rating: R — Genres: Action, Adventure, Science Fiction

> Construction worker Douglas Quaid's obsession with the planet Mars leads him to visit Recall, a company that manufactures memories. When his memory implant goes wrong, Doug can no longer be sure what is and isn't reality.

188. **American Beauty** (1999) — TMDB: 14 — Rating: R — Genres: Drama

> Lester Burnham, a depressed suburban father in a mid-life crisis, decides to turn his hectic life around after developing an infatuation with his daughter's attractive friend.

189. **Die Hard: With a Vengeance** (1995) — TMDB: 1572 — Rating: R — Genres: Action, Thriller

> New York detective John McClane is back and kicking bad-guy butt in the third installment of this action-packed series, which finds him teaming with civilian Zeus Carver to prevent the loss of innocent lives. McClane thought he'd seen it all, until a genius named Simon engages McClane, his new...

190. **Napoleon Dynamite** (2004) — TMDB: 8193 — Rating: PG — Genres: Comedy

> A listless and alienated teenager decides to help his new friend win the class presidency in their small western high school, while he must deal with his bizarre family life back home.

191. **Anchorman: The Legend of Ron Burgundy** (2004) — TMDB: 8699 — Rating: PG-13 — Genres: Comedy

> It's the 1970s and San Diego anchorman Ron Burgundy is the top dog in local TV, but that's all about to change when ambitious reporter Veronica Corningstone arrives as a new employee at his station.

192. **Friday** (1995) — TMDB: 10634 — Rating: R — Genres: Comedy, Drama

> Craig and Smokey are two guys in Los Angeles hanging out on their porch on a Friday afternoon, smoking and drinking, looking for something to do.

193. **Tommy Boy** (1995) — TMDB: 11381 — Rating: PG-13 — Genres: Comedy

> To save the family business, two ne’er-do-well traveling salesmen hit the road with disastrously funny consequences.

194. **The Waterboy** (1998) — TMDB: 10663 — Rating: PG-13 — Genres: Comedy

> Bobby Boucher is a water boy for a struggling college football team. The coach discovers Boucher's hidden rage makes him a tackling machine whose bone-crushing power might vault his team into the playoffs.

195. **Ace Ventura: Pet Detective** (1994) — TMDB: 3049 — Rating: PG-13 — Genres: Comedy, Mystery, Crime

> He's Ace Ventura: Pet Detective. The Ace is on the case to find the Miami Dolphins' missing mascot and quarterback Dan Marino. He goes eyeball to eyeball with a man-eating shark, stakes out the Miami Dolphins and woos and wows the ladies. Whether he's undercover, under fire or underwater, he...

196. **Meet the Fockers** (2004) — TMDB: 693 — Rating: PG-13 — Genres: Comedy, Romance

> Hard-to-crack ex-CIA man Jack Byrnes and his wife Dina head for the warmer climes of Florida to meet the parents of their son-in-law-to-be, Greg Focker. Unlike their happily matched offspring, the future in-laws find themselves in a situation of opposites that definitely do not attract.

197. **Galaxy Quest** (1999) — TMDB: 926 — Rating: PG — Genres: Comedy, Science Fiction, Adventure

> For four years, the courageous crew of the NSEA Protector —  Commander Peter Quincy Taggart, Lieutenant Tawny Madison, and Doctor Lazarus — set off on a thrilling and often dangerous mission in space ... until their series was cancelled! Now, twenty years later, aliens under attack have mistaken...

198. **The 40 Year Old Virgin** (2005) — TMDB: 6957 — Rating: R — Genres: Comedy, Romance

> Andy Stitzer has a pleasant life with a nice apartment and a job stamping invoices at an electronics store. But at age 40, there's one thing Andy hasn't done, and it's really bothering his sex-obsessed male co-workers: Andy is still a virgin. Determined to help Andy get laid, the guys make it...

199. **The Money Pit** (1986) — TMDB: 10466 — Rating: PG — Genres: Comedy, Romance

> After being evicted from their Manhattan apartment, a couple buy what looks like the home of their dreams—only to find themselves saddled with a bank-account-draining nightmare. Struggling to keep their relationship together as their rambling mansion falls to pieces around them, the two watch in...

200. **Ghostbusters II** (1989) — TMDB: 2978 — Rating: PG — Genres: Comedy, Fantasy

> The discovery of a massive river of ectoplasm and a resurgence of spectral activity allows the staff of Ghostbusters to revive the business.

201. **Minority Report** (2002) — TMDB: 180 — Rating: PG-13 — Genres: Science Fiction, Action, Thriller

> John Anderton is a top 'Precrime' cop in the late-21st century, when technology can predict crimes before they're committed. But Anderton becomes the quarry when another investigator targets him for a murder charge.

202. **Pitch Perfect** (2012) — TMDB: 114150 — Rating: PG-13 — Genres: Comedy, Music, Romance

> College student Beca knows she does not want to be part of a clique, but that's exactly where she finds herself after arriving at her new school. Thrust in among mean gals, nice gals and just plain weird gals, Beca finds that the only thing they have in common is how well they sing together. She...

203. **Bridesmaids** (2011) — TMDB: 55721 — Rating: R — Genres: Comedy, Romance

> Annie's life is a mess. But when she finds out her lifetime best friend is engaged, she simply must serve as Lillian's maid of honor. Though lovelorn and broke, Annie bluffs her way through the expensive and bizarre rituals. With one chance to get it perfect, she’ll show Lillian and her...

204. **Dumb and Dumber** (1994) — TMDB: 8467 — Rating: PG-13 — Genres: Comedy

> Lloyd and Harry are two men whose stupidity is really indescribable. When Mary, a beautiful woman, loses an important suitcase with money before she leaves for Aspen, the two friends (who have found the suitcase) decide to return it to her. After some "adventures" they finally get to Aspen...

205. **The Mask** (1994) — TMDB: 854 — Rating: PG-13 — Genres: Romance, Comedy, Crime, Fantasy

> Stanley, a meek bank employee, turns into an eccentric and maniacal green-skinned superhero who can bend reality, after wearing a wooden mask that was created by Loki, the Norse god of mischief.

206. **Liar Liar** (1997) — TMDB: 1624 — Rating: PG-13 — Genres: Comedy

> Forced by his son's birthday wish, fast-talking attorney and habitual liar Fletcher Reede must tell the truth for the next 24 hours.

207. **Independence Day** (1996) — TMDB: 602 — Rating: PG-13 — Genres: Action, Adventure, Science Fiction

> Strange phenomena surface around the globe. The skies ignite. Terror races through the world's major cities. As these extraordinary events unfold, it becomes increasingly clear that a force of incredible magnitude has arrived. Its mission: total annihilation over the Fourth of July weekend. The...

208. **I, Robot** (2004) — TMDB: 2048 — Rating: PG-13 — Genres: Action, Science Fiction

> In 2035, where robots are commonplace and abide by the three laws of robotics, a technophobic cop investigates an apparent suicide. Suspecting that a robot may be responsible for the death, his investigation leads him to believe that humanity may be in danger.

209. **Short Circuit** (1986) — TMDB: 2605 — Rating: PG — Genres: Science Fiction, Comedy, Family

> After a lightning bolt zaps a robot named Number 5, the lovable machine starts to think he's human and escapes the lab. Hot on his trail is his designer, Newton, who hopes to get to Number 5 before the military does. In the meantime, a spunky animal lover mistakes the robot for an alien and...

210. **True Lies** (1994) — TMDB: 36955 — Rating: R — Genres: Action, Thriller

> A fearless, globe-trotting, terrorist-battling secret agent has his life turned upside down when he discovers his wife might be having an affair with a used car salesman while terrorists smuggle nuclear war heads into the United States.

211. **Training Day** (2001) — TMDB: 2034 — Rating: R — Genres: Action, Crime, Drama

> On his first day on the job as a narcotics officer, a rookie cop works with a rogue detective who isn't what he appears.

212. **Constantine** (2005) — TMDB: 561 — Rating: R — Genres: Fantasy, Action, Horror

> John Constantine has literally been to Hell and back. When he teams up with a policewoman to solve the mysterious suicide of her twin sister, their investigation takes them through the world of demons and angels that exists beneath the landscape of contemporary Los Angeles.
