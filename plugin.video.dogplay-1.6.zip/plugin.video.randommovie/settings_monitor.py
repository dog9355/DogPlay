# -*- coding: utf-8 -*-
"""Monitor settings changes and trigger list selection when mode changes to single"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys

# Import FenlightAM modules for Trakt
try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')
    from apis import trakt_api
    from caches import settings_cache
except:
    pass

addon = xbmcaddon.Addon('plugin.video.randommovie')

class SettingsMonitor(xbmc.Monitor):
    """Monitor for settings changes"""
    def __init__(self):
        super().__init__()
        self.previous_mode = addon.getSetting('list_mode')
        # Custom list defaults
        self.custom_list_defaults = {
            1: {'name': 'Top 1000 Movies of all Time', 'user': 'reallyjosh', 'id': 'top-1-000-movies-on-imdb'},
            2: {'name': 'Action, Adventure & War Movies/TV', 'user': 'jmillz', 'id': 'action-adventure-war-movies-tv'},
            3: {'name': 'All Out 80s', 'user': 'fritzi1221', 'id': 'all-out-80s'}
        }
        xbmc.log("DogPlay: Settings monitor initialized", xbmc.LOGINFO)
        # Check and populate custom lists on startup
        self._check_custom_lists()

    def _check_custom_lists(self):
        """Check if custom lists are enabled and populate defaults if needed"""
        for i in range(1, 6):
            enabled = addon.getSetting(f'custom_list_{i}_enabled') == 'true'
            if enabled and i in self.custom_list_defaults:
                name = addon.getSetting(f'custom_list_{i}_name')
                user = addon.getSetting(f'custom_list_{i}_user')
                list_id = addon.getSetting(f'custom_list_{i}_id')

                # If any field is empty, populate with defaults
                if not name or not user or not list_id:
                    defaults = self.custom_list_defaults[i]
                    addon.setSetting(f'custom_list_{i}_name', defaults['name'])
                    addon.setSetting(f'custom_list_{i}_user', defaults['user'])
                    addon.setSetting(f'custom_list_{i}_id', defaults['id'])
                    xbmc.log(f"DogPlay: Auto-populated custom list {i} with defaults", xbmc.LOGINFO)

    def onSettingsChanged(self):
        """Called when addon settings change"""
        current_mode = addon.getSetting('list_mode')

        # Check if mode changed from 'prompt' to 'single'
        if self.previous_mode != 'single' and current_mode == 'single':
            xbmc.log("DogPlay: List mode changed to single, showing list selection", xbmc.LOGINFO)
            # Wait a bit for settings dialog to close
            xbmc.sleep(500)
            # Run the list selection script
            xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.randommovie/select_list.py)')

        self.previous_mode = current_mode

        # Check custom lists whenever settings change
        self._check_custom_lists()

if __name__ == '__main__':
    # This gets imported by service.py, not run directly
    pass
