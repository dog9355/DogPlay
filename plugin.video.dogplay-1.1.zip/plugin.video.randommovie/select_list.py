# -*- coding: utf-8 -*-
"""Script to select a Trakt list from settings"""
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

# Try to import FenlightAM modules
try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')

    from apis import trakt_api
    from caches import settings_cache
except Exception as e:
    xbmc.log(f"DogPlay: Failed to import FenlightAM modules: {str(e)}", xbmc.LOGERROR)
    xbmcgui.Dialog().ok('Error', 'Failed to load FenlightAM modules')
    sys.exit(1)

addon = xbmcaddon.Addon('plugin.video.randommovie')

def check_fenlight_auth():
    """Check if FenlightAM is authenticated with Trakt"""
    try:
        trakt_user = settings_cache.get_setting('fenlight.trakt.user')
        if not trakt_user or trakt_user in ('', 'empty_setting'):
            xbmcgui.Dialog().ok('Authentication Required',
                              'Please authenticate with Trakt in FenlightAM first.')
            return False
        return True
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Could not access FenlightAM settings: {str(e)}')
        return False

def get_trakt_lists():
    """Get user's Trakt lists using FenlightAM's API"""
    try:
        lists = trakt_api.trakt_get_lists('my_lists')
        if not lists:
            xbmcgui.Dialog().ok('No Lists Found', 'No Trakt lists found for your account.')
            return []
        return lists
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch Trakt lists: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch lists: {str(e)}", xbmc.LOGERROR)
        return []

if __name__ == '__main__':
    if not check_fenlight_auth():
        sys.exit(1)

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching your Trakt lists...')

    lists = get_trakt_lists()
    progress.close()

    if not lists:
        sys.exit(1)

    # Create list selection dialog
    list_names = [l.get('name', 'Unnamed List') for l in lists]
    selected = xbmcgui.Dialog().select('Select a Trakt List', list_names)

    if selected >= 0:
        # Get selected list details
        selected_list = lists[selected]
        user = selected_list.get('user', {}).get('ids', {}).get('slug')
        list_id = selected_list.get('ids', {}).get('trakt')
        list_name = selected_list.get('name', 'Unknown List')

        if user and list_id:
            # Save the list info to settings
            addon.setSetting('saved_list_user', user)
            addon.setSetting('saved_list_id', str(list_id))
            addon.setSetting('saved_list_name', list_name)
            xbmcgui.Dialog().ok('List Saved', f'Selected list: {list_name}')
            xbmc.log(f"DogPlay: Saved list - User: {user}, ID: {list_id}, Name: {list_name}", xbmc.LOGINFO)
