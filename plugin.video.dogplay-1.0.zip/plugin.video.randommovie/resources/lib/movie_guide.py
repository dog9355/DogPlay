# -*- coding: utf-8 -*-
"""Movie Guide - EPG-style grid showing random movies on virtual channels"""
import random
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
from datetime import datetime, timedelta
import colorsys
import os

addon = xbmcaddon.Addon()

class MovieGuide:
    """Generate EPG-style movie guide data"""

    def __init__(self, movies, num_channels=5, movies_per_channel=6):
        self.movies = movies
        self.num_channels = num_channels
        self.movies_per_channel = movies_per_channel
        self.channels = []

    def generate_guide(self):
        """Generate the guide data - simple grid of random movies"""
        self.channels = []
        used_tmdb_ids = set()  # Track used movies to avoid duplicates

        for channel_num in range(1, self.num_channels + 1):
            channel = {
                'number': channel_num,
                'name': f'DogPlay {channel_num}',
                'movies': []
            }

            # Pick random movies for this channel
            for _ in range(self.movies_per_channel):
                # Try to find a movie not yet used
                attempts = 0
                max_attempts = len(self.movies)

                while attempts < max_attempts:
                    movie = random.choice(self.movies)
                    media_ids = movie.get('media_ids', {})
                    tmdb_id = media_ids.get('tmdb')

                    # If we haven't used this movie yet, or we've run out of unique movies, use it
                    if tmdb_id not in used_tmdb_ids or len(used_tmdb_ids) >= len(self.movies):
                        movie_title = movie.get('title', 'Unknown Movie')

                        movie_item = {
                            'movie': movie,
                            'title': movie_title,
                            'tmdb_id': tmdb_id
                        }

                        channel['movies'].append(movie_item)
                        if tmdb_id:
                            used_tmdb_ids.add(tmdb_id)
                        break

                    attempts += 1

            self.channels.append(channel)

        return self.channels

class MovieGuideWindow(xbmcgui.Window):
    """Custom window for displaying the movie guide grid"""

    def __init__(self):
        super().__init__()
        self.channels = []
        self.movies_data = []
        self.user = ''
        self.list_id = ''
        self.bar_controls = []
        self.bar_data = []

        # Grid settings
        self.grid_left = 200
        self.grid_top = 150
        self.channel_height = 105  # Reduced to fit all 5 channels on screen
        self.grid_width = 1520
        self.pixels_per_minute = 3  # How many pixels per minute of movie runtime

    def set_data(self, channels, movies_data, user, list_id):
        """Set the data for the guide"""
        self.channels = channels
        self.movies_data = movies_data
        self.user = user
        self.list_id = list_id

    def onInit(self):
        """Initialize the window and create the grid"""
        try:
            xbmc.log("DogPlay MovieGuide: Starting onInit", xbmc.LOGINFO)
            xbmc.log(f"DogPlay MovieGuide: Channels count: {len(self.channels)}", xbmc.LOGINFO)

            # Make sure we have data
            if not self.channels:
                xbmc.log("DogPlay MovieGuide: No channels data available!", xbmc.LOGERROR)
                return

            # Set black background using window property
            self.setProperty('background', '0xFF000000')

            # Create title
            title = xbmcgui.ControlLabel(60, 40, 1800, 60, 'DogPlay Movie Guide',
                                        font='font30_title', textColor='0xFFFFFFFF')
            self.addControl(title)
            xbmc.log("DogPlay MovieGuide: Added title", xbmc.LOGINFO)

            # Create current time label
            time_label = xbmcgui.ControlLabel(60, 100, 1800, 40,
                                             f"Current Time: {datetime.now().strftime('%I:%M %p')}",
                                             font='font13', textColor='0xFFFFFFFF')
            self.addControl(time_label)
            xbmc.log("DogPlay MovieGuide: Added time label", xbmc.LOGINFO)

            # Draw the grid
            self._draw_grid()
            xbmc.log("DogPlay MovieGuide: Grid drawn", xbmc.LOGINFO)

            # Add instructions
            instructions = xbmcgui.ControlLabel(60, 1000, 1800, 40,
                                               'Use arrow keys to navigate, ENTER to select - Press ESC/BACK to close',
                                               font='font13', textColor='0xFFAAAAAA')
            self.addControl(instructions)

            # Set focus to first movie bar and show its color
            if self.bar_controls and self.bar_data:
                self.setFocus(self.bar_controls[0])
                # Small delay to ensure window is fully rendered
                import time
                time.sleep(0.1)
                # Show colored background for first bar
                self.bar_data[0]['bg_gray'].setVisible(False)
                self.bar_data[0]['bg_color'].setVisible(True)
                xbmc.log("DogPlay MovieGuide: Set focus to first bar with color", xbmc.LOGINFO)

            xbmc.log("DogPlay MovieGuide: onInit complete", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"DogPlay MovieGuide: Error in onInit: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay MovieGuide: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            raise

    def _get_color_for_movie(self, movie_index):
        """Generate a distinct color for each movie using a predefined palette"""
        # Use a palette of rich, visible colors that look good on black background
        color_palette = [
            '0xFF4169E1',  # Royal Blue
            '0xFFDC143C',  # Crimson Red
            '0xFF32CD32',  # Lime Green
            '0xFFFF8C00',  # Dark Orange
            '0xFF9370DB',  # Medium Purple
            '0xFF20B2AA',  # Light Sea Green
            '0xFFFF1493',  # Deep Pink
            '0xFFFFD700',  # Gold
            '0xFF00CED1',  # Dark Turquoise
            '0xFFFF6347',  # Tomato
            '0xFF9932CC',  # Dark Orchid
            '0xFF00FA9A',  # Medium Spring Green
            '0xFFFF69B4',  # Hot Pink
            '0xFF87CEEB',  # Sky Blue
            '0xFFFF4500',  # Orange Red
            '0xFF8A2BE2',  # Blue Violet
            '0xFF00FF7F',  # Spring Green
            '0xFFDB7093',  # Pale Violet Red
            '0xFF48D1CC',  # Medium Turquoise
            '0xFFFFA500',  # Orange
        ]

        # Cycle through the palette
        return color_palette[movie_index % len(color_palette)]

    def _draw_grid(self):
        """Draw the movie guide grid - bars with separators, stagger, random widths, cut off at channel label"""
        addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        white_texture = os.path.join(addon_path, 'white.png')

        base_bar_width = 400  # Base width
        bar_height = 85
        separator_width = 3  # Small black separator between bars

        for channel_idx, channel in enumerate(self.channels):
            y_pos = self.grid_top + (channel_idx * self.channel_height)

            # Draw channel label
            channel_label = xbmcgui.ControlLabel(
                60, y_pos + 40, 130, 40,
                f"Ch {channel['number']}",
                font='font13', textColor='0xFFFFFFFF'
            )
            self.addControl(channel_label)

            # Calculate stagger offset for this channel (more stagger: 0-200px)
            # Use channel_idx to seed random so each channel has consistent stagger
            random.seed(channel_idx * 1000)
            channel_stagger = random.randint(0, 200)

            # Calculate where the first bar should start (after channel label ends)
            # Channel label is at x=60, width=130, so it ends at x=190
            # Grid starts at x=200, so first bar visible area starts at grid_left
            first_bar_visible_x = self.grid_left

            # If staggered, the actual bar starts before grid_left
            first_bar_actual_x = self.grid_left - channel_stagger

            # Draw placeholder bar only for the visible portion before grid_left
            if channel_stagger > 0:
                # Placeholder bar shows the "in progress" part that's cut off
                # It goes from first_bar_actual_x to grid_left (but is partially hidden by channel label area)
                placeholder_width = channel_stagger
                bar_y = y_pos + 8

                # Only draw the portion that's actually visible (not covered by channel label)
                # Channel label ends at x=190, grid starts at 200
                # So we can show a bit of the placeholder from 190 to 200
                visible_placeholder_x = max(first_bar_actual_x, 190)
                visible_placeholder_width = first_bar_visible_x - visible_placeholder_x

                if visible_placeholder_width > 0:
                    placeholder_bar = xbmcgui.ControlImage(
                        visible_placeholder_x, bar_y, visible_placeholder_width, bar_height,
                        white_texture
                    )
                    placeholder_bar.setColorDiffuse('0xFF404040')  # Darker gray for placeholder
                    self.addControl(placeholder_bar)

            # Track current x position
            current_x = first_bar_actual_x

            # Draw movies for this channel
            for movie_idx, movie_item in enumerate(channel['movies']):
                # Random width variation (0-30% of base width)
                random.seed(hash(movie_item['title']))
                width_variation = random.randint(0, int(base_bar_width * 0.3))
                bar_width = base_bar_width + width_variation

                bar_x = current_x
                bar_y = y_pos + 8

                # For first bar, if it starts before grid_left, clip it
                actual_bar_x = bar_x
                actual_bar_width = bar_width

                if movie_idx == 0 and bar_x < first_bar_visible_x:
                    # First bar is cut off - adjust to only show visible portion
                    actual_bar_x = first_bar_visible_x
                    actual_bar_width = bar_width - (first_bar_visible_x - bar_x)

                # Get color for this movie
                color = self._get_color_for_movie(hash(movie_item['title']) % 20)

                # Create button for interaction
                bar_button = xbmcgui.ControlButton(
                    actual_bar_x, bar_y, actual_bar_width, bar_height,
                    '',
                    focusTexture=white_texture,
                    noFocusTexture=white_texture,
                    textColor='0x00FFFFFF',
                )
                self.addControl(bar_button)

                # Gray background (shown when not focused)
                bar_bg_gray = xbmcgui.ControlImage(
                    actual_bar_x, bar_y, actual_bar_width, bar_height,
                    white_texture
                )
                bar_bg_gray.setColorDiffuse('0xFF505050')
                self.addControl(bar_bg_gray)

                # Colored background (shown when focused)
                bar_bg_color = xbmcgui.ControlImage(
                    actual_bar_x, bar_y, actual_bar_width, bar_height,
                    white_texture
                )
                bar_bg_color.setColorDiffuse(color)
                bar_bg_color.setVisible(False)
                self.addControl(bar_bg_color)

                # Add movie title label
                title_label = xbmcgui.ControlLabel(
                    actual_bar_x + 15, bar_y + 35, actual_bar_width - 30, 40,
                    movie_item['title'][:35],
                    font='font12',
                    textColor='0xFFFFFFFF'
                )
                self.addControl(title_label)

                # Store bar data
                self.bar_controls.append(bar_button)
                self.bar_data.append({
                    'movie_item': movie_item,
                    'channel_idx': channel_idx,
                    'movie_idx': movie_idx,
                    'bg_gray': bar_bg_gray,
                    'bg_color': bar_bg_color
                })

                # Move current_x forward for next bar (with separator)
                current_x += bar_width + separator_width

            # Reset random seed
            random.seed()

    def onControl(self, control):
        """Handle control clicks"""
        try:
            # Find which bar was clicked
            for idx, bar_control in enumerate(self.bar_controls):
                if control == bar_control:
                    bar_info = self.bar_data[idx]
                    self._play_movie_at_position(bar_info['schedule_item'])
                    break
        except Exception as e:
            xbmc.log(f"DogPlay MovieGuide: Error in onControl: {str(e)}", xbmc.LOGERROR)

    def onClick(self, controlId):
        """Handle button clicks"""
        xbmc.log(f"DogPlay MovieGuide: onClick called for control ID: {controlId}", xbmc.LOGINFO)

        # Find which bar was clicked based on control
        for idx, bar_control in enumerate(self.bar_controls):
            if bar_control.getId() == controlId:
                xbmc.log(f"DogPlay MovieGuide: Clicked bar {idx}: {self.bar_data[idx]['schedule_item']['title']}", xbmc.LOGINFO)
                self._play_movie_at_position(self.bar_data[idx]['schedule_item'])
                return

    def onAction(self, action):
        """Handle actions like ESC key, ENTER, and arrow keys"""
        action_id = action.getId()
        xbmc.log(f"DogPlay MovieGuide: onAction called with action ID: {action_id}", xbmc.LOGINFO)

        # Handle back/escape
        if action_id in [10, 92]:  # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
            xbmc.log("DogPlay MovieGuide: Back/ESC pressed, closing", xbmc.LOGINFO)
            self.close()

        # Handle navigation to update focused bar color
        # Action 1 = Up, Action 2 = Down, Action 3 = Left, Action 4 = Right
        elif action_id in [1, 2, 3, 4]:
            try:
                focused_control = self.getFocus()
                focused_id = focused_control.getId()

                # Find current bar
                current_idx = None
                for idx, bar_control in enumerate(self.bar_controls):
                    if bar_control.getId() == focused_id:
                        current_idx = idx
                        break

                if current_idx is not None:
                    current_bar = self.bar_data[current_idx]

                    # Calculate target based on direction
                    # Note: Action IDs seem to be rotated on this system
                    if action_id == 1:  # Up -> goes Left
                        target_channel = current_bar['channel_idx']
                        target_movie = current_bar['movie_idx'] - 1
                    elif action_id == 2:  # Down -> goes Right
                        target_channel = current_bar['channel_idx']
                        target_movie = current_bar['movie_idx'] + 1
                    elif action_id == 3:  # Left -> goes Up
                        target_channel = current_bar['channel_idx'] - 1
                        target_movie = current_bar['movie_idx']
                    elif action_id == 4:  # Right -> goes Down
                        target_channel = current_bar['channel_idx'] + 1
                        target_movie = current_bar['movie_idx']

                    # Find target bar
                    for idx, bar_info in enumerate(self.bar_data):
                        if bar_info['channel_idx'] == target_channel and bar_info['movie_idx'] == target_movie:
                            self.setFocus(self.bar_controls[idx])
                            break
            except Exception as e:
                xbmc.log(f"DogPlay MovieGuide: Nav error: {str(e)}", xbmc.LOGERROR)

            # After navigation, update which bar is highlighted
            try:
                # Small delay to let focus change
                import time
                time.sleep(0.05)

                focused_control = self.getFocus()
                focused_id = focused_control.getId()

                # Hide all colored backgrounds, show gray
                for bar_info in self.bar_data:
                    bar_info['bg_gray'].setVisible(True)
                    bar_info['bg_color'].setVisible(False)

                # Show colored background for focused bar
                for idx, bar_control in enumerate(self.bar_controls):
                    if bar_control.getId() == focused_id:
                        self.bar_data[idx]['bg_gray'].setVisible(False)
                        self.bar_data[idx]['bg_color'].setVisible(True)
                        break
            except:
                pass  # Ignore errors during navigation

        # Handle SELECT/ENTER key (action 7)
        elif action_id == 7:
            try:
                focused_control = self.getFocus()
                focused_id = focused_control.getId()
                xbmc.log(f"DogPlay MovieGuide: SELECT pressed, focused control ID: {focused_id}", xbmc.LOGINFO)

                # Find which bar is focused by comparing control IDs
                for idx, bar_control in enumerate(self.bar_controls):
                    try:
                        bar_id = bar_control.getId()
                        if focused_id == bar_id:
                            xbmc.log(f"DogPlay MovieGuide: Selected bar {idx}: {self.bar_data[idx]['movie_item']['title']}", xbmc.LOGINFO)
                            self._play_movie_random(self.bar_data[idx]['movie_item'])
                            return
                    except Exception as inner_e:
                        xbmc.log(f"DogPlay MovieGuide: Error comparing control {idx}: {str(inner_e)}", xbmc.LOGERROR)

                xbmc.log(f"DogPlay MovieGuide: No matching bar found for focused control ID {focused_id}", xbmc.LOGWARNING)
            except RuntimeError as e:
                if "Non-Existent Control" in str(e):
                    xbmc.log("DogPlay MovieGuide: No control has focus", xbmc.LOGINFO)
                else:
                    xbmc.log(f"DogPlay MovieGuide: RuntimeError handling SELECT: {str(e)}", xbmc.LOGERROR)
            except Exception as e:
                xbmc.log(f"DogPlay MovieGuide: Error handling SELECT: {str(e)}", xbmc.LOGERROR)

    def _play_movie_random(self, movie_item):
        """Play a movie with random start position (like main DogPlay feature)"""
        try:
            from resources.lib import main
            import sys
            import xbmcvfs

            # Import FenlightAM modules
            fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
            fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
            if fenlight_path not in sys.path:
                sys.path.append(fenlight_path + '/resources/lib')

            from apis.tmdb_api import movie_details
            from modules import watched_status
            from modules.settings import playback_key, tmdb_api_key
            from modules.sources import Sources

            movie = movie_item['movie']
            media_ids = movie.get('media_ids', {})
            tmdb_id = media_ids.get('tmdb')

            if not tmdb_id:
                xbmcgui.Dialog().ok('Error', 'Could not find movie ID')
                return

            # Get random start settings from addon
            random_start_enabled = addon.getSetting('random_start_enabled') == 'true'
            min_percent = float(addon.getSetting('min_start_percent'))
            max_percent = float(addon.getSetting('max_start_percent'))

            # Calculate random start position
            if random_start_enabled:
                seek_percent = random.uniform(min_percent, max_percent)
            else:
                seek_percent = 0.0

            xbmc.log(f"DogPlay MovieGuide: Playing {movie_item['title']} at {seek_percent:.1f}%", xbmc.LOGINFO)

            # Save current movie info for service monitoring
            # Use Window properties instead of settings for temporary state
            window = xbmcgui.Window(10000)
            window.setProperty('dogplay.current_tmdb_id', str(tmdb_id))
            window.setProperty('dogplay.current_title', movie_item['title'])
            window.setProperty('dogplay.current_user', self.user)
            window.setProperty('dogplay.current_list_id', self.list_id)

            xbmc.log(f"DogPlay MovieGuide: Set properties - tmdb_id='{tmdb_id}', title='{movie_item['title']}', user='{self.user}', list_id='{self.list_id}'", xbmc.LOGINFO)

            # Get movie metadata
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 120) if meta else 120  # Default 120 minutes if not found
            runtime_seconds = runtime * 60

            # Set bookmark if we're not starting from the beginning
            if seek_percent > 0:
                seek_position = int((seek_percent / 100.0) * runtime_seconds)
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': movie_item['title'],
                    'from_playback': 'false'
                }
                watched_status.set_bookmark(bookmark_params)

            # Get playback key and build params
            key = playback_key()
            params = {
                'tmdb_id': str(tmdb_id),
                'media_type': 'movie',
                key: 'true'
            }

            # Create Sources instance
            source_instance = Sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                if seek_percent > 0:
                    return float(seek_percent)
                return original_get_playback_percent()

            source_instance.get_playback_percent = forced_get_playback_percent

            # Close the guide window
            self.close()

            # Start playback
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay MovieGuide: Error playing movie: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')

def show_movie_guide(movies):
    """Display the movie guide dialog"""
    if not movies:
        xbmcgui.Dialog().ok('No Movies', 'No movies found in the list.')
        return

    # Show busy dialog while loading
    progress = xbmcgui.DialogProgressBG()
    progress.create('DogPlay Movie Guide', 'Generating guide...')

    try:
        # Generate guide data
        progress.update(25, 'DogPlay Movie Guide', 'Selecting movies...')
        guide = MovieGuide(movies, num_channels=5, movies_per_channel=3)  # Reduced to 3 movies per channel to fit on screen
        channels = guide.generate_guide()

        # Get current list info for potential playback
        user = addon.getSetting('saved_list_user')
        list_id = addon.getSetting('saved_list_id')

        # Show the custom window
        progress.update(50, 'DogPlay Movie Guide', 'Building grid...')
        window = MovieGuideWindow()
        window.set_data(channels, movies, user, list_id)

        progress.update(75, 'DogPlay Movie Guide', 'Rendering controls...')
        window.onInit()  # Manually call onInit to set up the controls

        progress.update(100, 'DogPlay Movie Guide', 'Ready!')

        # Small delay to show "Ready!" message, then close progress
        import time
        time.sleep(0.3)
        progress.close()

        window.show()  # Show the window (non-blocking)

        # Keep window open until user presses back/escape
        import time
        while not xbmc.Monitor().waitForAbort(0.1):
            if xbmc.getCondVisibility('Window.IsActive(home)'):
                break

        # Properly clean up window
        try:
            window.close()
        except:
            pass
        try:
            del window
        except:
            pass

    except Exception as e:
        xbmc.log(f"DogPlay: Error showing movie guide window: {str(e)}", xbmc.LOGERROR)
        import traceback
        xbmc.log(f"DogPlay: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
        # Show error dialog instead of text fallback
        xbmcgui.Dialog().ok('Movie Guide Error', f'Failed to display movie guide: {str(e)}')

def build_guide_text(channels):
    """Build a text representation of the guide"""
    lines = []
    lines.append("=" * 80)
    lines.append("DOGPLAY MOVIE GUIDE - Live Now")
    lines.append("=" * 80)
    lines.append("")

    current_time = datetime.now()

    for channel in channels:
        lines.append(f"\n[B]Channel {channel['number']}: {channel['name']}[/B]")
        lines.append("-" * 80)

        for item in channel['schedule']:
            start_time_str = item['start_time'].strftime('%I:%M %p')
            end_time_str = item['end_time'].strftime('%I:%M %p')

            # Check if this movie is currently playing
            if current_time >= item['start_time'] and current_time < item['end_time']:
                status = f"[COLOR green]>> PLAYING NOW ({item['progress']:.0f}% complete)[/COLOR]"
            elif current_time < item['start_time']:
                status = "[COLOR yellow]Upcoming[/COLOR]"
            else:
                status = "[COLOR gray]Finished[/COLOR]"

            lines.append(f"{start_time_str} - {end_time_str} | {item['runtime']}min | {item['title']}")
            lines.append(f"                     {status}")
            lines.append("")

    lines.append("=" * 80)
    lines.append("Select a channel in the main menu to start watching!")

    return "\n".join(lines)
