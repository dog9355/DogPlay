# -*- coding: utf-8 -*-
"""Background service for DogPlay continuous playback monitoring"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys

# Import FenlightAM modules
try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')
except:
    pass

addon = xbmcaddon.Addon('plugin.video.randommovie')

class DogPlayMonitor(xbmc.Monitor):
    """Service monitor for DogPlay"""
    def __init__(self):
        super().__init__()
        self.player = DogPlayPlayer()
        xbmc.log("DogPlay Service: Monitor initialized", xbmc.LOGINFO)

    def run(self):
        """Main service loop"""
        xbmc.log("DogPlay Service: Starting service", xbmc.LOGINFO)
        while not self.abortRequested():
            if self.waitForAbort(1):
                break
        xbmc.log("DogPlay Service: Service stopped", xbmc.LOGINFO)

class DogPlayPlayer(xbmc.Player):
    """Player monitor for continuous playback"""
    def __init__(self):
        super().__init__()
        self.user = None
        self.list_id = None
        self.current_tmdb_id = None
        self.current_title = None
        xbmc.log("DogPlay Service: Player monitor initialized", xbmc.LOGINFO)

    def onAVStarted(self):
        """Called when playback starts"""
        # Check if this is a DogPlay playback
        try:
            window = xbmcgui.Window(10000)
            self.user = window.getProperty('dogplay.current_user')
            self.list_id = window.getProperty('dogplay.current_list_id')
            self.current_tmdb_id = window.getProperty('dogplay.current_tmdb_id')
            self.current_title = window.getProperty('dogplay.current_title')

            xbmc.log(f"DogPlay Service: Properties loaded - user='{self.user}', list_id='{self.list_id}', tmdb_id='{self.current_tmdb_id}'", xbmc.LOGINFO)

            if self.user and self.list_id:
                xbmc.log(f"DogPlay Service: Playback started - monitoring for list {self.list_id}, TMDB ID: {self.current_tmdb_id}", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay Service: No user/list info - continuous play will not work", xbmc.LOGINFO)
        except:
            pass

    def onPlayBackEnded(self):
        """Called when playback ends naturally"""
        xbmc.log("DogPlay Service: onPlayBackEnded - Movie finished naturally", xbmc.LOGINFO)

        # Clear Trakt progress if setting is enabled
        self._clear_trakt_progress_if_enabled()

        continuous_play = addon.getSetting('continuous_play') == 'true'

        xbmc.log(f"DogPlay Service: continuous_play={continuous_play}, user='{self.user}', list_id='{self.list_id}'", xbmc.LOGINFO)

        if continuous_play and self.user and self.list_id:
            xbmc.log(f"DogPlay Service: Continuous play enabled, playing next movie in 3 seconds", xbmc.LOGINFO)
            xbmc.sleep(3000)

            # Trigger next movie playback
            try:
                xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.randommovie/?action=play_next&user={self.user}&list_id={self.list_id})')
            except Exception as e:
                xbmc.log(f"DogPlay Service: Error triggering next movie: {str(e)}", xbmc.LOGERROR)
        else:
            xbmc.log("DogPlay Service: Continuous play disabled or no list info", xbmc.LOGINFO)
            # Clear the current playback info
            self._clear_current_playback_info()

    def onPlayBackStopped(self):
        """Called when user manually stops playback"""
        xbmc.log("DogPlay Service: onPlayBackStopped - User stopped manually", xbmc.LOGINFO)

        # Clear Trakt progress if setting is enabled
        self._clear_trakt_progress_if_enabled()

        # Clear the current playback info so it doesn't auto-play next
        self._clear_current_playback_info()

    def _clear_current_playback_info(self):
        """Clear current playback tracking properties"""
        window = xbmcgui.Window(10000)
        window.clearProperty('dogplay.current_user')
        window.clearProperty('dogplay.current_list_id')
        window.clearProperty('dogplay.current_tmdb_id')
        window.clearProperty('dogplay.current_title')
        self.user = None
        self.list_id = None
        self.current_tmdb_id = None
        self.current_title = None

    def _clear_trakt_progress_if_enabled(self):
        """Clear the movie from Trakt 'In Progress' if setting is enabled"""
        try:
            clear_enabled = addon.getSetting('clear_trakt_progress') == 'true'

            xbmc.log(f"DogPlay Service: Trakt clear check - enabled={clear_enabled}, tmdb_id='{self.current_tmdb_id}', title='{self.current_title}'", xbmc.LOGINFO)

            if clear_enabled and self.current_tmdb_id:
                xbmc.log(f"DogPlay Service: Clearing Trakt progress for TMDB ID {self.current_tmdb_id}", xbmc.LOGINFO)

                # Import FenlightAM's watched_status module
                from modules import watched_status

                # Erase the bookmark using correct function signature
                # erase_bookmark(media_type, media_id, season='', episode='', refresh='false')
                watched_status.erase_bookmark('movie', str(self.current_tmdb_id), '', '', 'false')
                xbmc.log(f"DogPlay Service: Cleared Trakt progress for '{self.current_title}'", xbmc.LOGINFO)
            elif not clear_enabled:
                xbmc.log("DogPlay Service: Clear Trakt progress disabled in settings", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: Error clearing Trakt progress: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)

if __name__ == '__main__':
    monitor = DogPlayMonitor()
    monitor.run()
