# -*- coding: utf-8 -*-
"""Monitor settings changes and trigger list selection when mode changes to single"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys

# Import FenlightAM modules for Trakt
try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')
    from apis import trakt_api
    from caches import settings_cache
except:
    pass

addon = xbmcaddon.Addon('plugin.video.randommovie')

class SettingsMonitor(xbmc.Monitor):
    """Monitor for settings changes"""
    def __init__(self):
        super().__init__()
        self.previous_mode = addon.getSetting('list_mode')
        xbmc.log("DogPlay: Settings monitor initialized", xbmc.LOGINFO)

    def onSettingsChanged(self):
        """Called when addon settings change"""
        current_mode = addon.getSetting('list_mode')

        # Check if mode changed from 'prompt' to 'single'
        if self.previous_mode != 'single' and current_mode == 'single':
            xbmc.log("DogPlay: List mode changed to single, showing list selection", xbmc.LOGINFO)
            # Wait a bit for settings dialog to close
            xbmc.sleep(500)
            # Run the list selection script
            xbmc.executebuiltin('RunScript(special://home/addons/plugin.video.randommovie/select_list.py)')

        self.previous_mode = current_mode

if __name__ == '__main__':
    # This gets imported by service.py, not run directly
    pass
