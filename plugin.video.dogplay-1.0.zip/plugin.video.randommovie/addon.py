# -*- coding: utf-8 -*-
import sys
import xbmcplugin
from urllib.parse import parse_qsl
from resources.lib import main

# Get addon handle and base URL
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

def router(params):
    """Route to the appropriate function based on params"""
    # Set content type for Kodi
    xbmcplugin.setContent(addon_handle, 'videos')

    if not params:
        # Show main menu
        main.main_menu(addon_handle, base_url)
    elif params.get('action') == 'play_random':
        # Play random movie from list
        list_id = params.get('list_id')
        user = params.get('user')
        main.play_random_movie(user, list_id)
    elif params.get('action') == 'select_list':
        # Show list selection menu
        main.select_list()
    elif params.get('action') == 'settings':
        # Open settings
        main.open_settings()
    elif params.get('action') == 'play_next':
        # Play next random movie (triggered by service)
        user = params.get('user')
        list_id = params.get('list_id')
        main.play_random_movie(user, list_id)
    elif params.get('action') == 'movie_guide':
        # Show movie guide
        main.show_movie_guide()
    elif params.get('action') == 'play_collection':
        # Play random movie from collection
        main.play_random_from_collection()

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:]))
    router(params)
