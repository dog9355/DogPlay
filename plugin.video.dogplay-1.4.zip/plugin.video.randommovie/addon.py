# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcplugin
from urllib.parse import parse_qsl
from resources.lib import main

# Get addon handle and base URL
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

def router(params):
    """Route to the appropriate function based on params"""
    # Set content type for Kodi
    xbmcplugin.setContent(addon_handle, 'videos')

    if not params:
        # Show main menu
        main.main_menu(addon_handle, base_url)
    elif params.get('action') == 'play_random':
        # Play random movie from list
        list_id = params.get('list_id')
        user = params.get('user')
        main.play_random_movie(user, list_id)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'select_list':
        # Show list selection menu
        main.select_list()
        # Close directory properly
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'settings':
        # Open settings
        main.open_settings()
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'play_next':
        # Play next random movie (triggered by service)
        user = params.get('user')
        list_id = params.get('list_id')
        main.play_random_movie(user, list_id)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'movie_guide':
        # Show movie guide
        main.show_movie_guide()
        # Close directory properly to prevent menu duplication
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'play_collection':
        # Play random movie from collection
        main.play_random_from_collection()
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'play_custom_list':
        # Play random movie from custom curated list
        user = params.get('user')
        list_id = params.get('list_id')
        main.play_random_movie(user, list_id)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'play_local_list':
        # Play random movie from local curated list (Omakase)
        main.play_random_from_local_list('Omakase')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'recently_watched':
        # Show Recently Watched
        main.show_recently_watched(addon_handle, base_url)
    elif params.get('action') == 'select_tv_list':
        # Show TV list selection menu
        main.select_tv_list()
        # Close directory properly
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'play_tv_collection':
        # Play random episode from TV collection
        main.play_random_tv_from_collection()
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'tv_guide':
        # Show TV guide
        main.show_tv_guide()
        # Close directory properly to prevent menu duplication
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    elif params.get('action') == 'play_specific_episode':
        # Play specific episode (triggered by service for next episode)
        tmdb_id = params.get('tmdb_id')
        season = int(params.get('season', 1))
        episode = int(params.get('episode', 1))
        title = params.get('title', 'Unknown')
        user = params.get('user', '')
        list_id = params.get('list_id', '')
        main.play_specific_episode(tmdb_id, season, episode, title, user, list_id)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:]))
    router(params)
