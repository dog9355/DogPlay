# -*- coding: utf-8 -*-
"""
Local Lists Module - Read hardcoded curated lists
"""
import json
import os
import xbmc

def get_local_list(list_type='movie'):
    """
    Load a local curated list from JSON file

    Args:
        list_type: 'movie' or 'episode'

    Returns:
        List of items with metadata, or None if file doesn't exist
    """
    addon_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

    if list_type == 'movie':
        list_file = os.path.join(addon_dir, 'resources', 'data', 'local_lists', 'curated_movies.json')
    else:
        list_file = os.path.join(addon_dir, 'resources', 'data', 'local_lists', 'curated_tv.json')

    if not os.path.exists(list_file):
        xbmc.log(f"DogPlay: Local list not found: {list_file}", xbmc.LOGINFO)
        return None

    try:
        with open(list_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        items = data.get('items', [])
        xbmc.log(f"DogPlay: Loaded {len(items)} items from local {list_type} list", xbmc.LOGINFO)
        return items

    except Exception as e:
        xbmc.log(f"DogPlay: Error loading local list: {str(e)}", xbmc.LOGERROR)
        return None

def get_local_list_info(list_type='movie'):
    """
    Get metadata about a local list (name, description, count)

    Args:
        list_type: 'movie' or 'episode'

    Returns:
        Dict with list metadata, or None if file doesn't exist
    """
    addon_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

    if list_type == 'movie':
        list_file = os.path.join(addon_dir, 'resources', 'data', 'local_lists', 'curated_movies.json')
    else:
        list_file = os.path.join(addon_dir, 'resources', 'data', 'local_lists', 'curated_tv.json')

    if not os.path.exists(list_file):
        return None

    try:
        with open(list_file, 'r', encoding='utf-8') as f:
            data = json.load(f)

        return {
            'name': data.get('list_name', 'Unknown'),
            'description': data.get('description', ''),
            'total_items': data.get('total_items', 0),
            'media_type': data.get('media_type', list_type)
        }

    except Exception as e:
        xbmc.log(f"DogPlay: Error loading local list info: {str(e)}", xbmc.LOGERROR)
        return None

def local_list_exists(list_type='movie'):
    """Check if a local list file exists"""
    addon_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

    if list_type == 'movie':
        list_file = os.path.join(addon_dir, 'resources', 'data', 'local_lists', 'curated_movies.json')
    else:
        list_file = os.path.join(addon_dir, 'resources', 'data', 'local_lists', 'curated_tv.json')

    return os.path.exists(list_file)
