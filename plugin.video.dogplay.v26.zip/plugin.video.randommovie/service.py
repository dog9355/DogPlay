# -*- coding: utf-8 -*-
"""Background service for DogPlay continuous playback monitoring"""
import xbmc
import xbmcaddon
import xbmcvfs
import sys

# Import FenlightAM modules
try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')
except:
    pass

addon = xbmcaddon.Addon('plugin.video.randommovie')

class DogPlayMonitor(xbmc.Monitor):
    """Service monitor for DogPlay"""
    def __init__(self):
        super().__init__()
        self.player = DogPlayPlayer()
        xbmc.log("DogPlay Service: Monitor initialized", xbmc.LOGINFO)

    def run(self):
        """Main service loop"""
        xbmc.log("DogPlay Service: Starting service", xbmc.LOGINFO)
        while not self.abortRequested():
            if self.waitForAbort(1):
                break
        xbmc.log("DogPlay Service: Service stopped", xbmc.LOGINFO)

class DogPlayPlayer(xbmc.Player):
    """Player monitor for continuous playback"""
    def __init__(self):
        super().__init__()
        self.user = None
        self.list_id = None
        xbmc.log("DogPlay Service: Player monitor initialized", xbmc.LOGINFO)

    def onAVStarted(self):
        """Called when playback starts"""
        # Check if this is a DogPlay playback
        try:
            self.user = addon.getSetting('current_user')
            self.list_id = addon.getSetting('current_list_id')
            if self.user and self.list_id:
                xbmc.log(f"DogPlay Service: Playback started - monitoring for list {self.list_id}", xbmc.LOGINFO)
        except:
            pass

    def onPlayBackEnded(self):
        """Called when playback ends naturally"""
        xbmc.log("DogPlay Service: onPlayBackEnded - Movie finished naturally", xbmc.LOGINFO)

        continuous_play = addon.getSetting('continuous_play') == 'true'

        if continuous_play and self.user and self.list_id:
            xbmc.log(f"DogPlay Service: Continuous play enabled, playing next movie in 3 seconds", xbmc.LOGINFO)
            xbmc.sleep(3000)

            # Trigger next movie playback
            try:
                xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.randommovie/?action=play_next&user={self.user}&list_id={self.list_id})')
            except Exception as e:
                xbmc.log(f"DogPlay Service: Error triggering next movie: {str(e)}", xbmc.LOGERROR)
        else:
            xbmc.log("DogPlay Service: Continuous play disabled or no list info", xbmc.LOGINFO)
            # Clear the current playback info
            addon.setSetting('current_user', '')
            addon.setSetting('current_list_id', '')

    def onPlayBackStopped(self):
        """Called when user manually stops playback"""
        xbmc.log("DogPlay Service: onPlayBackStopped - User stopped manually", xbmc.LOGINFO)
        # Clear the current playback info so it doesn't auto-play next
        addon.setSetting('current_user', '')
        addon.setSetting('current_list_id', '')

if __name__ == '__main__':
    monitor = DogPlayMonitor()
    monitor.run()
