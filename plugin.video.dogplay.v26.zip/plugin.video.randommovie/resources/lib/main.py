# -*- coding: utf-8 -*-
import sys
import random
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Try to import FenlightAM modules
trakt_api = None
settings_cache = None
sources = None

try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')

    from apis import trakt_api as ta
    from caches import settings_cache as sc
    from modules.sources import Sources
    from modules.settings import playback_key, tmdb_api_key
    from apis.tmdb_api import tmdb_movies_year
    trakt_api = ta
    settings_cache = sc
    sources = Sources
except Exception as e:
    xbmc.log(f"DogPlay: Failed to import FenlightAM modules: {str(e)}", xbmc.LOGERROR)

addon = xbmcaddon.Addon()

def get_addon_setting(setting_id, setting_type='bool'):
    """Get addon setting with type conversion"""
    if setting_type == 'bool':
        return addon.getSetting(setting_id) == 'true'
    elif setting_type == 'int':
        try:
            return int(addon.getSetting(setting_id))
        except:
            return 0
    else:  # string
        return addon.getSetting(setting_id)

def check_fenlight_auth():
    """Check if FenlightAM is authenticated with Trakt"""
    if not settings_cache or not trakt_api:
        xbmcgui.Dialog().ok('FenlightAM Not Available',
                          'FenlightAM addon is required. Please install FenlightAM and try again.')
        return False

    try:
        trakt_user = settings_cache.get_setting('fenlight.trakt.user')
        if not trakt_user or trakt_user in ('', 'empty_setting'):
            xbmcgui.Dialog().ok('Authentication Required',
                              'Please authenticate with Trakt in FenlightAM first. Go to FenlightAM > Tools > Trakt > Authorize')
            return False
        return True
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Could not access FenlightAM settings: {str(e)}')
        return False

def get_trakt_lists():
    """Get user's Trakt lists using FenlightAM's API"""
    try:
        # Get user's lists
        lists = trakt_api.trakt_get_lists('my_lists')

        if not lists:
            xbmcgui.Dialog().ok('No Lists Found', 'No Trakt lists found for your account.')
            return []

        return lists
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch Trakt lists: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch lists: {str(e)}", xbmc.LOGERROR)
        return []

def get_list_items(user, list_id):
    """Get movies from a Trakt list"""
    try:
        # Fetch list contents from Trakt
        items = trakt_api.get_trakt_list_contents('movies', user, list_id, with_auth=True)

        if not items:
            xbmcgui.Dialog().ok('Empty List', 'This list contains no movies.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch list items: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch list items: {str(e)}", xbmc.LOGERROR)
        return []

def play_random_movie(user, list_id):
    """Select and play a random movie from the list"""
    if not check_fenlight_auth():
        return

    # Save current playback info for the service to monitor
    addon.setSetting('current_user', user)
    addon.setSetting('current_list_id', str(list_id))
    xbmc.log(f"DogPlay: Saved playback info - User: {user}, List ID: {list_id}", xbmc.LOGINFO)

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching list contents...')

    # Get movies from list
    movies = get_list_items(user, list_id)

    if not movies:
        progress.close()
        return

    progress.update(50, 'Selecting random movie...')

    # Select random movie
    random_movie = random.choice(movies)

    movie_title = random_movie.get('title', 'Unknown')
    progress.update(75, f"Selected: {movie_title}")

    # Get movie identifiers from media_ids
    media_ids = random_movie.get('media_ids', {})
    tmdb_id = media_ids.get('tmdb')
    imdb_id = media_ids.get('imdb')

    progress.close()

    # Play via FenlightAM's Sources directly
    if tmdb_id or imdb_id:
        try:
            # Get movie metadata to find runtime
            from apis.tmdb_api import movie_details
            from modules import watched_status
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 0) if meta else 0

            # Calculate random position based on settings
            random_percent = 0.0
            random_start_enabled = get_addon_setting('random_start_enabled')

            if runtime > 0 and random_start_enabled:
                runtime_seconds = runtime * 60  # Convert minutes to seconds
                min_percent = float(get_addon_setting('min_start_percent', 'int'))
                max_percent = float(get_addon_setting('max_start_percent', 'int'))

                # Ensure min < max
                if min_percent >= max_percent:
                    min_percent = 5.0
                    max_percent = 80.0

                random_percent = random.uniform(min_percent, max_percent)
                seek_position = int((random_percent / 100.0) * runtime_seconds)

                xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% ({seek_position//60}m {seek_position%60}s) in {runtime}min movie", xbmc.LOGINFO)

                # Set bookmark using FenlightAM's format
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': movie_title,
                    'from_playback': 'false'
                }
                watched_status.set_bookmark(bookmark_params)
            else:
                xbmc.log(f"DogPlay: Starting from beginning (random start disabled)", xbmc.LOGINFO)

            # Get the playback key to authenticate with FenlightAM
            key = playback_key()
            # Build params for FenlightAM playback with auth key
            params = {
                'tmdb_id': str(tmdb_id) if tmdb_id else '',
                'media_type': 'movie',
                key: 'true'  # Add the playback key to bypass external check
            }

            # Create Sources instance and override get_playback_percent to force our random position
            source_instance = sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                # If we have a random position, return it directly (bypassing resume dialog)
                if random_percent > 0:
                    xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                    return float(random_percent)
                # Otherwise use the original method
                return original_get_playback_percent()

            # Replace the method with our custom one
            source_instance.get_playback_percent = forced_get_playback_percent

            # Call FenlightAM's playback function - it will use our custom get_playback_percent
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay: Playback error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')
    else:
        xbmcgui.Dialog().ok('Error', 'Could not find movie ID to play')

def select_list():
    """Show list selection dialog or use saved list based on settings"""
    if not check_fenlight_auth():
        return

    list_mode = get_addon_setting('list_mode', 'string')

    if list_mode == 'single':
        # Use saved list
        user = get_addon_setting('saved_list_user', 'string')
        list_id = get_addon_setting('saved_list_id', 'string')

        if not user or not list_id:
            xbmcgui.Dialog().ok('No Saved List',
                              'No list configured. Please go to Settings > List Settings and click "Select Trakt List".')
            return

        play_random_movie(user, list_id)
    else:
        # Show list selection dialog
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay', 'Fetching your Trakt lists...')

        lists = get_trakt_lists()
        progress.close()

        if not lists:
            return

        # Create list selection dialog
        list_names = [l.get('name', 'Unnamed List') for l in lists]
        selected = xbmcgui.Dialog().select('Select a Trakt List', list_names)

        if selected < 0:
            return

        # Get selected list details
        selected_list = lists[selected]
        user = selected_list.get('user', {}).get('ids', {}).get('slug')
        list_id = selected_list.get('ids', {}).get('trakt')
        list_name = selected_list.get('name', 'Unknown List')

        if user and list_id:
            # Save the list info to settings for easy access
            addon.setSetting('saved_list_user', user)
            addon.setSetting('saved_list_id', str(list_id))
            addon.setSetting('saved_list_name', list_name)
            play_random_movie(user, list_id)

def open_settings():
    """Open addon settings"""
    addon.openSettings()

def show_movie_guide():
    """Show the EPG-style movie guide"""
    if not check_fenlight_auth():
        return

    # Get the list to use
    list_mode = get_addon_setting('list_mode', 'string')

    if list_mode == 'single':
        user = get_addon_setting('saved_list_user', 'string')
        list_id = get_addon_setting('saved_list_id', 'string')

        if not user or not list_id:
            xbmcgui.Dialog().ok('No Saved List',
                              'Please configure a list in Settings first.')
            return
    else:
        # Show list selection
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay', 'Fetching your Trakt lists...')

        lists = get_trakt_lists()
        progress.close()

        if not lists:
            return

        list_names = [l.get('name', 'Unnamed List') for l in lists]
        selected = xbmcgui.Dialog().select('Select a Trakt List for Movie Guide', list_names)

        if selected < 0:
            return

        selected_list = lists[selected]
        user = selected_list.get('user', {}).get('ids', {}).get('slug')
        list_id = selected_list.get('ids', {}).get('trakt')

        if not user or not list_id:
            return

    # Get movies from the list
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Loading movie guide...')

    movies = get_list_items(user, list_id)
    progress.close()

    if not movies:
        return

    # Show the guide
    from resources.lib.movie_guide import show_movie_guide
    show_movie_guide(movies)

def main_menu(addon_handle, base_url):
    """Display main menu"""
    if not check_fenlight_auth():
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Create play menu item
    li = xbmcgui.ListItem('Play Random Movie')
    url = f'{base_url}?action=select_list'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # Create movie guide menu item
    li = xbmcgui.ListItem('View Movie Guide')
    url = f'{base_url}?action=movie_guide'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # Create settings menu item
    li = xbmcgui.ListItem('Settings')
    url = f'{base_url}?action=settings'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    xbmcplugin.endOfDirectory(addon_handle)
