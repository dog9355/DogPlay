# -*- coding: utf-8 -*-
"""Movie Guide - EPG-style grid showing random movies on virtual channels"""
import random
import xbmc
import xbmcgui
import xbmcaddon
from datetime import datetime, timedelta
import colorsys

addon = xbmcaddon.Addon()

class MovieGuide:
    """Generate EPG-style movie guide data"""

    def __init__(self, movies, num_channels=5, hours_to_show=6):
        self.movies = movies
        self.num_channels = num_channels
        self.hours_to_show = hours_to_show
        self.channels = []
        self.current_time = datetime.now()

    def generate_guide(self):
        """Generate the guide data for all channels"""
        self.channels = []

        for channel_num in range(1, self.num_channels + 1):
            channel = {
                'number': channel_num,
                'name': f'DogPlay {channel_num}',
                'schedule': []
            }

            # Generate schedule for this channel
            current_time = self.current_time
            end_time = current_time + timedelta(hours=self.hours_to_show)

            while current_time < end_time:
                # Pick a random movie
                movie = random.choice(self.movies)
                movie_title = movie.get('title', 'Unknown Movie')

                # Get runtime (default to 90 minutes if not available)
                media_ids = movie.get('media_ids', {})
                tmdb_id = media_ids.get('tmdb')

                # For now, use a random runtime between 80-180 minutes
                # In a real implementation, you'd fetch this from TMDb
                runtime_minutes = random.randint(80, 180)

                # Calculate when this movie starts and ends
                start_time = current_time
                end_time_slot = start_time + timedelta(minutes=runtime_minutes)

                # Calculate progress (how far into the movie we are)
                now = datetime.now()
                if now >= start_time and now < end_time_slot:
                    elapsed = (now - start_time).total_seconds() / 60  # minutes
                    progress_percent = (elapsed / runtime_minutes) * 100
                else:
                    progress_percent = 0

                schedule_item = {
                    'movie': movie,
                    'title': movie_title,
                    'tmdb_id': tmdb_id,
                    'start_time': start_time,
                    'end_time': end_time_slot,
                    'runtime': runtime_minutes,
                    'progress': progress_percent
                }

                channel['schedule'].append(schedule_item)
                current_time = end_time_slot

            self.channels.append(channel)

        return self.channels

class MovieGuideWindow(xbmcgui.Window):
    """Custom window for displaying the movie guide grid"""

    def __init__(self):
        super().__init__()
        self.channels = []
        self.movies_data = []
        self.user = ''
        self.list_id = ''
        self.bar_controls = []
        self.bar_data = []

        # Grid settings
        self.grid_left = 200
        self.grid_top = 150
        self.channel_height = 150
        self.grid_width = 1520
        self.pixels_per_minute = 3  # How many pixels per minute of movie runtime

    def set_data(self, channels, movies_data, user, list_id):
        """Set the data for the guide"""
        self.channels = channels
        self.movies_data = movies_data
        self.user = user
        self.list_id = list_id

    def onInit(self):
        """Initialize the window and create the grid"""
        try:
            xbmc.log("DogPlay MovieGuide: Starting onInit", xbmc.LOGINFO)

            # Set black background using window property
            self.setProperty('background', '0xFF000000')

            # Create title
            title = xbmcgui.ControlLabel(60, 40, 1800, 60, 'DogPlay Movie Guide',
                                        font='font30_title', textColor='0xFFFFFFFF')
            self.addControl(title)
            xbmc.log("DogPlay MovieGuide: Added title", xbmc.LOGINFO)

            # Create current time label
            time_label = xbmcgui.ControlLabel(60, 100, 1800, 40,
                                             f"Current Time: {datetime.now().strftime('%I:%M %p')}",
                                             font='font13', textColor='0xFFFFFFFF')
            self.addControl(time_label)
            xbmc.log("DogPlay MovieGuide: Added time label", xbmc.LOGINFO)

            # Draw the grid
            self._draw_grid()
            xbmc.log("DogPlay MovieGuide: Grid drawn", xbmc.LOGINFO)

            # Add instructions
            instructions = xbmcgui.ControlLabel(60, 1000, 1800, 40,
                                               'Click on a movie bar to start playing - Press ESC to close',
                                               font='font13', textColor='0xFFAAAAAA')
            self.addControl(instructions)
            xbmc.log("DogPlay MovieGuide: onInit complete", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"DogPlay MovieGuide: Error in onInit: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay MovieGuide: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            raise

    def _get_color_for_movie(self, movie_index):
        """Generate a distinct color for each movie"""
        # Use HSV color space for visually distinct colors
        hue = (movie_index * 0.618033988749895) % 1.0  # Golden ratio for good distribution
        saturation = 0.7
        value = 0.9

        r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)

        # Convert to Kodi color format (0xAARRGGBB)
        return f"0xFF{int(r*255):02X}{int(g*255):02X}{int(b*255):02X}"

    def _draw_grid(self):
        """Draw the movie guide grid"""
        current_time = datetime.now()

        for channel_idx, channel in enumerate(self.channels):
            y_pos = self.grid_top + (channel_idx * self.channel_height)

            # Draw channel label
            channel_label = xbmcgui.ControlLabel(
                60, y_pos + 55, 130, 40,
                f"Ch {channel['number']}",
                font='font13', textColor='0xFFFFFFFF'
            )
            self.addControl(channel_label)

            # Draw movies for this channel
            x_offset = 0

            for movie_idx, item in enumerate(channel['schedule']):
                # Calculate bar width based on runtime
                bar_width = item['runtime'] * self.pixels_per_minute

                # Stop if we exceed grid width
                if x_offset + bar_width > self.grid_width:
                    bar_width = self.grid_width - x_offset
                    if bar_width <= 0:
                        break

                # Get color for this movie
                color = self._get_color_for_movie(hash(item['title']) % 20)

                # Create colored bar button
                bar_x = self.grid_left + x_offset
                bar_y = y_pos + 10
                bar_height = 130

                # Create the bar as a button so it's clickable
                # Use empty string for textures and rely on colorDiffuse
                bar_button = xbmcgui.ControlButton(
                    bar_x, bar_y, int(bar_width), bar_height,
                    item['title'][:30],  # Truncate long titles
                    font='font12',
                    textColor='0xFFFFFFFF',
                    focusedColor='0xFFFFFFFF',
                    shadowColor='0xFF000000',
                    focusTexture='',
                    noFocusTexture='',
                    alignment=0x00000004 | 0x00000001  # Center align
                )

                # Set the button color
                try:
                    bar_button.setColorDiffuse(color)
                except:
                    pass

                self.addControl(bar_button)

                # Store bar data for click handling
                self.bar_controls.append(bar_button)
                self.bar_data.append({
                    'schedule_item': item,
                    'channel': channel,
                    'bar_x': bar_x,
                    'bar_width': bar_width
                })

                # Add progress indicator if movie is currently playing
                if current_time >= item['start_time'] and current_time < item['end_time']:
                    progress_width = int((item['progress'] / 100.0) * bar_width)
                    if progress_width > 5:
                        # Add a green overlay label to show progress
                        progress_label = xbmcgui.ControlLabel(
                            bar_x, bar_y, progress_width, 10,
                            '▓' * int(progress_width / 10),
                            font='font10', textColor='0xFF00FF00'
                        )
                        self.addControl(progress_label)

                x_offset += bar_width

    def onControl(self, control):
        """Handle control clicks"""
        try:
            # Find which bar was clicked
            for idx, bar_control in enumerate(self.bar_controls):
                if control == bar_control:
                    bar_info = self.bar_data[idx]
                    self._play_movie_at_position(bar_info['schedule_item'])
                    break
        except Exception as e:
            xbmc.log(f"DogPlay MovieGuide: Error in onControl: {str(e)}", xbmc.LOGERROR)

    def onAction(self, action):
        """Handle actions like ESC key"""
        if action.getId() in [10, 92]:  # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK
            self.close()

    def _play_movie_at_position(self, schedule_item):
        """Play a movie starting at its current "live" position"""
        try:
            from resources.lib import main
            import sys
            import xbmcvfs

            # Import FenlightAM modules
            fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
            fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
            if fenlight_path not in sys.path:
                sys.path.append(fenlight_path + '/resources/lib')

            from apis.tmdb_api import movie_details
            from modules import watched_status
            from modules.settings import playback_key, tmdb_api_key
            from modules.sources import Sources

            movie = schedule_item['movie']
            media_ids = movie.get('media_ids', {})
            tmdb_id = media_ids.get('tmdb')

            if not tmdb_id:
                xbmcgui.Dialog().ok('Error', 'Could not find movie ID')
                return

            # Calculate what position the movie should be at "live"
            current_time = datetime.now()
            elapsed_minutes = (current_time - schedule_item['start_time']).total_seconds() / 60
            runtime_minutes = schedule_item['runtime']

            if elapsed_minutes < 0:
                # Movie hasn't started yet, start from beginning
                seek_percent = 0.0
            elif elapsed_minutes >= runtime_minutes:
                # Movie is over, start from beginning anyway
                seek_percent = 0.0
            else:
                # Calculate percentage
                seek_percent = (elapsed_minutes / runtime_minutes) * 100.0

            xbmc.log(f"DogPlay MovieGuide: Playing {schedule_item['title']} at {seek_percent:.1f}%", xbmc.LOGINFO)

            # Get movie metadata
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', runtime_minutes) if meta else runtime_minutes
            runtime_seconds = runtime * 60

            # Set bookmark if we're not starting from the beginning
            if seek_percent > 0:
                seek_position = int((seek_percent / 100.0) * runtime_seconds)
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': schedule_item['title'],
                    'from_playback': 'false'
                }
                watched_status.set_bookmark(bookmark_params)

            # Get playback key and build params
            key = playback_key()
            params = {
                'tmdb_id': str(tmdb_id),
                'media_type': 'movie',
                key: 'true'
            }

            # Create Sources instance
            source_instance = Sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                if seek_percent > 0:
                    return float(seek_percent)
                return original_get_playback_percent()

            source_instance.get_playback_percent = forced_get_playback_percent

            # Close the guide window
            self.close()

            # Start playback
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay MovieGuide: Error playing movie: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')

def show_movie_guide(movies):
    """Display the movie guide dialog"""
    if not movies:
        xbmcgui.Dialog().ok('No Movies', 'No movies found in the list.')
        return

    # Generate guide data
    guide = MovieGuide(movies, num_channels=5, hours_to_show=6)
    channels = guide.generate_guide()

    # Get current list info for potential playback
    user = addon.getSetting('saved_list_user')
    list_id = addon.getSetting('saved_list_id')

    try:
        # Show the custom window
        window = MovieGuideWindow()
        window.set_data(channels, movies, user, list_id)
        window.doModal()
        del window

    except Exception as e:
        xbmc.log(f"DogPlay: Error showing movie guide window: {str(e)}", xbmc.LOGERROR)
        import traceback
        xbmc.log(f"DogPlay: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
        # Fallback to text view
        guide_text = build_guide_text(channels)
        xbmcgui.Dialog().textviewer('DogPlay Movie Guide', guide_text)

def build_guide_text(channels):
    """Build a text representation of the guide"""
    lines = []
    lines.append("=" * 80)
    lines.append("DOGPLAY MOVIE GUIDE - Live Now")
    lines.append("=" * 80)
    lines.append("")

    current_time = datetime.now()

    for channel in channels:
        lines.append(f"\n[B]Channel {channel['number']}: {channel['name']}[/B]")
        lines.append("-" * 80)

        for item in channel['schedule']:
            start_time_str = item['start_time'].strftime('%I:%M %p')
            end_time_str = item['end_time'].strftime('%I:%M %p')

            # Check if this movie is currently playing
            if current_time >= item['start_time'] and current_time < item['end_time']:
                status = f"[COLOR green]>> PLAYING NOW ({item['progress']:.0f}% complete)[/COLOR]"
            elif current_time < item['start_time']:
                status = "[COLOR yellow]Upcoming[/COLOR]"
            else:
                status = "[COLOR gray]Finished[/COLOR]"

            lines.append(f"{start_time_str} - {end_time_str} | {item['runtime']}min | {item['title']}")
            lines.append(f"                     {status}")
            lines.append("")

    lines.append("=" * 80)
    lines.append("Select a channel in the main menu to start watching!")

    return "\n".join(lines)
