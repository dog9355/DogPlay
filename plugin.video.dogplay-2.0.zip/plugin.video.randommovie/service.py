# -*- coding: utf-8 -*-
"""Background service for DogPlay continuous playback monitoring"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys

# Import FenlightAM modules
try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')
except:
    pass

addon = xbmcaddon.Addon('plugin.video.randommovie')

class DogPlayMonitor(xbmc.Monitor):
    """Service monitor for DogPlay"""
    def __init__(self):
        super().__init__()
        self.player = DogPlayPlayer()
        xbmc.log("DogPlay Service: Monitor initialized", xbmc.LOGINFO)

    def run(self):
        """Main service loop"""
        xbmc.log("DogPlay Service: Starting service", xbmc.LOGINFO)
        while not self.abortRequested():
            if self.waitForAbort(1):
                break
        xbmc.log("DogPlay Service: Service stopped", xbmc.LOGINFO)

class DogPlayPlayer(xbmc.Player):
    """Player monitor for continuous playback"""
    def __init__(self):
        super().__init__()
        self.user = None
        self.list_id = None
        self.current_tmdb_id = None
        self.current_title = None
        xbmc.log("DogPlay Service: Player monitor initialized", xbmc.LOGINFO)

    def onAVStarted(self):
        """Called when playback starts"""
        xbmc.log("=" * 80, xbmc.LOGINFO)
        xbmc.log("DogPlay Service: 🎬 onAVStarted() called", xbmc.LOGINFO)
        xbmc.log("=" * 80, xbmc.LOGINFO)
        
        # Verify this is actual video playback, not scraping
        # Give a longer delay to let the player stabilize and ensure scraping is complete
        xbmc.log("DogPlay Service: ⏱️  Waiting 2 seconds for player to stabilize...", xbmc.LOGINFO)
        xbmc.sleep(2000)
        
        # Check if player is still actually playing a video file
        xbmc.log("DogPlay Service: 🔍 Step 1: Checking if video is playing...", xbmc.LOGINFO)
        is_playing = self.isPlayingVideo()
        xbmc.log(f"DogPlay Service: isPlayingVideo() = {is_playing}", xbmc.LOGINFO)
        
        if not is_playing:
            xbmc.log("DogPlay Service: ❌ Not playing video - IGNORING (likely scraping)", xbmc.LOGINFO)
            xbmc.log("=" * 80, xbmc.LOGINFO)
            return
        
        # Additional verification: check if we have an actual file playing (not just initializing)
        xbmc.log("DogPlay Service: 🔍 Step 2: Checking playing file...", xbmc.LOGINFO)
        try:
            playing_file = self.getPlayingFile()
            xbmc.log(f"DogPlay Service: getPlayingFile() = {playing_file if playing_file else 'EMPTY'}", xbmc.LOGINFO)
            
            if not playing_file or len(playing_file) < 5:
                xbmc.log("DogPlay Service: ❌ No valid playing file - IGNORING", xbmc.LOGINFO)
                xbmc.log("=" * 80, xbmc.LOGINFO)
                return
            xbmc.log(f"DogPlay Service: ✅ Verified video file: {playing_file[:80]}...", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: ❌ Exception getting playing file: {str(e)} - IGNORING", xbmc.LOGINFO)
            xbmc.log("=" * 80, xbmc.LOGINFO)
            return
        
        # NOW check if this is a DogPlay playback by looking for PENDING properties
        xbmc.log("DogPlay Service: 🔍 Step 3: Checking for PENDING DogPlay properties...", xbmc.LOGINFO)
        try:
            window = xbmcgui.Window(10000)
            pending_user = window.getProperty('dogplay.pending_user')
            pending_list_id = window.getProperty('dogplay.pending_list_id')
            pending_tmdb_id = window.getProperty('dogplay.pending_tmdb_id')
            pending_title = window.getProperty('dogplay.pending_title')

            xbmc.log(f"DogPlay Service: Pending properties found:", xbmc.LOGINFO)
            xbmc.log(f"  - pending_user: '{pending_user}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_list_id: '{pending_list_id}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_tmdb_id: '{pending_tmdb_id}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_title: '{pending_title}'", xbmc.LOGINFO)

            if pending_tmdb_id:  # We have a pending DogPlay playback
                xbmc.log("DogPlay Service: ✅ PENDING DOGPLAY PLAYBACK DETECTED!", xbmc.LOGINFO)
                xbmc.log("DogPlay Service: 🎯 Activating pending → current properties...", xbmc.LOGINFO)
                
                # Playback confirmed! Activate the pending properties as current
                self.user = pending_user
                self.list_id = pending_list_id
                self.current_tmdb_id = pending_tmdb_id
                self.current_title = pending_title
                
                # Set current properties for other components to use
                window.setProperty('dogplay.current_user', self.user)
                window.setProperty('dogplay.current_list_id', self.list_id)
                window.setProperty('dogplay.current_tmdb_id', self.current_tmdb_id)
                window.setProperty('dogplay.current_title', self.current_title)
                
                xbmc.log("DogPlay Service: 📝 Set CURRENT properties:", xbmc.LOGINFO)
                xbmc.log(f"  - current_user: '{self.user}'", xbmc.LOGINFO)
                xbmc.log(f"  - current_list_id: '{self.list_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - current_tmdb_id: '{self.current_tmdb_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - current_title: '{self.current_title}'", xbmc.LOGINFO)
                
                # Clear pending properties
                window.clearProperty('dogplay.pending_user')
                window.clearProperty('dogplay.pending_list_id')
                window.clearProperty('dogplay.pending_tmdb_id')
                window.clearProperty('dogplay.pending_title')
                
                xbmc.log("DogPlay Service: 🧹 Cleared all PENDING properties", xbmc.LOGINFO)
                xbmc.log(f"DogPlay Service: ✅✅✅ CONFIRMED PLAYBACK - Now tracking '{self.current_title}' (TMDB: {self.current_tmdb_id})", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay Service: ℹ️  No pending_tmdb_id - this is NOT a DogPlay movie", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: ❌ Error checking pending properties: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
        
        xbmc.log("=" * 80, xbmc.LOGINFO)
        xbmc.log("DogPlay Service: onAVStarted() complete", xbmc.LOGINFO)
        xbmc.log("=" * 80, xbmc.LOGINFO)

    def onPlayBackEnded(self):
        """Called when playback ends naturally"""
        xbmc.log("DogPlay Service: onPlayBackEnded - Movie finished naturally", xbmc.LOGINFO)

        # Clear Trakt progress if setting is enabled
        self._clear_trakt_progress_if_enabled()

        continuous_play = addon.getSetting('continuous_play') == 'true'

        xbmc.log(f"DogPlay Service: continuous_play={continuous_play}, user='{self.user}', list_id='{self.list_id}'", xbmc.LOGINFO)

        if continuous_play and self.user and self.list_id:
            xbmc.log(f"DogPlay Service: Continuous play enabled, playing next movie in 3 seconds", xbmc.LOGINFO)
            xbmc.sleep(3000)

            # Trigger next movie playback
            try:
                xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.randommovie/?action=play_next&user={self.user}&list_id={self.list_id})')
            except Exception as e:
                xbmc.log(f"DogPlay Service: Error triggering next movie: {str(e)}", xbmc.LOGERROR)
        else:
            xbmc.log("DogPlay Service: Continuous play disabled or no list info", xbmc.LOGINFO)
            # Clear the current playback info
            self._clear_current_playback_info()

    def onPlayBackStopped(self):
        """Called when user manually stops playback"""
        xbmc.log("DogPlay Service: 🛑 onPlayBackStopped - User stopped manually", xbmc.LOGINFO)
        
        # If we have current tracking info, use it. Otherwise, check for PENDING info.
        # This handles cases where user cancels DURING scraping.
        if not self.current_tmdb_id:
            try:
                window = xbmcgui.Window(10000)
                pending_tmdb_id = window.getProperty('dogplay.pending_tmdb_id')
                pending_title = window.getProperty('dogplay.pending_title')
                if pending_tmdb_id:
                    xbmc.log(f"DogPlay Service: Found PENDING tracking for cancelled playback - '{pending_title}' (TMDB: {pending_tmdb_id})", xbmc.LOGINFO)
                    self.current_tmdb_id = pending_tmdb_id
                    self.current_title = pending_title
            except:
                pass

        xbmc.log(f"DogPlay Service: Current tracking - tmdb_id: '{self.current_tmdb_id}', title: '{self.current_title}'", xbmc.LOGINFO)

        # Clear Trakt progress if setting is enabled
        self._clear_trakt_progress_if_enabled()

        # Clear the current playback info so it doesn't auto-play next
        self._clear_current_playback_info()
        xbmc.log("DogPlay Service: 🧹 All properties cleared", xbmc.LOGINFO)
        xbmc.log("DogPlay Service: 🧹 All properties cleared", xbmc.LOGINFO)

    def _clear_current_playback_info(self):
        """Clear current playback tracking properties"""
        xbmc.log("DogPlay Service: 🧹 Clearing all playback properties...", xbmc.LOGINFO)
        window = xbmcgui.Window(10000)
        # Clear current properties
        window.clearProperty('dogplay.current_user')
        window.clearProperty('dogplay.current_list_id')
        window.clearProperty('dogplay.current_tmdb_id')
        window.clearProperty('dogplay.current_title')
        # Also clear any pending properties (in case playback was cancelled during scraping)
        window.clearProperty('dogplay.pending_user')
        window.clearProperty('dogplay.pending_list_id')
        window.clearProperty('dogplay.pending_tmdb_id')
        window.clearProperty('dogplay.pending_title')
        
        xbmc.log("DogPlay Service: ✅ Cleared all CURRENT and PENDING properties", xbmc.LOGINFO)
        
        self.user = None
        self.list_id = None
        self.current_tmdb_id = None
        self.current_title = None

    def _clear_trakt_progress_if_enabled(self):
        """Clear the movie from Trakt 'In Progress' if setting is enabled"""
        try:
            clear_enabled = addon.getSetting('clear_trakt_progress') == 'true'

            xbmc.log(f"DogPlay Service: Trakt clear check - enabled={clear_enabled}, tmdb_id='{self.current_tmdb_id}', title='{self.current_title}'", xbmc.LOGINFO)

            if clear_enabled and self.current_tmdb_id:
                xbmc.log(f"DogPlay Service: Clearing Trakt progress for TMDB ID {self.current_tmdb_id}", xbmc.LOGINFO)

                # Import FenlightAM's watched_status module
                from modules import watched_status

                # Erase the bookmark using correct function signature
                # erase_bookmark(media_type, media_id, season='', episode='', refresh='false')
                watched_status.erase_bookmark('movie', str(self.current_tmdb_id), '', '', 'false')
                xbmc.log(f"DogPlay Service: Cleared Trakt progress for '{self.current_title}'", xbmc.LOGINFO)
            elif not clear_enabled:
                xbmc.log("DogPlay Service: Clear Trakt progress disabled in settings", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: Error clearing Trakt progress: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)

if __name__ == '__main__':
    monitor = DogPlayMonitor()
    monitor.run()
