# -*- coding: utf-8 -*-
import sys
import os
import random
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Try to import FenlightAM modules
trakt_api = None
settings_cache = None
sources = None

try:
    fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
    fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
    sys.path.append(fenlight_path + '/resources/lib')

    from apis import trakt_api as ta
    from caches import settings_cache as sc
    from modules.sources import Sources
    from modules.settings import playback_key, tmdb_api_key
    from apis.tmdb_api import tmdb_movies_year
    trakt_api = ta
    settings_cache = sc
    sources = Sources
except Exception as e:
    xbmc.log(f"DogPlay: Failed to import FenlightAM modules: {str(e)}", xbmc.LOGERROR)

addon = xbmcaddon.Addon()

def get_addon_setting(setting_id, setting_type='bool'):
    """Get addon setting with type conversion"""
    if setting_type == 'bool':
        return addon.getSetting(setting_id) == 'true'
    elif setting_type == 'int':
        try:
            return int(addon.getSetting(setting_id))
        except:
            return 0
    else:  # string
        return addon.getSetting(setting_id)

def check_fenlight_auth():
    """Check if FenlightAM is authenticated with Trakt"""
    if not settings_cache or not trakt_api:
        xbmcgui.Dialog().ok('FenlightAM Not Available',
                          'FenlightAM addon is required. Please install FenlightAM and try again.')
        return False

    try:
        trakt_user = settings_cache.get_setting('fenlight.trakt.user')
        if not trakt_user or trakt_user in ('', 'empty_setting'):
            xbmcgui.Dialog().ok('Authentication Required',
                              'Please authenticate with Trakt in FenlightAM first. Go to FenlightAM > Tools > Trakt > Authorize')
            return False
        return True
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Could not access FenlightAM settings: {str(e)}')
        return False

def get_trakt_lists():
    """Get user's Trakt lists using FenlightAM's API"""
    try:
        # Get user's lists
        lists = trakt_api.trakt_get_lists('my_lists')

        if not lists:
            xbmcgui.Dialog().ok('No Lists Found', 'No Trakt lists found for your account.')
            return []

        return lists
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch Trakt lists: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch lists: {str(e)}", xbmc.LOGERROR)
        return []

def get_list_items(user, list_id):
    """Get movies from a Trakt list"""
    try:
        # Fetch list contents from Trakt
        items = trakt_api.get_trakt_list_contents('movies', user, list_id, with_auth=True)

        if not items:
            xbmcgui.Dialog().ok('Empty List', 'This list contains no movies.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch list items: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch list items: {str(e)}", xbmc.LOGERROR)
        return []

def get_collection_items():
    """Get movies from user's Trakt collection"""
    try:
        # Fetch collection from Trakt
        items = trakt_api.trakt_collection('movies', None)

        if not items:
            xbmcgui.Dialog().ok('Empty Collection', 'Your Trakt movie collection is empty.')
            return []

        return items
    except Exception as e:
        xbmcgui.Dialog().ok('Error', f'Failed to fetch collection: {str(e)}')
        xbmc.log(f"DogPlay: Failed to fetch collection: {str(e)}", xbmc.LOGERROR)
        return []

def play_random_movie(user, list_id):
    """Select and play a random movie from the list"""
    if not check_fenlight_auth():
        return

    # Set PENDING playback info - service will activate these only after confirming real playback
    window = xbmcgui.Window(10000)
    window.setProperty('dogplay.pending_user', user)
    window.setProperty('dogplay.pending_list_id', str(list_id))
    window.setProperty('dogplay.pending_tmdb_id', '')  # Will be set after movie selection
    window.setProperty('dogplay.pending_title', '')  # Will be set after movie selection
    xbmc.log(f"DogPlay: Set pending playback info - User: {user}, List ID: {list_id}", xbmc.LOGINFO)

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching list contents...')

    # Get movies from list
    movies = get_list_items(user, list_id)

    if not movies:
        progress.close()
        return

    progress.update(50, 'Selecting random movie...')

    # Select random movie
    random_movie = random.choice(movies)

    movie_title = random_movie.get('title', 'Unknown')
    progress.update(75, f"Selected: {movie_title}")

    # Get movie identifiers from media_ids
    media_ids = random_movie.get('media_ids', {})
    tmdb_id = media_ids.get('tmdb')
    imdb_id = media_ids.get('imdb')

    # Update pending movie info for service monitoring
    window.setProperty('dogplay.pending_tmdb_id', str(tmdb_id) if tmdb_id else '')
    window.setProperty('dogplay.pending_title', movie_title)
    xbmc.log(f"DogPlay: Updated pending properties - tmdb_id='{tmdb_id}', title='{movie_title}'", xbmc.LOGINFO)

    progress.close()

    # Play via FenlightAM's Sources directly
    if tmdb_id or imdb_id:
        try:
            # Get movie metadata to find runtime
            from apis.tmdb_api import movie_details
            from modules import watched_status
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 0) if meta else 0

            # Calculate random position based on settings
            random_percent = 0.0
            random_start_enabled = get_addon_setting('random_start_enabled')

            if runtime > 0 and random_start_enabled:
                runtime_seconds = runtime * 60  # Convert minutes to seconds
                min_percent = float(get_addon_setting('min_start_percent', 'int'))
                max_percent = float(get_addon_setting('max_start_percent', 'int'))

                # Ensure min < max
                if min_percent >= max_percent:
                    min_percent = 5.0
                    max_percent = 80.0

                random_percent = random.uniform(min_percent, max_percent)
                seek_position = int((random_percent / 100.0) * runtime_seconds)

                xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% ({seek_position//60}m {seek_position%60}s) in {runtime}min movie", xbmc.LOGINFO)

                # Set bookmark using FenlightAM's format
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': movie_title,
                    'from_playback': 'false'
                }
                # watched_status.set_bookmark(bookmark_params)
                xbmc.log(f"DogPlay: ℹ️ skipped Trakt bookmark - using forced start percentage instead", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay: Starting from beginning (random start disabled)", xbmc.LOGINFO)

            # Get the playback key to authenticate with FenlightAM
            key = playback_key()
            # Build params for FenlightAM playback with auth key
            params = {
                'tmdb_id': str(tmdb_id) if tmdb_id else '',
                'media_type': 'movie',
                key: 'true'  # Add the playback key to bypass external check
            }

            # Create Sources instance and override get_playback_percent to force our random position
            source_instance = sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                # If we have a random position, return it directly (bypassing resume dialog)
                if random_percent > 0:
                    xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                    return float(random_percent)
                # Otherwise use the original method
                return original_get_playback_percent()

            # Replace the method with our custom one
            source_instance.get_playback_percent = forced_get_playback_percent

            # Call FenlightAM's playback function - it will use our custom get_playback_percent
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay: Playback error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')
    else:
        xbmcgui.Dialog().ok('Error', 'Could not find movie ID to play')

def play_random_from_collection():
    """Play a random movie from user's Trakt collection"""
    if not check_fenlight_auth():
        return

    # Show progress dialog
    progress = xbmcgui.DialogProgress()
    progress.create('DogPlay', 'Fetching your Trakt collection...')

    # Get movies from collection
    movies = get_collection_items()

    if not movies:
        progress.close()
        return

    progress.update(50, 'Selecting random movie...')

    # Select random movie
    random_movie = random.choice(movies)

    movie_title = random_movie.get('title', 'Unknown')
    progress.update(75, f"Selected: {movie_title}")

    # Get movie identifiers from media_ids
    media_ids = random_movie.get('media_ids', {})
    tmdb_id = media_ids.get('tmdb')
    imdb_id = media_ids.get('imdb')

    # Set pending movie info for service monitoring
    window = xbmcgui.Window(10000)
    window.setProperty('dogplay.pending_tmdb_id', str(tmdb_id))
    window.setProperty('dogplay.pending_title', movie_title)
    window.setProperty('dogplay.pending_user', '')  # Collection playback has no list
    window.setProperty('dogplay.pending_list_id', '')
    xbmc.log(f"DogPlay Collection: Set pending properties - tmdb_id='{tmdb_id}', title='{movie_title}'", xbmc.LOGINFO)

    progress.close()

    # Play via FenlightAM's Sources directly
    if tmdb_id or imdb_id:
        try:
            # Get movie metadata to find runtime
            from apis.tmdb_api import movie_details
            from modules import watched_status
            api_key = tmdb_api_key()
            meta = movie_details(tmdb_id, api_key)
            runtime = meta.get('runtime', 0) if meta else 0

            # Calculate random position based on settings
            random_percent = 0.0
            random_start_enabled = get_addon_setting('random_start_enabled')

            if runtime > 0 and random_start_enabled:
                runtime_seconds = runtime * 60  # Convert minutes to seconds
                min_percent = float(get_addon_setting('min_start_percent', 'int'))
                max_percent = float(get_addon_setting('max_start_percent', 'int'))

                # Ensure min < max
                if min_percent >= max_percent:
                    min_percent = 5.0
                    max_percent = 80.0

                random_percent = random.uniform(min_percent, max_percent)
                seek_position = int((random_percent / 100.0) * runtime_seconds)

                xbmc.log(f"DogPlay: Setting resume to {random_percent:.1f}% ({seek_position//60}m {seek_position%60}s) in {runtime}min movie", xbmc.LOGINFO)

                # Set bookmark using FenlightAM's format
                bookmark_params = {
                    'media_type': 'movie',
                    'tmdb_id': str(tmdb_id),
                    'curr_time': str(seek_position),
                    'total_time': str(runtime_seconds),
                    'title': movie_title,
                    'from_playback': 'false'
                }
                # watched_status.set_bookmark(bookmark_params)
                xbmc.log(f"DogPlay: ℹ️ skipped Trakt bookmark - using forced start percentage instead", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay: Starting from beginning (random start disabled)", xbmc.LOGINFO)

            # Get the playback key to authenticate with FenlightAM
            key = playback_key()
            # Build params for FenlightAM playback with auth key
            params = {
                'tmdb_id': str(tmdb_id) if tmdb_id else '',
                'media_type': 'movie',
                key: 'true'  # Add the playback key to bypass external check
            }

            # Create Sources instance and override get_playback_percent to force our random position
            source_instance = sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                # If we have a random position, return it directly (bypassing resume dialog)
                if random_percent > 0:
                    xbmc.log(f"DogPlay: Forcing playback to start at {random_percent:.1f}%", xbmc.LOGINFO)
                    return float(random_percent)
                # Otherwise use the original method
                return original_get_playback_percent()

            # Replace the method with our custom one
            source_instance.get_playback_percent = forced_get_playback_percent

            # Call FenlightAM's playback function - it will use our custom get_playback_percent
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay: Playback error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')
    else:
        xbmcgui.Dialog().ok('Error', 'Could not find movie ID to play')

def select_list():
    """Show list selection dialog or use saved list based on settings"""
    if not check_fenlight_auth():
        return

    list_mode = get_addon_setting('list_mode', 'string')

    if list_mode == 'single':
        # Use saved list
        user = get_addon_setting('saved_list_user', 'string')
        list_id = get_addon_setting('saved_list_id', 'string')

        if not user or not list_id:
            xbmcgui.Dialog().ok('No Saved List',
                              'No list configured. Please go to Settings > List Settings and click "Select Trakt List".')
            return

        play_random_movie(user, list_id)
    else:
        # Show list selection dialog
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay', 'Fetching your Trakt lists...')

        lists = get_trakt_lists()
        progress.close()

        if not lists:
            return

        # Create list selection dialog
        list_names = [l.get('name', 'Unnamed List') for l in lists]
        selected = xbmcgui.Dialog().select('Select a Trakt List', list_names)

        if selected < 0:
            return

        # Get selected list details
        selected_list = lists[selected]
        user = selected_list.get('user', {}).get('ids', {}).get('slug')
        list_id = selected_list.get('ids', {}).get('trakt')
        list_name = selected_list.get('name', 'Unknown List')

        if user and list_id:
            # Save the list info to settings for easy access
            addon.setSetting('saved_list_user', user)
            addon.setSetting('saved_list_id', str(list_id))
            addon.setSetting('saved_list_name', list_name)
            play_random_movie(user, list_id)

def open_settings():
    """Open addon settings"""
    addon.openSettings()
    # Refresh the list to update dynamic labels
    xbmc.executebuiltin('Container.Refresh')

def show_movie_guide():
    """Show the EPG-style movie guide"""
    if not check_fenlight_auth():
        return

    # Check guide source setting
    guide_source = get_addon_setting('guide_source', 'string')

    if guide_source == 'Trakt Collection':
        # Get movies from collection
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading movies from your collection...')

        movies = get_collection_items()
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in your Trakt collection.')
            return
    elif guide_source == 'Top 1000 Movies of all Time':
        # Get movies from Top 1000 list
        user = 'reallyjosh'
        list_id = 'top-1-000-movies-on-imdb'
        
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading Top 1000 Movies...')

        movies = get_list_items(user, list_id)
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in the Top 1000 list.')
            return
    else:
        # Get the list to use (Trakt List mode)
        list_mode = get_addon_setting('list_mode', 'string')

        if list_mode == 'single':
            user = get_addon_setting('saved_list_user', 'string')
            list_id = get_addon_setting('saved_list_id', 'string')

            if not user or not list_id:
                xbmcgui.Dialog().ok('No Saved List',
                                  'Please configure a list in Settings first.')
                return
        else:
            # Show list selection
            progress = xbmcgui.DialogProgress()
            progress.create('DogPlay', 'Fetching your Trakt lists...')

            lists = get_trakt_lists()
            progress.close()

            if not lists:
                return

            list_names = [l.get('name', 'Unnamed List') for l in lists]
            selected = xbmcgui.Dialog().select('Select a Trakt List for Movie Guide', list_names)

            if selected < 0:
                return

            selected_list = lists[selected]
            user = selected_list.get('user', {}).get('ids', {}).get('slug')
            list_id = selected_list.get('ids', {}).get('trakt')

            if not user or not list_id:
                return

        # Get movies from the list
        progress = xbmcgui.DialogProgress()
        progress.create('DogPlay Movie Guide', 'Loading movies from your list...')

        movies = get_list_items(user, list_id)
        progress.close()

        if not movies:
            xbmcgui.Dialog().ok('No Movies', 'No movies found in the list.')
            return

    # Show the guide
    from resources.lib.movie_guide import show_movie_guide
    show_movie_guide(movies)

def get_recently_watched_items():
    """Get recently watched movies from Trakt"""
    try:
        # Fetch recently watched from Trakt using FenlightAM's API
        # Manual implementation using call_trakt since get_trakt_history is missing
        params = {'extended': 'full', 'limit': 50}
        result = trakt_api.call_trakt('sync/history/movies', params=params)

        if not result:
            xbmcgui.Dialog().ok('No History', 'No recently watched movies found.')
            return []

        items = []
        for c, i in enumerate(result):
            try:
                if i['type'] == 'movie':
                    items.append({
                        'media_ids': i['movie']['ids'],
                        'title': i['movie']['title'],
                        'overview': i['movie'].get('overview', ''),
                        'year': i['movie'].get('year', ''),
                        'rating': i['movie'].get('rating', ''),
                        'watched_at': i.get('watched_at')
                    })
            except: pass

        if not items:
            xbmcgui.Dialog().ok('No History', 'No recently watched movies found.')
            return []

        return items
    except Exception as e:
        xbmc.log(f"DogPlay: Failed to fetch recently watched: {str(e)}", xbmc.LOGERROR)
        return []

def play_from_history_movie(tmdb_id, title=''):
    """Play a movie from history using FenLight"""
    try:
        # Use RunPlugin to trigger FenLight playback
        fenlight_url = f'plugin://plugin.video.fenlight/?mode=playback.media&media_type=movie&tmdb_id={tmdb_id}'
        xbmc.log(f"DogPlay: Playing from history - {title} (TMDB: {tmdb_id})", xbmc.LOGINFO)
        xbmc.executebuiltin(f'RunPlugin({fenlight_url})')
    except Exception as e:
        xbmc.log(f"DogPlay: Error playing from history: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Playback Error', f'Failed to play movie: {str(e)}')

def show_recently_watched(addon_handle, base_url):
    """Show Recently Watched movies list - Redirect to FenLight"""
    if not check_fenlight_auth():
        return
    
    # Redirect to FenLight's native Recently Watched view
    # This allows playback to work properly
    fenlight_url = 'plugin://plugin.video.fenlight/?mode=build_movie_list&action=recent_watched_movies'
    xbmc.executebuiltin(f'Container.Update({fenlight_url}, false)')


def main_menu(addon_handle, base_url):
    """Display main menu"""
    # Enforce Insertion Order
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_NONE)
    
    if not check_fenlight_auth():
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    # Common artwork
    addon_dir = addon.getAddonInfo('path')
    icon = os.path.join(addon_dir, 'icon.png')
    
    # Get dynamic settings
    list_mode = get_addon_setting('list_mode', 'string')
    saved_list_name = get_addon_setting('saved_list_name', 'string')
    guide_source = get_addon_setting('guide_source', 'string')

    # Set plugin category
    xbmcplugin.setPluginCategory(addon_handle, "Main Menu")

    # 1. Play Random Movie from List
    play_title = 'Play Random Movie from List'
    play_plot = 'Select a Trakt list and play a random movie from it.'
    if list_mode == 'single' and saved_list_name:
        play_title = f'Play Random Movie from {saved_list_name}'
        play_plot = f"Play a random movie from your saved list: '{saved_list_name}'."
        
    li = xbmcgui.ListItem(play_title)
    li.setInfo('video', {'title': play_title, 'plot': play_plot})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=select_list'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # 2. Play Random Movie from Collection
    li = xbmcgui.ListItem('Play Random Movie from Collection')
    li.setInfo('video', {'title': 'Play Random Movie from Collection', 'plot': 'Play a random movie from your personal Trakt collection.'})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=play_collection'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # 3. View Movie Guide
    guide_plot = 'Browse movies in an EPG-style guide format.'
    if guide_source:
        guide_plot = f'Browse movies from your {guide_source} in an EPG-style guide format.'
        
    li = xbmcgui.ListItem('View Movie Guide')
    li.setInfo('video', {'title': 'View Movie Guide', 'plot': guide_plot})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=movie_guide'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # 4. Custom Lists (04-09)
    for i in range(1, 6):  # Support up to 5 custom lists
        try:
            enabled = get_addon_setting(f'custom_list_{i}_enabled')
            if enabled:
                list_name = get_addon_setting(f'custom_list_{i}_name', 'string')
                list_user = get_addon_setting(f'custom_list_{i}_user', 'string')
                list_id = get_addon_setting(f'custom_list_{i}_id', 'string')

                if list_name and list_user and list_id:
                    li = xbmcgui.ListItem(f'Play Random Movie from {list_name}')
                    li.setInfo('video', {
                        'title': f'Play Random Movie from {list_name}', 
                        'plot': f'Play a random movie from custom list: {list_name}'
                    })
                    li.setArt({'icon': icon, 'thumb': icon})
                    url = f'{base_url}?action=play_custom_list&user={list_user}&list_id={list_id}'
                    xbmcplugin.addDirectoryItem(
                        handle=addon_handle,
                        url=url,
                        listitem=li,
                        isFolder=False
                    )
        except:
            pass

    # 99. Settings
    li = xbmcgui.ListItem('Settings')
    li.setInfo('video', {'title': 'Settings', 'plot': 'Configure DogPlay options, manage lists, and adjust playback preferences.'})
    li.setArt({'icon': icon, 'thumb': icon})
    url = f'{base_url}?action=settings'
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=url,
        listitem=li,
        isFolder=False
    )

    # Revert to standard behavior (updateListing=False is the key fix for duplicates)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False)
