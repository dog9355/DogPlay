# -*- coding: utf-8 -*-
"""TV Guide - EPG-style grid showing random TV shows on virtual channels"""
import random
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
from datetime import datetime, timedelta
import colorsys
import os

addon = xbmcaddon.Addon()

class TVGuide:
    """Generate EPG-style TV guide data"""

    def __init__(self, shows, num_channels=5, shows_per_channel=6):
        self.shows = shows
        self.num_channels = num_channels
        self.shows_per_channel = shows_per_channel
        self.channels = []

    def generate_guide(self):
        """Generate the guide data - simple grid of random TV shows"""
        self.channels = []
        used_tmdb_ids = set()  # Track used shows to avoid duplicates

        for channel_num in range(1, self.num_channels + 1):
            channel = {
                'number': channel_num,
                'name': f'DogPlay TV {channel_num}',
                'shows': []
            }

            # Pick random shows for this channel
            for _ in range(self.shows_per_channel):
                # Try to find a show not yet used
                attempts = 0
                max_attempts = len(self.shows)

                while attempts < max_attempts:
                    show = random.choice(self.shows)
                    media_ids = show.get('media_ids', {})
                    tmdb_id = media_ids.get('tmdb')

                    # If we haven't used this show yet, or we've run out of unique shows, use it
                    if tmdb_id not in used_tmdb_ids or len(used_tmdb_ids) >= len(self.shows):
                        show_title = show.get('title', 'Unknown Show')

                        show_item = {
                            'show': show,
                            'title': show_title,
                            'tmdb_id': tmdb_id
                        }

                        channel['shows'].append(show_item)
                        if tmdb_id:
                            used_tmdb_ids.add(tmdb_id)
                        break

                    attempts += 1

            self.channels.append(channel)

        return self.channels

class TVGuideWindow(xbmcgui.Window):
    """Custom window for displaying the TV guide grid"""

    def __init__(self):
        super().__init__()
        self.channels = []
        self.shows_data = []
        self.user = ''
        self.list_id = ''
        self.bar_controls = []
        self.bar_data = []

        # Grid settings
        self.grid_left = 200
        self.grid_top = 150
        self.channel_height = 105  # Reduced to fit all 5 channels on screen
        self.grid_width = 1520

    def set_data(self, channels, shows_data, user, list_id):
        """Set the data for the guide"""
        self.channels = channels
        self.shows_data = shows_data
        self.user = user
        self.list_id = list_id

    def onInit(self):
        """Initialize the window and create the grid"""
        try:
            xbmc.log("DogPlay TVGuide: Starting onInit", xbmc.LOGINFO)
            xbmc.log(f"DogPlay TVGuide: Channels count: {len(self.channels)}", xbmc.LOGINFO)

            # Make sure we have data
            if not self.channels:
                xbmc.log("DogPlay TVGuide: No channels data available!", xbmc.LOGERROR)
                return

            # Set black background using window property
            self.setProperty('background', '0xFF000000')

            # Create title
            title = xbmcgui.ControlLabel(60, 40, 1800, 60, 'DogPlay TV Guide',
                                        font='font30_title', textColor='0xFFFFFFFF')
            self.addControl(title)
            xbmc.log("DogPlay TVGuide: Added title", xbmc.LOGINFO)

            # Create current time label
            time_label = xbmcgui.ControlLabel(60, 100, 1800, 40,
                                             f"Current Time: {datetime.now().strftime('%I:%M %p')}",
                                             font='font13', textColor='0xFFFFFFFF')
            self.addControl(time_label)
            xbmc.log("DogPlay TVGuide: Added time label", xbmc.LOGINFO)

            # Draw the grid
            self._draw_grid()
            xbmc.log("DogPlay TVGuide: Grid drawn", xbmc.LOGINFO)

            # Add instructions
            instructions = xbmcgui.ControlLabel(60, 1000, 1800, 40,
                                               'Arrow keys: navigate | ENTER: play random episode | C or MENU: show details | ESC/BACK: close',
                                               font='font13', textColor='0xFFAAAAAA')
            self.addControl(instructions)

            # Set focus to first show bar and show its color
            if self.bar_controls and self.bar_data:
                self.setFocus(self.bar_controls[0])
                # Small delay to ensure window is fully rendered
                import time
                time.sleep(0.1)
                # Show colored background for first bar
                self.bar_data[0]['bg_gray'].setVisible(False)
                self.bar_data[0]['bg_color'].setVisible(True)
                xbmc.log("DogPlay TVGuide: Set focus to first bar with color", xbmc.LOGINFO)

            xbmc.log("DogPlay TVGuide: onInit complete", xbmc.LOGINFO)

        except Exception as e:
            xbmc.log(f"DogPlay TVGuide: Error in onInit: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay TVGuide: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            raise

    def _get_color_for_show(self, show_index):
        """Generate a distinct color for each show using a predefined palette"""
        # Use a palette of rich, visible colors that look good on black background
        color_palette = [
            '0xFF4169E1',  # Royal Blue
            '0xFFDC143C',  # Crimson Red
            '0xFF32CD32',  # Lime Green
            '0xFFFF8C00',  # Dark Orange
            '0xFF9370DB',  # Medium Purple
            '0xFF20B2AA',  # Light Sea Green
            '0xFFFF1493',  # Deep Pink
            '0xFFFFD700',  # Gold
            '0xFF00CED1',  # Dark Turquoise
            '0xFFFF6347',  # Tomato
            '0xFF9932CC',  # Dark Orchid
            '0xFF00FA9A',  # Medium Spring Green
            '0xFFFF69B4',  # Hot Pink
            '0xFF87CEEB',  # Sky Blue
            '0xFFFF4500',  # Orange Red
            '0xFF8A2BE2',  # Blue Violet
            '0xFF00FF7F',  # Spring Green
            '0xFFDB7093',  # Pale Violet Red
            '0xFF48D1CC',  # Medium Turquoise
            '0xFFFFA500',  # Orange
        ]

        # Cycle through the palette
        return color_palette[show_index % len(color_palette)]

    def _draw_grid(self):
        """Draw the TV guide grid - bars with separators, stagger, random widths"""
        addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        white_texture = os.path.join(addon_path, 'white.png')

        base_bar_width = 400  # Base width
        bar_height = 85
        separator_width = 3  # Small black separator between bars

        for channel_idx, channel in enumerate(self.channels):
            y_pos = self.grid_top + (channel_idx * self.channel_height)

            # Draw channel label
            channel_label = xbmcgui.ControlLabel(
                60, y_pos + 40, 130, 40,
                f"Ch {channel['number']}",
                font='font13', textColor='0xFFFFFFFF'
            )
            self.addControl(channel_label)

            # Calculate stagger offset for this channel
            random.seed(channel_idx * 1000)
            channel_stagger = random.randint(0, 200)

            first_bar_visible_x = self.grid_left
            first_bar_actual_x = self.grid_left - channel_stagger

            # Draw placeholder bar for the cut-off portion
            if channel_stagger > 0:
                placeholder_width = channel_stagger
                bar_y = y_pos + 8

                visible_placeholder_x = max(first_bar_actual_x, 190)
                visible_placeholder_width = first_bar_visible_x - visible_placeholder_x

                if visible_placeholder_width > 0:
                    placeholder_bar = xbmcgui.ControlImage(
                        visible_placeholder_x, bar_y, visible_placeholder_width, bar_height,
                        white_texture
                    )
                    placeholder_bar.setColorDiffuse('0xFF404040')
                    self.addControl(placeholder_bar)

            # Track current x position
            current_x = first_bar_actual_x

            # Draw shows for this channel
            for show_idx, show_item in enumerate(channel['shows']):
                # Random width variation
                random.seed(hash(show_item['title']))
                width_variation = random.randint(0, int(base_bar_width * 0.3))
                bar_width = base_bar_width + width_variation

                bar_x = current_x
                bar_y = y_pos + 8

                # For first bar, if it starts before grid_left, clip it
                actual_bar_x = bar_x
                actual_bar_width = bar_width

                if show_idx == 0 and bar_x < first_bar_visible_x:
                    actual_bar_x = first_bar_visible_x
                    actual_bar_width = bar_width - (first_bar_visible_x - bar_x)

                # Get color for this show
                color = self._get_color_for_show(hash(show_item['title']) % 20)

                # Create button for interaction
                bar_button = xbmcgui.ControlButton(
                    actual_bar_x, bar_y, actual_bar_width, bar_height,
                    '',
                    focusTexture=white_texture,
                    noFocusTexture=white_texture,
                    textColor='0x00FFFFFF',
                )
                self.addControl(bar_button)

                # Gray background (shown when not focused)
                bar_bg_gray = xbmcgui.ControlImage(
                    actual_bar_x, bar_y, actual_bar_width, bar_height,
                    white_texture
                )
                bar_bg_gray.setColorDiffuse('0xFF505050')
                self.addControl(bar_bg_gray)

                # Colored background (shown when focused)
                bar_bg_color = xbmcgui.ControlImage(
                    actual_bar_x, bar_y, actual_bar_width, bar_height,
                    white_texture
                )
                bar_bg_color.setColorDiffuse(color)
                bar_bg_color.setVisible(False)
                self.addControl(bar_bg_color)

                # Add show title label
                title_label = xbmcgui.ControlLabel(
                    actual_bar_x + 15, bar_y + 35, actual_bar_width - 30, 40,
                    show_item['title'][:35],
                    font='font12',
                    textColor='0xFFFFFFFF'
                )
                self.addControl(title_label)

                # Store bar data
                self.bar_controls.append(bar_button)
                self.bar_data.append({
                    'show_item': show_item,
                    'channel_idx': channel_idx,
                    'show_idx': show_idx,
                    'bg_gray': bar_bg_gray,
                    'bg_color': bar_bg_color
                })

                # Move current_x forward for next bar (with separator)
                current_x += bar_width + separator_width

            # Reset random seed
            random.seed()

    def onAction(self, action):
        """Handle actions like ESC key, ENTER, and arrow keys"""
        action_id = action.getId()

        # Handle back/escape
        if action_id in [10, 92]:
            self.close()

        # Handle navigation
        elif action_id in [1, 2, 3, 4]:
            try:
                focused_control = self.getFocus()
                focused_id = focused_control.getId()

                # Find current bar
                current_idx = None
                for idx, bar_control in enumerate(self.bar_controls):
                    if bar_control.getId() == focused_id:
                        current_idx = idx
                        break

                if current_idx is not None:
                    current_bar = self.bar_data[current_idx]

                    # Calculate target based on direction
                    if action_id == 1:  # Up -> goes Left
                        target_channel = current_bar['channel_idx']
                        target_show = current_bar['show_idx'] - 1
                    elif action_id == 2:  # Down -> goes Right
                        target_channel = current_bar['channel_idx']
                        target_show = current_bar['show_idx'] + 1
                    elif action_id == 3:  # Left -> goes Up
                        target_channel = current_bar['channel_idx'] - 1
                        target_show = current_bar['show_idx']
                    elif action_id == 4:  # Right -> goes Down
                        target_channel = current_bar['channel_idx'] + 1
                        target_show = current_bar['show_idx']

                    # Find target bar
                    for idx, bar_info in enumerate(self.bar_data):
                        if bar_info['channel_idx'] == target_channel and bar_info['show_idx'] == target_show:
                            self.setFocus(self.bar_controls[idx])
                            break
            except Exception as e:
                xbmc.log(f"DogPlay TVGuide: Nav error: {str(e)}", xbmc.LOGERROR)

            # After navigation, update which bar is highlighted
            try:
                import time
                time.sleep(0.05)

                focused_control = self.getFocus()
                focused_id = focused_control.getId()

                # Hide all colored backgrounds, show gray
                for bar_info in self.bar_data:
                    bar_info['bg_gray'].setVisible(True)
                    bar_info['bg_color'].setVisible(False)

                # Show colored background for focused bar
                for idx, bar_control in enumerate(self.bar_controls):
                    if bar_control.getId() == focused_id:
                        self.bar_data[idx]['bg_gray'].setVisible(False)
                        self.bar_data[idx]['bg_color'].setVisible(True)
                        break
            except:
                pass

        # Handle CONTEXT MENU key
        elif action_id == 117:
            xbmc.log("DogPlay TVGuide: Context menu requested", xbmc.LOGINFO)
            try:
                focused_control = self.getFocus()
                focused_id = focused_control.getId()

                # Find which bar is focused
                for idx, bar_control in enumerate(self.bar_controls):
                    if bar_control.getId() == focused_id:
                        show_item = self.bar_data[idx]['show_item']
                        self._show_tv_context_menu(show_item)
                        return
            except Exception as e:
                xbmc.log(f"DogPlay TVGuide: Error showing context menu: {str(e)}", xbmc.LOGERROR)

        # Handle SELECT/ENTER key
        elif action_id == 7:
            try:
                focused_control = self.getFocus()
                focused_id = focused_control.getId()
                xbmc.log(f"DogPlay TVGuide: SELECT pressed, focused control ID: {focused_id}", xbmc.LOGINFO)

                # Find which bar is focused
                for idx, bar_control in enumerate(self.bar_controls):
                    try:
                        bar_id = bar_control.getId()
                        if focused_id == bar_id:
                            xbmc.log(f"DogPlay TVGuide: Selected bar {idx}: {self.bar_data[idx]['show_item']['title']}", xbmc.LOGINFO)
                            self._play_random_episode(self.bar_data[idx]['show_item'])
                            return
                    except Exception as inner_e:
                        xbmc.log(f"DogPlay TVGuide: Error comparing control {idx}: {str(inner_e)}", xbmc.LOGERROR)

                xbmc.log(f"DogPlay TVGuide: No matching bar found for focused control ID {focused_id}", xbmc.LOGWARNING)
            except RuntimeError as e:
                if "Non-Existent Control" in str(e):
                    xbmc.log("DogPlay TVGuide: No control has focus", xbmc.LOGINFO)
                else:
                    xbmc.log(f"DogPlay TVGuide: RuntimeError handling SELECT: {str(e)}", xbmc.LOGERROR)
            except Exception as e:
                xbmc.log(f"DogPlay TVGuide: Error handling SELECT: {str(e)}", xbmc.LOGERROR)

    def _show_tv_context_menu(self, show_item):
        """Show a context menu for the selected TV show"""
        try:
            show = show_item['show']
            title = show_item['title']

            # Get show details
            year = show.get('year', 'Unknown')
            rating = show.get('rating', 'N/A')
            overview = show.get('overview', '')

            # If no overview from Trakt, try to fetch from TMDB
            if not overview or overview == '':
                media_ids = show.get('media_ids', {})
                tmdb_id = media_ids.get('tmdb')
                if tmdb_id:
                    try:
                        import sys
                        import xbmcvfs
                        # Import FenlightAM modules
                        fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
                        fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
                        if fenlight_path not in sys.path:
                            sys.path.append(fenlight_path + '/resources/lib')

                        from apis.tmdb_api import tvshow_details
                        from modules.settings import tmdb_api_key

                        api_key = tmdb_api_key()
                        meta = tvshow_details(tmdb_id, api_key)
                        if meta:
                            overview = meta.get('overview', '')
                            if not rating or rating == 'N/A':
                                rating = meta.get('vote_average', 'N/A')
                            xbmc.log(f"DogPlay TVGuide: Fetched overview from TMDB for {title}", xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f"DogPlay TVGuide: Could not fetch TMDB details: {str(e)}", xbmc.LOGWARNING)

            if not overview:
                overview = 'No description available.'

            # Create context menu options
            options = [
                'View Description',
                'Extras',
                'Manage Trakt Lists',
                'Play Random Episode',
                'Cancel'
            ]

            selected = xbmcgui.Dialog().select(f'{title} ({year})', options)

            if selected == 0:  # View Description
                description_text = f"[B]{title}[/B] ({year})\n"
                if rating and rating != 'N/A':
                    description_text += f"Rating: {rating}/10\n"
                description_text += f"\n{overview}"

                xbmcgui.Dialog().textviewer(f'{title}', description_text)
            elif selected == 1:  # Extras
                self._show_extras(show_item)
            elif selected == 2:  # Manage Trakt Lists
                self._manage_trakt_lists(show_item)
            elif selected == 3:  # Play Random Episode
                self._play_random_episode(show_item)

        except Exception as e:
            xbmc.log(f"DogPlay TVGuide: Error in context menu: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to show TV show details: {str(e)}')

    def _show_extras(self, show_item):
        """Open FenlightAM's Extras menu for this TV show"""
        try:
            show = show_item['show']
            media_ids = show.get('media_ids', {})
            tmdb_id = media_ids.get('tmdb')
            tvdb_id = media_ids.get('tvdb')

            if not tmdb_id:
                xbmcgui.Dialog().ok('Error', 'Could not find TV show ID for extras')
                return

            xbmc.log(f"DogPlay TVGuide: Opening Extras for {show_item['title']} (TMDB: {tmdb_id})", xbmc.LOGINFO)

            fenlight_url = f'plugin://plugin.video.fenlight/?mode=extras_menu_choice&tmdb_id={tmdb_id}&media_type=tvshow'
            xbmc.executebuiltin(f'ActivateWindow(Videos,{fenlight_url},return)')

        except Exception as e:
            xbmc.log(f"DogPlay TVGuide: Error opening extras: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to open extras: {str(e)}')

    def _manage_trakt_lists(self, show_item):
        """Open FenlightAM's Trakt List Manager for this TV show"""
        try:
            show = show_item['show']
            media_ids = show.get('media_ids', {})
            tmdb_id = media_ids.get('tmdb')
            imdb_id = media_ids.get('imdb')
            tvdb_id = media_ids.get('tvdb')

            if not tmdb_id:
                xbmcgui.Dialog().ok('Error', 'Could not find TV show ID for list management')
                return

            xbmc.log(f"DogPlay TVGuide: Opening Trakt List Manager for {show_item['title']}", xbmc.LOGINFO)

            fenlight_url = f'plugin://plugin.video.fenlight/?mode=trakt_manager_choice&tmdb_id={tmdb_id}&imdb_id={imdb_id}&tvdb_id={tvdb_id}&media_type=tvshow'
            xbmc.executebuiltin(f'ActivateWindow(Videos,{fenlight_url},return)')

        except Exception as e:
            xbmc.log(f"DogPlay TVGuide: Error opening Trakt list manager: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to open list manager: {str(e)}')

    def _play_random_episode(self, show_item):
        """Play a random episode from a random season of the TV show"""
        try:
            import sys
            import xbmcvfs

            # Import FenlightAM modules
            fenlight_addon = xbmcaddon.Addon('plugin.video.fenlight')
            fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
            if fenlight_path not in sys.path:
                sys.path.append(fenlight_path + '/resources/lib')

            from apis.tmdb_api import tvshow_details, season_episodes_details
            from modules.settings import playback_key, tmdb_api_key
            from modules.sources import Sources

            show = show_item['show']
            media_ids = show.get('media_ids', {})
            tmdb_id = media_ids.get('tmdb')

            if not tmdb_id:
                xbmcgui.Dialog().ok('Error', 'Could not find TV show ID')
                return

            # Get show metadata
            api_key = tmdb_api_key()
            show_meta = tvshow_details(tmdb_id, api_key)

            if not show_meta or not show_meta.get('seasons'):
                xbmcgui.Dialog().ok('Error', f'Could not fetch season data for {show_item["title"]}')
                return

            # Filter out season 0 (specials)
            valid_seasons = [s for s in show_meta['seasons'] if s.get('season_number', 0) > 0]

            if not valid_seasons:
                xbmcgui.Dialog().ok('Error', 'No valid seasons found')
                return

            # Select random season
            random_season = random.choice(valid_seasons)
            season_number = random_season['season_number']
            episode_count = random_season['episode_count']

            if episode_count == 0:
                xbmcgui.Dialog().ok('Error', f'No episodes found in Season {season_number}')
                return

            # Select random episode
            episode_number = random.randint(1, episode_count)

            # Get TV random start settings
            tv_random_start_enabled = addon.getSetting('tv_random_start_enabled') == 'true'
            tv_min_percent = float(addon.getSetting('tv_min_start_percent'))
            tv_max_percent = float(addon.getSetting('tv_max_start_percent'))

            # Calculate random start position
            if tv_random_start_enabled:
                seek_percent = random.uniform(tv_min_percent, tv_max_percent)
            else:
                seek_percent = 0.0

            xbmc.log("=" * 80, xbmc.LOGINFO)
            xbmc.log(f"DogPlay TVGuide: Playing {show_item['title']} S{season_number:02d}E{episode_number:02d} at {seek_percent:.1f}%", xbmc.LOGINFO)
            xbmc.log(f"DogPlay TVGuide: self.user='{self.user}', self.list_id='{self.list_id}'", xbmc.LOGINFO)

            # Set pending TV episode info for service monitoring
            window = xbmcgui.Window(10000)
            window.setProperty('dogplay.tv.pending_tmdb_id', str(tmdb_id))
            window.setProperty('dogplay.tv.pending_title', show_item['title'])
            window.setProperty('dogplay.tv.pending_season', str(season_number))
            window.setProperty('dogplay.tv.pending_episode', str(episode_number))
            window.setProperty('dogplay.tv.pending_user', self.user)
            window.setProperty('dogplay.tv.pending_list_id', self.list_id)

            xbmc.log(f"DogPlay TVGuide: Set window properties:", xbmc.LOGINFO)
            xbmc.log(f"  - pending_tmdb_id: '{tmdb_id}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_title: '{show_item['title']}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_season: '{season_number}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_episode: '{episode_number}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_user: '{self.user}'", xbmc.LOGINFO)
            xbmc.log(f"  - pending_list_id: '{self.list_id}'", xbmc.LOGINFO)
            xbmc.log("=" * 80, xbmc.LOGINFO)

            # Get playback key and build params
            key = playback_key()
            params = {
                'tmdb_id': str(tmdb_id),
                'media_type': 'episode',
                'season': str(season_number),
                'episode': str(episode_number),
                key: 'true'
            }

            # Create Sources instance
            source_instance = Sources()
            original_get_playback_percent = source_instance.get_playback_percent

            def forced_get_playback_percent():
                if seek_percent > 0:
                    return float(seek_percent)
                return original_get_playback_percent()

            source_instance.get_playback_percent = forced_get_playback_percent

            # Close the guide window
            self.close()

            # Start playback
            source_instance.playback_prep(params)

        except Exception as e:
            xbmc.log(f"DogPlay TVGuide: Error playing episode: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to start playback: {str(e)}')

def show_tv_guide(shows, user='', list_id=''):
    """Display the TV guide dialog"""
    xbmc.log("=" * 80, xbmc.LOGINFO)
    xbmc.log("DogPlay TVGuide: show_tv_guide() CALLED", xbmc.LOGINFO)
    xbmc.log(f"DogPlay TVGuide: Number of shows: {len(shows) if shows else 0}", xbmc.LOGINFO)
    xbmc.log(f"DogPlay TVGuide: user='{user}', list_id='{list_id}'", xbmc.LOGINFO)
    xbmc.log("=" * 80, xbmc.LOGINFO)

    if not shows:
        xbmc.log("DogPlay TVGuide: No shows available", xbmc.LOGINFO)
        xbmcgui.Dialog().ok('No TV Shows', 'No TV shows found.')
        return

    # Show busy dialog while loading
    progress = xbmcgui.DialogProgressBG()
    progress.create('DogPlay TV Guide', 'Generating guide...')

    try:
        # Generate guide data
        progress.update(25, 'DogPlay TV Guide', 'Selecting TV shows...')
        guide = TVGuide(shows, num_channels=5, shows_per_channel=3)
        channels = guide.generate_guide()

        # Show the custom window
        progress.update(50, 'DogPlay TV Guide', 'Building grid...')
        window = TVGuideWindow()
        window.set_data(channels, shows, user, list_id)

        progress.update(75, 'DogPlay TV Guide', 'Rendering controls...')
        window.onInit()

        progress.update(100, 'DogPlay TV Guide', 'Ready!')

        import time
        time.sleep(0.3)
        progress.close()

        # Use doModal() to block until window closes
        window.doModal()

        # Clean up
        try:
            del window
        except:
            pass

        xbmc.log("DogPlay TVGuide: show_tv_guide() COMPLETE", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"DogPlay: Error showing TV guide window: {str(e)}", xbmc.LOGERROR)
        import traceback
        xbmc.log(f"DogPlay: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('TV Guide Error', f'Failed to display TV guide: {str(e)}')
