# -*- coding: utf-8 -*-
"""Background service for DogPlay continuous playback monitoring"""
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import sys

# Import Fenlight/FenlightAM modules
# Try both addon IDs (original and fork)
for addon_id in ['plugin.video.fenlight', 'plugin.video.fenlightam']:
    try:
        fenlight_addon = xbmcaddon.Addon(addon_id)
        fenlight_path = xbmcvfs.translatePath(fenlight_addon.getAddonInfo('path'))
        sys.path.append(fenlight_path + '/resources/lib')
        xbmc.log(f"DogPlay Service: Loaded {addon_id}", xbmc.LOGINFO)
        break
    except:
        continue

addon = xbmcaddon.Addon('plugin.video.randommovie')

class NextEpisodeDialog(xbmcgui.WindowDialog):
    """Custom dialog for next episode prompt - positioned at top-left with 3 options"""
    def __init__(self, show_title, next_season, next_episode, episode_title):
        super().__init__()
        self.show_title = show_title
        self.next_season = next_season
        self.next_episode = next_episode
        self.episode_title = episode_title
        self.user_choice = None  # Can be 'play_now', 'play_after', 'play_random', or None

        # Dialog dimensions and position (top-left corner) - wider for 3 buttons
        self.x = 50
        self.y = 50
        self.width = 680
        self.height = 220

        # Control IDs
        self.BACKGROUND_ID = 1000
        self.TITLE_ID = 1001
        self.MESSAGE_ID = 1002
        self.PLAY_NOW_BUTTON_ID = 1003
        self.PLAY_AFTER_BUTTON_ID = 1004
        self.PLAY_RANDOM_BUTTON_ID = 1005

        self._setup_controls()

    def _setup_controls(self):
        """Create and position dialog controls"""
        # Background
        self.background = xbmcgui.ControlImage(
            self.x, self.y, self.width, self.height,
            '',
            colorDiffuse='DD000000'  # Semi-transparent black
        )
        self.addControl(self.background)

        # Title label
        title_label = xbmcgui.ControlLabel(
            self.x + 20, self.y + 20, self.width - 40, 30,
            'Play Next Episode?',
            font='font13_title',
            textColor='0xFFFFFFFF'
        )
        self.addControl(title_label)

        # Show title
        show_label = xbmcgui.ControlLabel(
            self.x + 20, self.y + 55, self.width - 40, 25,
            self.show_title,
            font='font12',
            textColor='0xFFCCCCCC'
        )
        self.addControl(show_label)

        # Episode info
        episode_text = f'S{self.next_season:02d}E{self.next_episode:02d}: {self.episode_title}'
        episode_label = xbmcgui.ControlLabel(
            self.x + 20, self.y + 85, self.width - 40, 25,
            episode_text,
            font='font12',
            textColor='0xFFCCCCCC'
        )
        self.addControl(episode_label)

        # Play Now button (left)
        self.play_now_button = xbmcgui.ControlButton(
            self.x + 20, self.y + 140, 200, 50,
            'Play Now',
            font='font13',
            textColor='0xFFFFFFFF',
            focusedColor='0xFF00FF00'
        )
        self.addControl(self.play_now_button)
        self.PLAY_NOW_BUTTON_ID = self.play_now_button.getId()  # Get actual ID from Kodi

        # Play After button (center) - default focus
        self.play_after_button = xbmcgui.ControlButton(
            self.x + 240, self.y + 140, 200, 50,
            'Play After',
            font='font13',
            textColor='0xFFFFFFFF',
            focusedColor='0xFF00FF00'
        )
        self.addControl(self.play_after_button)
        self.PLAY_AFTER_BUTTON_ID = self.play_after_button.getId()  # Get actual ID from Kodi
        self.setFocus(self.play_after_button)  # Default focus

        # Play Random button (right)
        self.play_random_button = xbmcgui.ControlButton(
            self.x + 460, self.y + 140, 200, 50,
            'Play Random',
            font='font13',
            textColor='0xFFFFFFFF',
            focusedColor='0xFFFFFF00'
        )
        self.addControl(self.play_random_button)
        self.PLAY_RANDOM_BUTTON_ID = self.play_random_button.getId()  # Get actual ID from Kodi

        # Set navigation (horizontal)
        self.play_now_button.controlRight(self.play_after_button)
        self.play_after_button.controlLeft(self.play_now_button)
        self.play_after_button.controlRight(self.play_random_button)
        self.play_random_button.controlLeft(self.play_after_button)

        # Auto-close timer
        import threading
        self.timer = threading.Timer(30.0, self._auto_close)
        self.timer.daemon = True
        self.timer.start()

    def _auto_close(self):
        """Auto-close dialog after timeout"""
        try:
            self.user_choice = None
            self.close()
        except:
            pass

    def onControl(self, control):
        """Handle button clicks"""
        try:
            control_id = control.getId()
            xbmc.log(f"DogPlay Dialog: onControl called with control ID {control_id}", xbmc.LOGINFO)

            if control_id == self.PLAY_NOW_BUTTON_ID:
                xbmc.log("DogPlay Dialog: Play Now button clicked", xbmc.LOGINFO)
                self.user_choice = 'play_now'
                self.timer.cancel()
                self.close()
            elif control_id == self.PLAY_AFTER_BUTTON_ID:
                xbmc.log("DogPlay Dialog: Play After button clicked", xbmc.LOGINFO)
                self.user_choice = 'play_after'
                self.timer.cancel()
                self.close()
            elif control_id == self.PLAY_RANDOM_BUTTON_ID:
                xbmc.log("DogPlay Dialog: Play Random button clicked", xbmc.LOGINFO)
                self.user_choice = 'play_random'
                self.timer.cancel()
                self.close()
            else:
                xbmc.log(f"DogPlay Dialog: Unknown control ID {control_id}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Dialog: Error in onControl: {str(e)}", xbmc.LOGERROR)

    def onAction(self, action):
        """Handle actions like back/escape and select"""
        action_id = action.getId()

        # Log action for debugging
        xbmc.log(f"DogPlay Dialog: Action ID {action_id} received", xbmc.LOGINFO)

        if action_id in [10, 92]:  # Back or escape
            self.user_choice = None
            self.timer.cancel()
            self.close()
        elif action_id in [7, 100]:  # Select/Enter key (7) or Mouse click (100)
            # Get the currently focused control and trigger it
            try:
                focused_control = self.getFocus()
                xbmc.log(f"DogPlay Dialog: Focused control found, triggering onControl", xbmc.LOGINFO)
                self.onControl(focused_control)
            except Exception as e:
                xbmc.log(f"DogPlay Dialog: Error in select handler: {str(e)}", xbmc.LOGERROR)

class DogPlayMonitor(xbmc.Monitor):
    """Service monitor for DogPlay"""
    def __init__(self):
        super().__init__()
        self.player = DogPlayPlayer()
        xbmc.log("DogPlay Service: Monitor initialized", xbmc.LOGINFO)

    def run(self):
        """Main service loop"""
        xbmc.log("DogPlay Service: Starting service", xbmc.LOGINFO)
        while not self.abortRequested():
            if self.waitForAbort(1):
                break
        xbmc.log("DogPlay Service: Service stopped", xbmc.LOGINFO)

class DogPlayPlayer(xbmc.Player):
    """Player monitor for continuous playback"""
    def __init__(self):
        super().__init__()
        self.user = None
        self.list_id = None
        self.current_tmdb_id = None
        self.current_title = None
        # TV-specific tracking
        self.current_media_type = None  # 'movie' or 'episode'
        self.current_season = None
        self.current_episode = None
        self.prompt_shown = False  # Track if we've shown the next episode prompt
        self.user_choice = None  # Can be 'play_now', 'play_after', 'play_random', or None
        self.next_ep_info = None  # Store next episode info for play_now/play_after
        self.monitor_thread = None  # Monitoring thread for TV playback
        xbmc.log("DogPlay Service: Player monitor initialized", xbmc.LOGINFO)

    def onAVStarted(self):
        """Called when playback starts"""
        xbmc.log("=" * 80, xbmc.LOGINFO)
        xbmc.log("DogPlay Service: 🎬 onAVStarted() called", xbmc.LOGINFO)
        xbmc.log("=" * 80, xbmc.LOGINFO)
        
        # Verify this is actual video playback, not scraping
        # Give a longer delay to let the player stabilize and ensure scraping is complete
        xbmc.log("DogPlay Service: ⏱️  Waiting 2 seconds for player to stabilize...", xbmc.LOGINFO)
        xbmc.sleep(2000)
        
        # Check if player is still actually playing a video file
        xbmc.log("DogPlay Service: 🔍 Step 1: Checking if video is playing...", xbmc.LOGINFO)
        is_playing = self.isPlayingVideo()
        xbmc.log(f"DogPlay Service: isPlayingVideo() = {is_playing}", xbmc.LOGINFO)
        
        if not is_playing:
            xbmc.log("DogPlay Service: ❌ Not playing video - IGNORING (likely scraping)", xbmc.LOGINFO)
            xbmc.log("=" * 80, xbmc.LOGINFO)
            return
        
        # Additional verification: check if we have an actual file playing (not just initializing)
        xbmc.log("DogPlay Service: 🔍 Step 2: Checking playing file...", xbmc.LOGINFO)
        try:
            playing_file = self.getPlayingFile()
            xbmc.log(f"DogPlay Service: getPlayingFile() = {playing_file if playing_file else 'EMPTY'}", xbmc.LOGINFO)
            
            if not playing_file or len(playing_file) < 5:
                xbmc.log("DogPlay Service: ❌ No valid playing file - IGNORING", xbmc.LOGINFO)
                xbmc.log("=" * 80, xbmc.LOGINFO)
                return
            xbmc.log(f"DogPlay Service: ✅ Verified video file: {playing_file[:80]}...", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: ❌ Exception getting playing file: {str(e)} - IGNORING", xbmc.LOGINFO)
            xbmc.log("=" * 80, xbmc.LOGINFO)
            return
        
        # NOW check if this is a DogPlay playback by looking for PENDING properties
        xbmc.log("DogPlay Service: 🔍 Step 3: Checking for PENDING DogPlay properties...", xbmc.LOGINFO)
        try:
            window = xbmcgui.Window(10000)

            # Check for TV pending properties first
            tv_pending_tmdb_id = window.getProperty('dogplay.tv.pending_tmdb_id')
            tv_pending_title = window.getProperty('dogplay.tv.pending_title')
            tv_pending_season = window.getProperty('dogplay.tv.pending_season')
            tv_pending_episode = window.getProperty('dogplay.tv.pending_episode')
            tv_pending_user = window.getProperty('dogplay.tv.pending_user')
            tv_pending_list_id = window.getProperty('dogplay.tv.pending_list_id')

            # Check for movie pending properties
            pending_user = window.getProperty('dogplay.pending_user')
            pending_list_id = window.getProperty('dogplay.pending_list_id')
            pending_tmdb_id = window.getProperty('dogplay.pending_tmdb_id')
            pending_title = window.getProperty('dogplay.pending_title')

            if tv_pending_tmdb_id:  # We have a pending TV episode
                xbmc.log("DogPlay Service: ✅ PENDING TV EPISODE PLAYBACK DETECTED!", xbmc.LOGINFO)
                xbmc.log(f"DogPlay Service: TV properties found:", xbmc.LOGINFO)
                xbmc.log(f"  - tv_pending_tmdb_id: '{tv_pending_tmdb_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - tv_pending_title: '{tv_pending_title}'", xbmc.LOGINFO)
                xbmc.log(f"  - tv_pending_season: '{tv_pending_season}'", xbmc.LOGINFO)
                xbmc.log(f"  - tv_pending_episode: '{tv_pending_episode}'", xbmc.LOGINFO)
                xbmc.log(f"  - tv_pending_user: '{tv_pending_user}'", xbmc.LOGINFO)
                xbmc.log(f"  - tv_pending_list_id: '{tv_pending_list_id}'", xbmc.LOGINFO)
                xbmc.log("DogPlay Service: 🎯 Activating pending TV → current properties...", xbmc.LOGINFO)

                # Activate TV episode properties
                self.current_media_type = 'episode'
                self.user = tv_pending_user
                self.list_id = tv_pending_list_id
                self.current_tmdb_id = tv_pending_tmdb_id
                self.current_title = tv_pending_title
                self.current_season = tv_pending_season
                self.current_episode = tv_pending_episode

                # Set current properties
                window.setProperty('dogplay.tv.current_tmdb_id', self.current_tmdb_id)
                window.setProperty('dogplay.tv.current_title', self.current_title)
                window.setProperty('dogplay.tv.current_season', self.current_season)
                window.setProperty('dogplay.tv.current_episode', self.current_episode)
                window.setProperty('dogplay.tv.current_user', self.user)
                window.setProperty('dogplay.tv.current_list_id', self.list_id)

                # Clear pending TV properties
                window.clearProperty('dogplay.tv.pending_tmdb_id')
                window.clearProperty('dogplay.tv.pending_title')
                window.clearProperty('dogplay.tv.pending_season')
                window.clearProperty('dogplay.tv.pending_episode')
                window.clearProperty('dogplay.tv.pending_user')
                window.clearProperty('dogplay.tv.pending_list_id')

                xbmc.log(f"DogPlay Service: ✅✅✅ CONFIRMED TV PLAYBACK - Now tracking '{self.current_title}' S{self.current_season}E{self.current_episode} (TMDB: {self.current_tmdb_id})", xbmc.LOGINFO)

            elif pending_tmdb_id:  # We have a pending movie playback
                xbmc.log("DogPlay Service: ✅ PENDING MOVIE PLAYBACK DETECTED!", xbmc.LOGINFO)
                xbmc.log(f"DogPlay Service: Movie properties found:", xbmc.LOGINFO)
                xbmc.log(f"  - pending_user: '{pending_user}'", xbmc.LOGINFO)
                xbmc.log(f"  - pending_list_id: '{pending_list_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - pending_tmdb_id: '{pending_tmdb_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - pending_title: '{pending_title}'", xbmc.LOGINFO)
                xbmc.log("DogPlay Service: 🎯 Activating pending → current properties...", xbmc.LOGINFO)

                # Playback confirmed! Activate the pending properties as current
                self.current_media_type = 'movie'
                self.user = pending_user
                self.list_id = pending_list_id
                self.current_tmdb_id = pending_tmdb_id
                self.current_title = pending_title
                self.current_season = None
                self.current_episode = None

                # Set current properties for other components to use
                window.setProperty('dogplay.current_user', self.user)
                window.setProperty('dogplay.current_list_id', self.list_id)
                window.setProperty('dogplay.current_tmdb_id', self.current_tmdb_id)
                window.setProperty('dogplay.current_title', self.current_title)

                xbmc.log("DogPlay Service: 📝 Set CURRENT properties:", xbmc.LOGINFO)
                xbmc.log(f"  - current_user: '{self.user}'", xbmc.LOGINFO)
                xbmc.log(f"  - current_list_id: '{self.list_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - current_tmdb_id: '{self.current_tmdb_id}'", xbmc.LOGINFO)
                xbmc.log(f"  - current_title: '{self.current_title}'", xbmc.LOGINFO)

                # Clear pending properties
                window.clearProperty('dogplay.pending_user')
                window.clearProperty('dogplay.pending_list_id')
                window.clearProperty('dogplay.pending_tmdb_id')
                window.clearProperty('dogplay.pending_title')

                xbmc.log("DogPlay Service: 🧹 Cleared all PENDING properties", xbmc.LOGINFO)
                xbmc.log(f"DogPlay Service: ✅✅✅ CONFIRMED MOVIE PLAYBACK - Now tracking '{self.current_title}' (TMDB: {self.current_tmdb_id})", xbmc.LOGINFO)
            else:
                xbmc.log(f"DogPlay Service: ℹ️  No pending properties - this is NOT a DogPlay playback", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: ❌ Error checking pending properties: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
        
        # Start monitoring thread for TV episodes if enabled
        if self.current_media_type == 'episode':
            tv_autoplay_enabled = addon.getSetting('tv_autoplay_next_episode') == 'true'
            tv_prompt_enabled = addon.getSetting('tv_show_next_episode_prompt') == 'true'

            if tv_autoplay_enabled or tv_prompt_enabled:
                xbmc.log("DogPlay Service: Starting TV episode monitoring thread", xbmc.LOGINFO)
                self.prompt_shown = False
                self.user_choice = None
                self.next_ep_info = None
                # Start monitoring in a separate thread
                import threading
                self.monitor_thread = threading.Thread(target=self._monitor_tv_playback)
                self.monitor_thread.daemon = True
                self.monitor_thread.start()

        xbmc.log("=" * 80, xbmc.LOGINFO)
        xbmc.log("DogPlay Service: onAVStarted() complete", xbmc.LOGINFO)
        xbmc.log("=" * 80, xbmc.LOGINFO)

    def onPlayBackEnded(self):
        """Called when playback ends naturally"""
        xbmc.log("DogPlay Service: onPlayBackEnded - Playback finished naturally", xbmc.LOGINFO)

        # Clear Trakt progress if setting is enabled
        self._clear_trakt_progress_if_enabled()

        # Handle TV episode auto-play
        if self.current_media_type == 'episode':
            xbmc.log("DogPlay Service: TV episode ended", xbmc.LOGINFO)

            tv_autoplay_enabled = addon.getSetting('tv_autoplay_next_episode') == 'true'
            tv_prompt_enabled = addon.getSetting('tv_show_next_episode_prompt') == 'true'

            xbmc.log(f"DogPlay Service: tv_autoplay_enabled={tv_autoplay_enabled}, tv_prompt_enabled={tv_prompt_enabled}, user_choice='{self.user_choice}'", xbmc.LOGINFO)

            # Determine if we should play next episode
            should_play_next = False

            # Check if user already made a choice via prompt
            if tv_prompt_enabled and self.user_choice:
                if self.user_choice == 'play_after':
                    # User selected "Play After" - play next episode now
                    should_play_next = True
                    xbmc.log("DogPlay Service: Playing next episode (user selected 'Play After')", xbmc.LOGINFO)
                elif self.user_choice == 'play_now':
                    # Already handled in monitoring thread
                    xbmc.log("DogPlay Service: Next episode already played via 'Play Now'", xbmc.LOGINFO)
                    return
                elif self.user_choice == 'play_random':
                    # Already handled in monitoring thread
                    xbmc.log("DogPlay Service: Random episode already played", xbmc.LOGINFO)
                    return
                else:
                    # User dismissed or timeout
                    xbmc.log("DogPlay Service: User dismissed prompt, not auto-playing", xbmc.LOGINFO)
                    self._clear_current_playback_info()
                    return
            elif tv_autoplay_enabled:
                # Auto-play is enabled (no prompt)
                should_play_next = True
                xbmc.log("DogPlay Service: Auto-playing next episode", xbmc.LOGINFO)

            if should_play_next:
                # Use stored next_ep_info if available (from prompt), otherwise get fresh info
                next_ep_info = self.next_ep_info if self.next_ep_info else self._get_next_episode_info()

                if next_ep_info:
                    # Play next episode
                    self._play_next_episode(next_ep_info)
                else:
                    # No more episodes - handle "When Show Ends" behavior
                    xbmc.log("DogPlay Service: No more episodes in series", xbmc.LOGINFO)
                    self._handle_show_ends()
            else:
                xbmc.log("DogPlay Service: Not auto-playing next episode", xbmc.LOGINFO)
                self._clear_current_playback_info()

        # Handle movie continuous play
        elif self.current_media_type == 'movie':
            continuous_play = addon.getSetting('continuous_play') == 'true'
            xbmc.log(f"DogPlay Service: continuous_play={continuous_play}, user='{self.user}', list_id='{self.list_id}'", xbmc.LOGINFO)

            if continuous_play and self.user and self.list_id:
                xbmc.log(f"DogPlay Service: Continuous play enabled, playing next movie in 3 seconds", xbmc.LOGINFO)
                xbmc.sleep(3000)

                # Trigger next movie playback
                try:
                    xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.randommovie/?action=play_next&user={self.user}&list_id={self.list_id})')
                except Exception as e:
                    xbmc.log(f"DogPlay Service: Error triggering next movie: {str(e)}", xbmc.LOGERROR)
            else:
                xbmc.log("DogPlay Service: Continuous play disabled or no list info", xbmc.LOGINFO)
                self._clear_current_playback_info()
        else:
            # Unknown media type
            xbmc.log("DogPlay Service: Unknown media type, clearing playback info", xbmc.LOGINFO)
            self._clear_current_playback_info()

    def onPlayBackStopped(self):
        """Called when user manually stops playback"""
        xbmc.log("DogPlay Service: 🛑 onPlayBackStopped - User stopped manually", xbmc.LOGINFO)
        
        # If we have current tracking info, use it. Otherwise, check for PENDING info.
        # This handles cases where user cancels DURING scraping.
        if not self.current_tmdb_id:
            try:
                window = xbmcgui.Window(10000)
                pending_tmdb_id = window.getProperty('dogplay.pending_tmdb_id')
                pending_title = window.getProperty('dogplay.pending_title')
                if pending_tmdb_id:
                    xbmc.log(f"DogPlay Service: Found PENDING tracking for cancelled playback - '{pending_title}' (TMDB: {pending_tmdb_id})", xbmc.LOGINFO)
                    self.current_tmdb_id = pending_tmdb_id
                    self.current_title = pending_title
            except:
                pass

        xbmc.log(f"DogPlay Service: Current tracking - tmdb_id: '{self.current_tmdb_id}', title: '{self.current_title}'", xbmc.LOGINFO)

        # Clear Trakt progress if setting is enabled
        self._clear_trakt_progress_if_enabled()

        # Clear the current playback info so it doesn't auto-play next
        self._clear_current_playback_info()
        xbmc.log("DogPlay Service: 🧹 All properties cleared", xbmc.LOGINFO)
        xbmc.log("DogPlay Service: 🧹 All properties cleared", xbmc.LOGINFO)

    def _monitor_tv_playback(self):
        """Monitor TV episode playback and show next episode prompt"""
        xbmc.log("DogPlay Service: TV monitoring thread started", xbmc.LOGINFO)

        try:
            # Wait a bit for playback to stabilize
            xbmc.sleep(5000)

            while self.isPlayingVideo() and self.current_media_type == 'episode':
                try:
                    # Get current playback time
                    total_time = self.getTotalTime()
                    current_time = self.getTime()
                    time_remaining = total_time - current_time

                    # Show prompt 2 minutes (120 seconds) before end
                    tv_prompt_enabled = addon.getSetting('tv_show_next_episode_prompt') == 'true'

                    if tv_prompt_enabled and not self.prompt_shown and 0 < time_remaining <= 120:
                        xbmc.log(f"DogPlay Service: {time_remaining:.0f}s remaining - showing next episode prompt", xbmc.LOGINFO)
                        self.prompt_shown = True
                        self._show_next_episode_prompt()

                    # Check if user selected "Play Now"
                    if self.user_choice == 'play_now' and self.next_ep_info:
                        xbmc.log("DogPlay Service: User selected 'Play Now' - stopping current playback and starting next episode", xbmc.LOGINFO)
                        self.stop()
                        xbmc.sleep(500)  # Brief pause for clean stop
                        self._play_next_episode(self.next_ep_info)
                        break  # Exit monitoring loop

                    # Check if user selected "Play Random"
                    if self.user_choice == 'play_random':
                        xbmc.log("DogPlay Service: User selected 'Play Random' - stopping current playback", xbmc.LOGINFO)
                        self.stop()
                        xbmc.sleep(500)  # Brief pause for clean stop
                        self._play_random_episode()
                        break  # Exit monitoring loop

                    # Check every 5 seconds
                    xbmc.sleep(5000)

                except Exception as e:
                    xbmc.log(f"DogPlay Service: Error in monitoring loop: {str(e)}", xbmc.LOGERROR)
                    xbmc.sleep(5000)

        except Exception as e:
            xbmc.log(f"DogPlay Service: TV monitoring thread error: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)

        xbmc.log("DogPlay Service: TV monitoring thread ended", xbmc.LOGINFO)

    def _show_next_episode_prompt(self):
        """Show dialog asking if user wants to play next episode"""
        try:
            next_ep_info = self._get_next_episode_info()

            if not next_ep_info:
                xbmc.log("DogPlay Service: No next episode available - series may have ended", xbmc.LOGINFO)

                # Show notification to user that series has ended
                show_ends_behavior = addon.getSetting('tv_show_ends_behavior')
                if show_ends_behavior == 'Pick Random TV Show':
                    xbmcgui.Dialog().notification(
                        'DogPlay',
                        f'{self.current_title} has ended. Playing random show next.',
                        xbmcgui.NOTIFICATION_INFO,
                        3000
                    )
                elif show_ends_behavior == 'Continue Current Season':
                    xbmcgui.Dialog().notification(
                        'DogPlay',
                        f'{self.current_title} season ended. Restarting season.',
                        xbmcgui.NOTIFICATION_INFO,
                        3000
                    )
                else:  # Stop
                    xbmcgui.Dialog().notification(
                        'DogPlay',
                        f'{self.current_title} has ended.',
                        xbmcgui.NOTIFICATION_INFO,
                        3000
                    )
                return

            next_season = next_ep_info.get('season')
            next_episode = next_ep_info.get('episode')
            next_title = next_ep_info.get('episode_title', f'S{next_season:02d}E{next_episode:02d}')

            # Store next episode info for potential use
            self.next_ep_info = next_ep_info

            # Create custom dialog positioned at top-left
            dialog = NextEpisodeDialog(
                self.current_title,
                next_season,
                next_episode,
                next_title
            )
            dialog.doModal()

            # Get result
            self.user_choice = dialog.user_choice
            if self.user_choice == 'play_now':
                xbmc.log("DogPlay Service: User selected 'Play Now'", xbmc.LOGINFO)
            elif self.user_choice == 'play_after':
                xbmc.log("DogPlay Service: User selected 'Play After'", xbmc.LOGINFO)
            elif self.user_choice == 'play_random':
                xbmc.log("DogPlay Service: User selected 'Play Random'", xbmc.LOGINFO)
            else:
                xbmc.log("DogPlay Service: User dismissed dialog or timeout", xbmc.LOGINFO)

            del dialog

        except Exception as e:
            xbmc.log(f"DogPlay Service: Error showing next episode prompt: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)

    def _get_next_episode_info(self):
        """Determine what the next episode should be"""
        try:
            if not self.current_tmdb_id or not self.current_season or not self.current_episode:
                return None

            # Import TMDB API functions
            from apis.tmdb_api import tvshow_details, season_episodes_details

            # Get API key from Fenlight settings (with fallback)
            try:
                from modules.settings_reader import get_setting as fenlight_setting
                api_key = fenlight_setting('tmdb.api_key', 'e7c1c7fca0c2c3bf347aa7d8af5b1c5c')
            except:
                api_key = 'e7c1c7fca0c2c3bf347aa7d8af5b1c5c'

            # Get show details
            show_meta = tvshow_details(self.current_tmdb_id, api_key)
            if not show_meta:
                xbmc.log(f"DogPlay Service: Failed to get show metadata for TMDB {self.current_tmdb_id}", xbmc.LOGERROR)
                return None

            current_season_num = int(self.current_season)
            current_episode_num = int(self.current_episode)

            xbmc.log(f"DogPlay Service: Getting next episode info for S{current_season_num}E{current_episode_num}", xbmc.LOGINFO)

            # Get current season details
            season_meta = season_episodes_details(self.current_tmdb_id, current_season_num)
            if not season_meta or 'episodes' not in season_meta:
                xbmc.log(f"DogPlay Service: Failed to get season {current_season_num} metadata", xbmc.LOGERROR)
                return None

            episode_count = len(season_meta['episodes'])
            xbmc.log(f"DogPlay Service: Season {current_season_num} has {episode_count} episodes", xbmc.LOGINFO)

            # Check if there's a next episode in current season
            if current_episode_num < episode_count:
                # Next episode in same season
                next_episode_num = current_episode_num + 1
                episode_info = None

                for ep in season_meta['episodes']:
                    if ep.get('episode_number') == next_episode_num:
                        episode_info = ep
                        break

                return {
                    'season': current_season_num,
                    'episode': next_episode_num,
                    'episode_title': episode_info.get('name', f'Episode {next_episode_num}') if episode_info else f'Episode {next_episode_num}'
                }
            else:
                # End of season - check for next season
                xbmc.log(f"DogPlay Service: End of season {current_season_num} - checking for next season", xbmc.LOGINFO)

                valid_seasons = [s for s in show_meta.get('seasons', []) if s.get('season_number', 0) > 0]

                # Log all available seasons for debugging
                xbmc.log(f"DogPlay Service: Total seasons in show: {len(valid_seasons)}", xbmc.LOGINFO)
                for s in valid_seasons:
                    season_num = s.get('season_number', 0)
                    ep_count = s.get('episode_count', 0)
                    xbmc.log(f"DogPlay Service:   Season {season_num}: {ep_count} episodes", xbmc.LOGINFO)

                # Find next season
                next_season = None
                for season in valid_seasons:
                    season_num = season.get('season_number')
                    ep_count = season.get('episode_count', 0)

                    if season_num > current_season_num:
                        if ep_count > 0:
                            next_season = season
                            xbmc.log(f"DogPlay Service: Found next season: Season {season_num} with {ep_count} episodes", xbmc.LOGINFO)
                            break
                        else:
                            xbmc.log(f"DogPlay Service: Season {season_num} exists but has 0 episodes (skipping)", xbmc.LOGINFO)

                if next_season:
                    # Next season exists
                    return {
                        'season': next_season['season_number'],
                        'episode': 1,
                        'episode_title': f"Season {next_season['season_number']} Episode 1"
                    }
                else:
                    # No more episodes - series ended
                    xbmc.log(f"DogPlay Service: ⚠️ No next season found after Season {current_season_num}", xbmc.LOGINFO)
                    xbmc.log(f"DogPlay Service: Series '{self.current_title}' appears to have ended", xbmc.LOGINFO)
                    return None

        except Exception as e:
            xbmc.log(f"DogPlay Service: Error getting next episode info: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return None

    def _play_next_episode(self, next_ep_info):
        """Play the next episode using plugin action"""
        try:
            next_season = next_ep_info.get('season')
            next_episode = next_ep_info.get('episode')

            if not next_season or not next_episode:
                xbmc.log("DogPlay Service: Invalid next episode info", xbmc.LOGERROR)
                self._clear_current_playback_info()
                return

            xbmc.log(f"DogPlay Service: Triggering next episode S{next_season:02d}E{next_episode:02d}", xbmc.LOGINFO)

            # Use executebuiltin to trigger playback through the plugin system
            # This ensures proper context and state management
            from urllib.parse import quote
            plugin_url = (
                f'plugin://plugin.video.randommovie/?action=play_specific_episode'
                f'&tmdb_id={self.current_tmdb_id}'
                f'&season={next_season}'
                f'&episode={next_episode}'
                f'&title={quote(self.current_title)}'
                f'&user={quote(self.user or "")}'
                f'&list_id={quote(self.list_id or "")}'
            )
            xbmc.executebuiltin(f'RunPlugin({plugin_url})')

        except Exception as e:
            xbmc.log(f"DogPlay Service: Error playing next episode: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            self._clear_current_playback_info()

    def _handle_show_ends(self):
        """Handle behavior when TV show ends (no more episodes)"""
        try:
            show_ends_behavior = addon.getSetting('tv_show_ends_behavior')
            xbmc.log(f"DogPlay Service: Show ended, behavior setting: '{show_ends_behavior}'", xbmc.LOGINFO)

            if show_ends_behavior == 'Pick Random TV Show':
                xbmc.log("DogPlay Service: Playing random TV show in 3 seconds", xbmc.LOGINFO)
                xbmc.sleep(3000)

                # Trigger random TV show playback
                if self.user and self.list_id:
                    xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.randommovie/?action=play_random_tv&user={self.user}&list_id={self.list_id})')
                else:
                    # Fallback to collection if no list info
                    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.randommovie/?action=play_random_tv_collection)')

            elif show_ends_behavior == 'Continue Current Season':
                # Play first episode of current season
                xbmc.log(f"DogPlay Service: Restarting current season (S{self.current_season}E01) in 3 seconds", xbmc.LOGINFO)
                xbmc.sleep(3000)

                next_ep_info = {
                    'season': int(self.current_season),
                    'episode': 1
                }
                self._play_next_episode(next_ep_info)

            else:  # Stop
                xbmc.log("DogPlay Service: Stopping playback (show ended)", xbmc.LOGINFO)
                self._clear_current_playback_info()

        except Exception as e:
            xbmc.log(f"DogPlay Service: Error handling show end: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            self._clear_current_playback_info()

    def _play_random_episode(self):
        """Play a random episode from the user's list or collection"""
        try:
            xbmc.log("DogPlay Service: Playing random episode (user selected 'Play Random')", xbmc.LOGINFO)
            xbmc.sleep(1000)

            # Trigger random TV episode playback
            if self.user and self.list_id:
                xbmc.log(f"DogPlay Service: Playing random episode from list (user='{self.user}', list_id='{self.list_id}')", xbmc.LOGINFO)
                xbmc.executebuiltin(f'RunPlugin(plugin://plugin.video.randommovie/?action=play_random_tv&user={self.user}&list_id={self.list_id})')
            else:
                # Fallback to collection if no list info
                xbmc.log("DogPlay Service: Playing random episode from collection", xbmc.LOGINFO)
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.randommovie/?action=play_tv_collection)')

        except Exception as e:
            xbmc.log(f"DogPlay Service: Error playing random episode: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            self._clear_current_playback_info()

    def _clear_current_playback_info(self):
        """Clear current playback tracking properties"""
        xbmc.log("DogPlay Service: 🧹 Clearing all playback properties...", xbmc.LOGINFO)
        window = xbmcgui.Window(10000)
        # Clear current movie properties
        window.clearProperty('dogplay.current_user')
        window.clearProperty('dogplay.current_list_id')
        window.clearProperty('dogplay.current_tmdb_id')
        window.clearProperty('dogplay.current_title')
        # Clear pending movie properties
        window.clearProperty('dogplay.pending_user')
        window.clearProperty('dogplay.pending_list_id')
        window.clearProperty('dogplay.pending_tmdb_id')
        window.clearProperty('dogplay.pending_title')
        # Clear current TV properties
        window.clearProperty('dogplay.tv.current_tmdb_id')
        window.clearProperty('dogplay.tv.current_title')
        window.clearProperty('dogplay.tv.current_season')
        window.clearProperty('dogplay.tv.current_episode')
        window.clearProperty('dogplay.tv.current_user')
        window.clearProperty('dogplay.tv.current_list_id')
        # Clear pending TV properties
        window.clearProperty('dogplay.tv.pending_tmdb_id')
        window.clearProperty('dogplay.tv.pending_title')
        window.clearProperty('dogplay.tv.pending_season')
        window.clearProperty('dogplay.tv.pending_episode')
        window.clearProperty('dogplay.tv.pending_user')
        window.clearProperty('dogplay.tv.pending_list_id')

        xbmc.log("DogPlay Service: ✅ Cleared all CURRENT and PENDING properties (movies and TV)", xbmc.LOGINFO)

        self.user = None
        self.list_id = None
        self.current_tmdb_id = None
        self.current_title = None
        self.current_media_type = None
        self.current_season = None
        self.current_episode = None

    def _clear_trakt_progress_if_enabled(self):
        """Clear the movie/episode from Trakt 'In Progress' if setting is enabled"""
        try:
            # Check appropriate setting based on media type
            if self.current_media_type == 'episode':
                clear_enabled = addon.getSetting('tv_clear_trakt_progress') == 'true'
                media_type = 'episode'
            else:
                clear_enabled = addon.getSetting('clear_trakt_progress') == 'true'
                media_type = 'movie'

            xbmc.log(f"DogPlay Service: Trakt clear check - media_type={media_type}, enabled={clear_enabled}, tmdb_id='{self.current_tmdb_id}', title='{self.current_title}'", xbmc.LOGINFO)

            if clear_enabled and self.current_tmdb_id:
                # Import FenlightAM's trakt_api and settings modules
                from apis import trakt_api
                from modules import settings as fenlight_settings

                # Only proceed if user is using Trakt (not Kodi database)
                if fenlight_settings.watched_indicators() != 1:
                    xbmc.log("DogPlay Service: Trakt watched indicators not enabled in Fenlight - skipping", xbmc.LOGINFO)
                    return

                if media_type == 'episode':
                    xbmc.log(f"DogPlay Service: Fetching Trakt playback progress to find episode: TMDB {self.current_tmdb_id} S{self.current_season}E{self.current_episode}", xbmc.LOGINFO)

                    # Get all playback progress from Trakt
                    progress_info = trakt_api.trakt_playback_progress()
                    if not progress_info:
                        xbmc.log("DogPlay Service: No playback progress items found in Trakt", xbmc.LOGINFO)
                        return

                    # Find matching episode in progress list
                    tmdb_id_int = int(self.current_tmdb_id)
                    season_int = int(self.current_season)
                    episode_int = int(self.current_episode)

                    xbmc.log(f"DogPlay Service: Searching {len(progress_info)} playback items for match", xbmc.LOGINFO)

                    for item in progress_info:
                        if item.get('type') != 'episode':
                            continue

                        # Get show TMDB ID
                        show_ids = item.get('show', {}).get('ids', {})
                        show_tmdb = show_ids.get('tmdb')

                        # Get episode details
                        ep = item.get('episode', {})
                        ep_season = ep.get('season')
                        ep_number = ep.get('number')
                        resume_id = item.get('id')

                        # Match by TMDB ID, season, and episode
                        if show_tmdb == tmdb_id_int and ep_season == season_int and ep_number == episode_int:
                            xbmc.log(f"DogPlay Service: Found matching episode in Trakt playback (resume_id: {resume_id})", xbmc.LOGINFO)
                            xbmc.log(f"DogPlay Service: Clearing playback progress via DELETE /sync/playback/{resume_id}", xbmc.LOGINFO)

                            # Clear the progress using the correct endpoint with cache refresh
                            trakt_api.trakt_progress('clear_progress', 'episode', tmdb_id_int, 0, season_int, episode_int, resume_id, refresh_trakt=True)

                            xbmc.log(f"DogPlay Service: ✅ Removed '{self.current_title}' S{self.current_season}E{self.current_episode} from Trakt 'In Progress Episodes' (cache refreshed)", xbmc.LOGINFO)
                            return

                    xbmc.log(f"DogPlay Service: Episode not found in Trakt playback progress - may have already been cleared", xbmc.LOGINFO)

                else:
                    xbmc.log(f"DogPlay Service: Fetching Trakt playback progress to find movie: TMDB {self.current_tmdb_id}", xbmc.LOGINFO)

                    # Get all playback progress from Trakt
                    progress_info = trakt_api.trakt_playback_progress()
                    if not progress_info:
                        xbmc.log("DogPlay Service: No playback progress items found in Trakt", xbmc.LOGINFO)
                        return

                    # Find matching movie in progress list
                    tmdb_id_int = int(self.current_tmdb_id)

                    xbmc.log(f"DogPlay Service: Searching {len(progress_info)} playback items for match", xbmc.LOGINFO)

                    for item in progress_info:
                        if item.get('type') != 'movie':
                            continue

                        # Get movie TMDB ID
                        movie_ids = item.get('movie', {}).get('ids', {})
                        movie_tmdb = movie_ids.get('tmdb')
                        resume_id = item.get('id')

                        # Match by TMDB ID
                        if movie_tmdb == tmdb_id_int:
                            xbmc.log(f"DogPlay Service: Found matching movie in Trakt playback (resume_id: {resume_id})", xbmc.LOGINFO)
                            xbmc.log(f"DogPlay Service: Clearing playback progress via DELETE /sync/playback/{resume_id}", xbmc.LOGINFO)

                            # Clear the progress using the correct endpoint with cache refresh
                            trakt_api.trakt_progress('clear_progress', 'movie', tmdb_id_int, 0, None, None, resume_id, refresh_trakt=True)

                            xbmc.log(f"DogPlay Service: ✅ Removed '{self.current_title}' from Trakt 'In Progress Movies' (cache refreshed)", xbmc.LOGINFO)
                            return

                    xbmc.log(f"DogPlay Service: Movie not found in Trakt playback progress - may have already been cleared", xbmc.LOGINFO)

            elif not clear_enabled:
                xbmc.log(f"DogPlay Service: Clear Trakt progress disabled in settings for {media_type}", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"DogPlay Service: Error clearing Trakt progress: {str(e)}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"DogPlay Service: Traceback: {traceback.format_exc()}", xbmc.LOGERROR)

if __name__ == '__main__':
    monitor = DogPlayMonitor()
    monitor.run()
